import { IBNCLibraryStrings } from "./libraries/interfaces/commun/IBNCLibraryString";

export const BNCConstantsStrings: IBNCLibraryStrings = {
  "ErrorsGetProfilEmailNotDefined": "getProfil email is not defined.",
  "ErrorsNeedRawDataServiceContext": "getProfil need rawDataService.context.",
  "ErrorsNeedRawDataService": "getProfil need rawDataService.",
  "ErrorsExpectValidUser": "Expected a valid user from graph object from processProfilData",
  "ErrorsProfilDataInCompetencies": "Persona:ProfilData is undefined in setCompetencies().",
  "PropertyPaneDescription": "Description",
  "BasicGroupName": "Group Name",
  "DescriptionFieldLabel": "Description Field"
};
