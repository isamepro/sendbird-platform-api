import moment from 'moment';
import { PersonaPresence } from 'office-ui-fabric-react';

export class FormatHelper {
  /**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************
   * Find and replace ISO 8601 dates in the string by a friendly value
   * @param inputValue The string to format
   *************************************************************************************/
  public static formatDate( inputValue: string ): string {

    if ( !inputValue ) return '';

    const iso8061rgx = /(\d{4}-[01]\d-[0-3]\dT[0-2]\d:[0-5]\d:[0-5]\d\.\d+([+-][0-2]\d:[0-5]\d|Z))|(\d{4}-[01]\d-[0-3]\dT[0-2]\d:[0-5]\d:[0-5]\d([+-][0-2]\d:[0-5]\d|Z))|(\d{4}-[01]\d-[0-3]\dT[0-2]\d:[0-5]\d([+-][0-2]\d:[0-5]\d|Z))/g;
    const matches = inputValue.match( iso8061rgx );

    let updatedInputValue = inputValue;

    if ( matches ) {
      matches.map( match => {
        updatedInputValue = updatedInputValue.replace(
          match,
          moment( match ).format( "LL" )
        );
      } );
    }

    return updatedInputValue;
  }


  /**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************
   * Find and replace ISO 8601 dates in the string by a friendly value
   * @param inputValue The string to format
   *************************************************************************************/
  public static formatSize( inputValue: string ): string {
    const numberMatch = /([+-]?\d+(?:\.\d+)?)|(\B-\B)/g;
    const matches = inputValue.match( numberMatch );

    let updatedInputValue = inputValue;

    if ( matches ) {
      matches.map( match => {
        let intMatch = parseInt( match );
        let i = Math.floor( Math.log( intMatch ) / Math.log( 1024 ) );
        let newVal =
          ( ( intMatch / Math.pow( 1024, i ) ) * 1 ).toFixed( 2 ) +
          " " +
          [ "B", "KB", "MB", "GB", "TB" ][ i ];
        updatedInputValue = updatedInputValue.replace( match, newVal );
      } );
    }

    return updatedInputValue;
  }

  /**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************
   * Find and eeplace ISO 8601 dates in the string by a friendly value
   * @param inputValue The string to format
   *************************************************************************************/
  public static isDateRefiner( inputValue: string ): boolean {
    const iso8061rgx = /(\d{4}-[01]\d-[0-3]\dT[0-2]\d:[0-5]\d:[0-5]\d\.\d+([+-][0-2]\d:[0-5]\d|Z))|(\d{4}-[01]\d-[0-3]\dT[0-2]\d:[0-5]\d:[0-5]\d([+-][0-2]\d:[0-5]\d|Z))|(\d{4}-[01]\d-[0-3]\dT[0-2]\d:[0-5]\d([+-][0-2]\d:[0-5]\d|Z))/g;
    const matches = inputValue.match( iso8061rgx );
    if ( matches ) {
      return matches.length > 0;
    }
    return false;
  }

  /**
   * Get date formatted
   * @param date
   * @param format
   */
  public static getDateFormatted( date: string, format: string ) {
    if ( moment( date ).isValid() ) {
      return moment( date ).format( format );
    }
  }

  /**
   * Get phone number formatted
   * @param phoneNumberString
   */
  public static formatPhoneNumber( phoneNumberString:string ):string {
    var cleaned = ( "" + phoneNumberString ).replace( /\D/g, "" );
    var match = cleaned.match( /^(1|)?(\d{3})(\d{3})(\d{4})$/ );
    if ( match ) {
      //var intlCode = (match[1] ? '+1 ' : '')
      return [/*intlCode,*/ "+1 ", match[ 2 ], ".", match[ 3 ], ".", match[ 4 ] ].join(
        ""
      );
    }
    match = cleaned.match( /^(1|)?(\d{3})(\d{3})(\d{4})(\d{4})$/ );
    if ( match ) {
      //var intlCode = (match[1] ? '+1 ' : '')
      return [
        /*intlCode,*/ "+1 ",
        match[ 2 ],
        ".",
        match[ 3 ],
        ".",
        match[ 4 ],
        "#",
        match[ 5 ]
      ].join( "" );
    }
    match = cleaned.match( /^(1|)?(\d{3})(\d{3})(\d{4})(\d{5})$/ );
    if ( match ) {
      //var intlCode = (match[1] ? '+1 ' : '')
      return [
        /*intlCode,*/ "+1 ",
        match[ 2 ],
        ".",
        match[ 3 ],
        ".",
        match[ 4 ],
        "#",
        match[ 5 ]
      ].join( "" );
    }
    return phoneNumberString;
  }

  public static formatPostalCode ( postCodeString:string ):string {
    if (
      !postCodeString ||
      typeof postCodeString !== "string" ||
      postCodeString.length !== 6
    )
      return postCodeString;

    return `${ postCodeString.substring( 0, 3 ) } ${ postCodeString.substring( 3 ) }`;
  }


  /**
  *
  *
  * @protected
  * @descriptionThe base presence information for a user. Possible values are Available, AvailableIdle, Away, BeRightBack, Busy, BusyIdle, DoNotDisturb, Offline, PresenceUnknown
  * @param {string} value
  * @returns {PersonaPresence}
  *
  * @memberOf ProfilService
  */
  public static getPresenceType( value: string ): PersonaPresence {
    switch ( value ) {
      case 'Available':
        return PersonaPresence.online;
        break;
      case 'AvailableIdle':
        return PersonaPresence.away;
        break;
      case 'Away':
        return PersonaPresence.away;
        break;
      case 'BeRightBack':
        return PersonaPresence.away;
        break;
      case 'Busy':
        return PersonaPresence.busy;
        break;
      case 'BusyIdle':
        return PersonaPresence.busy;
        break;
      case 'DoNotDisturb':
        return PersonaPresence.dnd;
        break;

      case 'Offline':
        return PersonaPresence.offline;
        break;

      case 'PresenceUnknown':
        return PersonaPresence.none;
        break;

      default:
        return PersonaPresence.none;
        break;
    }

  }

}
