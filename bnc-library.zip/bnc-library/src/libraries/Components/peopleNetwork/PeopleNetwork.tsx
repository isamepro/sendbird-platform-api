import * as React from "react";
import { IPeopleNetworkProps, PeopleNetworkType } from "./PeopleNetwork.types";
import styles from './PeopleNetwork.module.scss';

export class PeopleNetwork extends React.Component<
  IPeopleNetworkProps,
  null
  > {
  /**
   * Creates an instance of PeopleNetworkComponent.
   * @param {IPeopleNetworkProps} props
   *
   * @memberOf PeopleNetworkComponent
   */
  constructor( props: IPeopleNetworkProps ) {
    super( props );
  }

  /**
   *
   *
   * @returns {JSX.Element}
   *
   * @memberOf PeopleNetworkComponent
   */
  public render(): JSX.Element {
    if (this.props === undefined) return;

    return (
      <div className={styles.peopleNetworkContainer} style={{ backgroundColor: this.props.backgroundColor }}>
        <div className={styles.menuContainer}>
          <div className={styles.menu}>
            <div className={styles.menuItem} onClick={() => { this.onClickMenu(PeopleNetworkType.Colleagues); }} >
              <div className={styles.menuText}
                style={{
                  color: this.getMenuLabelColor(this.props.colleaguesType === PeopleNetworkType.Colleagues)
                }}
              >
                {this.props.colleagueMenuLabel}
              </div>
              <div
                className={styles.menuSelectIndicator}
                style={this.getSelectIndicatorStyles(this.props.colleaguesType === PeopleNetworkType.Colleagues)}
              />
            </div>
            {/* <div
              className={styles.menuItem}
              onClick={() => { this.onClickMenu(PeopleNetworkType.SimilarProfiles); }}
            >
              <div
                className={styles.menuText}
                style={{
                  color: this.getMenuLabelColor(this.props.colleaguesType === PeopleNetworkType.SimilarProfiles)
                }}
              >
                {this.props.similarProfilesMenuLabel}
              </div>
              <div
                className={styles.menuSelectIndicator}
                style={this.getSelectIndicatorStyles(this.props.colleaguesType === PeopleNetworkType.SimilarProfiles)}
              />
            </div> */}
          </div>
        </div>
        <div
          className={styles.peopleListContainer}
          style={{ maxHeight: window.innerHeight - 250 }}
        >
          {this.props.children}
      </div>
      </div>
    );
  }

  private onClickMenu = (type: PeopleNetworkType) => {
    if (this.props.colleaguesType !== type && this.props.switchSource) {
      this.props.switchSource(type);
    }
  }

  private getSelectIndicatorStyles = (isSelected: boolean) => {
    let defaultColor = '#000';
    let selectIndicatorStyles = {};
    if (isSelected) {
      selectIndicatorStyles['opacity'] = 1;
      selectIndicatorStyles['borderColor'] = this.props.menuSelectorColor || defaultColor;
    } else {
      selectIndicatorStyles['borderColor'] = this.props.menuHoverColor || defaultColor;
    }
    return selectIndicatorStyles;
  }

  private getMenuLabelColor = (isSelected: boolean): string => {
    return isSelected ? this.props.menuSelectorColor : this.props.menuColor;
  }
}
