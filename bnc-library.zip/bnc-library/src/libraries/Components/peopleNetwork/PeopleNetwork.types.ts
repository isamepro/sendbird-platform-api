
export enum PeopleNetworkType {
  Colleagues = 'colleagues',
  SimilarProfiles = 'similarProfiles'
}

export interface IPeopleNetworkProps {
  colleaguesType: PeopleNetworkType;
  switchSource?(menuSelection: PeopleNetworkType): void;
  colleagueMenuLabel: string;
  similarProfilesMenuLabel: string;
  backgroundColor?: string;
  menuSelectorColor?: string;
  menuColor?: string;
  menuHoverColor?: string;
}
