
export const bncTenantPropertiesNamespace: string = "BNC";
export const bncTenantPropertiesNamespaceCommon: string = "BNC.Common";
export const bncHeadquarterAddress: string = "600 de la Gauchetière Ouest Montreal Quebec Canada";
export const deepseSearchQueryResultFields = {
  type: 'type',
  source: 'source',
  content: 'content',
};

export const searchQueryResultFields = {
  createdByDisplayName: 'createdByDisplayName',
  spaceName: 'spaceName',
  spaceKey: 'spaceKey',
  createdDate: 'createdDate',
  lastModified: 'lastModified',
  projectLeadName: 'projectLeadName',
  projectKey: 'projectKey',
  assigneeDisplayName: 'assigneeDisplayName',
  like: 'like',
  /** succursales */
  transitId: 'transitId',
  open24h7d: 'open24h7d',
  printer: 'printer',
  civicNum: 'civicNum',
  displayStreetFr: 'displayStreetFr',
  displayStreetEn: 'displayStreetEn',
  displayCityFr: 'displayCityFr',
  displayCityEn: 'displayCityEn',
  postalCode: 'postalCode',
  provinceFr: 'provinceFr',
  provinceEn: 'provinceEn',
  handicappedAccess: 'handicappedAccess',
  displayIntersectionFr: 'displayIntersectionFr',
  displayIntersectionEn: 'displayIntersectionEn',
  displaySiteFr: 'displaySiteFr',
  displaySiteEn: 'displaySiteEn',
  atmId: 'atmId',
  withDrawOnly: 'withDrawOnly',
  exchange: 'exchange',
  displayNameFr: 'displayNameFr',
  displayNameEn: 'displayNameEn',
  phone: 'phone',
  fax: 'fax',
  aTMCount: 'aTMCount',
  exchangeOffice: 'exchangeOffice',
  transitTypeId: 'transitTypeId',
  transitTypeFr: 'transitTypeFr',
  transitTypeEn: 'transitTypeEn',
  distanceAtm: 'distanceAtm',

  /** Documents */
  title: 'Title',
  hitHighlightedSummary: 'HitHighlightedSummary',
  rank: 'Rank',
  docId: 'DocId',
  filename: 'Filename',
  siteTitle: 'SiteTitle',
  sPWebUrl: 'SPWebUrl',
  serverRedirectedPreviewURL: 'ServerRedirectedPreviewURL',
  serverRedirectedEmbedURL: 'ServerRedirectedEmbedURL',
  path: 'Path',
  serverRedirectedURL: 'ServerRedirectedURL',
  refinableString123: 'RefinableString123',
  department: 'Department',
  spsLocation: 'SPS-Location',
  workPhone : 'WorkPhone',
  workEmail: 'WorkEmail',
  jobTitle: 'JobTitle',
  officeNumber: 'OfficeNumber',
  pictureURL: 'PictureURL',
  preferredName: 'PreferredName',
  sipAddress: 'SipAddress',
  mobilePhone: 'MobilePhone'


  /** Images */

  /** Videos */

};

export enum EnumLinePersonaData {
	DisplayName = 0,
	JobTitle = 1,
	Email = 2
}
