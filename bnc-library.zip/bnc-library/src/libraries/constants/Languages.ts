export enum Languages {
    English  = "English",
    French   = "French"
}
