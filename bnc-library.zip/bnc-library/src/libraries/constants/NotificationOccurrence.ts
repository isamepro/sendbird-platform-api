export enum NotificationOccurrence {
    Never         = -1,
    Spot          = 0,
    Each10Minutes = 10,
    Hourly        = 60,
    Each8Hour     = 480,
    Daily         = 1440,
}
