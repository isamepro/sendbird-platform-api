export enum TeamsThemes {
  Contrast = "contrast",
  Default = "default",
  Dark = "dark",
}
