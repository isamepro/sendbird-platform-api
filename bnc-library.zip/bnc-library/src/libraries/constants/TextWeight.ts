export enum TextWeight {
  Light = "light",
  SemiLight = "semilight",
  Regular = "regular",
  SemiBold = "semibold",
  Bold = "bold",
}
