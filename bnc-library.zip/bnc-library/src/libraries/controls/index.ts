export { PeopleNetwork, IPeopleNetworkProps, PeopleNetworkType } from "../Components/peopleNetwork"; // To move to controls directory
