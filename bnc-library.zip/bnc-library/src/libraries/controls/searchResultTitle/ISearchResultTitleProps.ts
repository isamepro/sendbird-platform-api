// import {ITelemetryService} from "../../services/telemetryService/ITelemetryService";

// export interface ISearchResultTitleProps {
//   title: string;
//   content?: string;
//   url: string;
//   rank?: string;
//   target?: string;
//   position?: number;
//   docId?: string;
//   telemetryService?: ITelemetryService;
//   isStamped?: boolean;
//   stampedClassName?: string;
// }
