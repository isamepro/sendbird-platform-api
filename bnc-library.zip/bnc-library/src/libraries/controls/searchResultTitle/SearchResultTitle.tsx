// import * as React from 'react';
// import { ISearchResultTitleProps } from './ISearchResultTitleProps';
// import { EventName } from '../../services/telemetryService/TelemetryConstants';

// export class SearchResultTitle extends React.Component<ISearchResultTitleProps, {}> {

//   public render(): React.ReactElement<ISearchResultTitleProps> {

//     return (<a
//       href={this.props.url}
//       onClick={this.onClick}
//       className='is-trackable'
//       data-interception='off'
//       target='_blank'
//       data-eventname='resultItemInteraction'
//       data-action='resultSelected'
//       data-position={`${ this.props.position }`}
//       data-rank={this.props.rank}
//       data-title={this.props.title}
//       data-docid={this.props.docId}
//       data-path={this.props.url}>
//       {this.props.title}
//       {
//         this.props.isStamped &&
//         <div className={this.props.stampedClassName}>
//           <i className='ms-Icon ms-Icon--SkypeCircleCheck'></i>
//         </div>
//       }
//     </a>);
//   }

//   private onClick = (ev) => {
//     if (this.props.telemetryService) {
//       this.props.telemetryService.takeClickSnapshot(EventName.click, {
//         results: JSON.stringify({title: this.props.title, url: this.props.url, summary: this.props.content})
//       });
//     }
//   }
// }
