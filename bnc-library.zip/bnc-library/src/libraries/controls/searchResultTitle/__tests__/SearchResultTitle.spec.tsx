// /// <reference types="jest" />

// import 'jest';
// import * as React from 'react';
// import { SearchResultTitle } from "../SearchResultTitle";
// import { configure, mount } from 'enzyme';

// describe('SearchResultTitle Component', () => {

//   let renderedElement;
//   let selector:string = ".is-trackable";
//   beforeEach(() => {
//     renderedElement = mount(<SearchResultTitle title="A Title" url="http://bnc.ca" content="content" />);
//   });

//   it('render should return a link', () => {

//     const element = renderedElement.find(selector);
//     expect(element.length).toBeGreaterThan(0);
//   });

//   it('should has the correct title', () => {

//     const element = renderedElement.find(selector);
//     const text = element.text();

//     // Assert
//     expect(text).toBe("A Title");
//   });

// });
