export interface IBNCLibraryStrings {
  ErrorsGetProfilEmailNotDefined: string;
  ErrorsNeedRawDataServiceContext: string;
  ErrorsNeedRawDataService: string;
  ErrorsExpectValidUser: string;
  ErrorsProfilDataInCompetencies: string;
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}
