export interface IPresenceInfo {
  availability: string;
  activity: string;
  id: string;
}
