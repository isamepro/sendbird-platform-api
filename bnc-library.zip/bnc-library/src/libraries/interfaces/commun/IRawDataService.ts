import { IPaging } from '../../model/paging/IPaging';
import { IHubServiceFactoryContext, ISearchPersonas, IPresenceInfo } from '../../..';
import { User } from '@microsoft/microsoft-graph-types';
import { ResultsCertificationStardog, ResultsLanguagesStardog, ResultsApplicationBNCStarDog } from '../../model/Profil/stardog/IObjectsBNCStardog';
import { IApplicationBNCStarDog, ICertificationStardog, ILanguagesBNCStardog } from '../../model/Profil/stardog/IObjectsBNCStardog';
import {ITagActionData} from '../../model/commun/ITagActionData';

export interface IRawDataService {
  context: IHubServiceFactoryContext;
  getPersonaRawData( email: string ): Promise<any>;
  getPresence( email: string ): Promise<IPresenceInfo>;
  getPersonasRawData( keywords: string, paging?: IPaging ): Promise<ISearchPersonas>;
  getPeoplesByEmail( email: string, paging: IPaging ): Promise<User[]>;
  getPictureUrl( email: string ): string;
  getDisplayName( row: any ): string;
  getTitle( row: any ): string;
  getEmail( row: any ): string;
  getLanguagesRawData( email: string ): Promise<ResultsLanguagesStardog>;
  getCertificationsRawData( email: string ): Promise<ResultsCertificationStardog>;
  getApplicationBNCRawData( email: string ): Promise<ResultsApplicationBNCStarDog>;
  addPropertieValue( tagValues: ITagActionData ): Promise<any>;
  setPropertieValue(tagValues: ITagActionData): Promise<any>;
  getApplicationBNCRawData( email: string ): Promise<IApplicationBNCStarDog>;
}



