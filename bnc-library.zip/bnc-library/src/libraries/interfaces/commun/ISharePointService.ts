import { IQueryRequest } from '../../model/commun/IQueryRequest';
import { IQueryResult } from '../../model/commun/IQueryResult';
import { IResult } from '../../model/commun/IResult';
import { IWebhook } from './IWebhook';

export interface ISharePointService {
  getFileContent(webUrl: string, listname: string, filename: string): Promise<string>;
  addWebhook(listName:string, webUrl: string): void;
  getWebhook(listName: string,webhookUrl:string):Promise<IWebhook>;
  updateWebhook(listName: string,webhookId: string): void;
  search(queryRequest: IQueryRequest): Promise<IQueryResult>;
  listExists(listName: string): Promise<boolean>;
  getListIdByName(listName: string): Promise<string>;
  userIsAuthorizedToManageContent(guid:string): Promise<boolean>;
  isUserInOwnerGroup(webUrl: string): Promise<boolean>;
  addUserToOwnerGroup(webUrl: string): Promise<boolean>;
  isSiteOwner(): Promise<boolean>;
  addFieldToCurrentList(fieldName: string, fieldDisplayName:string): void;
  getCurrentListId(): string;
  getFieldFromSiteColection(fieldName: string): Promise<any>;
  getTenantProperty(value: string): Promise<any>;
}
