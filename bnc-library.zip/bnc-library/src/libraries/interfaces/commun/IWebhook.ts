export interface IWebhook {
    webhookId:string;
    expirationDate:string;
}