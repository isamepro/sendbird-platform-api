import { WebPartContext } from '@microsoft/sp-webpart-base';
import { EnvironmentType } from '@microsoft/sp-core-library';
import { ServiceScope } from "@microsoft/sp-core-library";

export interface IPreferencesEndpoint {
  userPreferences: string;
  notificationTypes: string;
}

export interface IContextBase {
  spfxContext: WebPartContext | any;
  environmentType: EnvironmentType;
  endPointUrl?: string;
  userPreferencesEndpoint?: IPreferencesEndpoint;
  tenantKey?: string;
}

export interface IRawServiceFactoryContext extends IContextBase {
  language: string;
  strings: any;
  serviceDomainUrl?: string;
  azureServiceProfilsUrl?: string;
  subscriptionkey?: string;
}

export interface IHubServiceFactoryContext extends IRawServiceFactoryContext { }

export interface IFactoryContext extends IContextBase {}
