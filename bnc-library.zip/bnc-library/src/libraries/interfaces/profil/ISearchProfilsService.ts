import { ISearchPersonas } from '../../model/Profil/ISearchPersonas';
import { IPaging } from '../../model/paging/IPaging';
import { User } from '@microsoft/microsoft-graph-types';
export interface ISearchProfilsService {
  getProfils( keyword: string, paging: IPaging ): Promise<ISearchPersonas>;
  getPeoplesByEmail( email: string, paging: IPaging ): Promise<User[]>;
}
