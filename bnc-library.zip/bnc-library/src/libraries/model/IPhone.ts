export interface IPhone {
  phone: string;
  ext?: string;
}
