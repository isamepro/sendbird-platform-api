import { ITag } from "@fluentui/react";
import { Field } from "../queryResults/ISearchQueryResult";
import { StatusValues } from "../commun/StatusValues";
import { ManageCompetencyStatus } from "../../services/profilSocial/ProfilSocialService.status";

export interface IProfilDataItem extends ITag {
  description?: string;
  date?: Date;
  value?: string;
  /**
   * This property is used to specify the status of item (competencies, suggested competencies).
   * TODO: TO REMOVE StatusValues after refactoring. ID: 2020-10-13
   *
   * @type {StatusValues}
   * @memberof IProfilDataItem
   */
  status?: StatusValues | ManageCompetencyStatus;
  fields?: Field;
  json?: string;
}
