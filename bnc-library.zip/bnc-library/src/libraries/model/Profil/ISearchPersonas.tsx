import { IPersonaData } from './persona/IPersonaData';
export interface ISearchPersonas {
  header: string;
  keyword: string;
  data: IPersonaData[];
  totalRows: number;
}
