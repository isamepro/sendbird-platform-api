import { ILine } from '../../commun/ILine';
import { ITagBNC } from '../../commun/ITagBNC';

export interface IDescriptionCard {
	lines: ILine[];
	titre?: string;
	date?: string;
	description?: string;
	mapUrl?: string;
	tags?: ITagBNC[];
}
