import { IDescriptionCard } from './IDescriptionCard';
import { IPhone } from '../../../..';
import { PersonaPresence } from 'office-ui-fabric-react';
export interface IPersonaData extends IDescriptionCard {
  pictureUrl?: string;
  presence: string | PersonaPresence;
  email?: string;
  phones?: IPhone[];
}
