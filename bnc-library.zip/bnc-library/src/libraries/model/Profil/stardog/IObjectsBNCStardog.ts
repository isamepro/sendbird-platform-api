export interface IApplicationBNCStarDog {
  head: Head;
  results: ResultsApplicationBNCStarDog;
}
export interface ICertificationStardog {
  head: Head;
  results: ResultsCertificationStardog;
}
export interface ILanguagesBNCStardog {
  head: Head;
  results: ResultsLanguagesStardog;
}
export interface Head {
  vars?: (string)[] | null;
}
export interface ResultsApplicationBNCStarDog {
  bindings?: (BindingsEntityApplication)[] | null;
}
export interface BindingsEntityApplication {
  employeeId: LiteralValue;
  email: LiteralValue;
  applicationBNCLabel: LiteralValue;
  id?: LiteralValue | null;
}
export interface ResultsCertificationStardog {
  bindings?: (BindingsEntityResultsCertificationStardog)[] | null;
}
export interface ResultsLanguagesStardog {
  bindings?: (BindingsEntityResultsLanguageStardog)[] | null;
}
export interface BindingsEntityResultsCertificationStardog {
  employeeId: LiteralValue;
  email: LiteralValue;
  certificationLabel: LiteralValue;
  startMonthYear: DateValue;
  endMonthYear?: DateValue | null;
  logoUrl?: LiteralValue | null;
  description?: LiteralValue | null;
  valid?: LiteralValue | null;
  id?: LiteralValue | null;
}
export interface BindingsEntityResultsLanguageStardog {
  employeeId: LiteralValue;
  email: LiteralValue;
  languageLabel: LiteralValue;
  languageProficiency: LiteralValue | null;
  languageCode?: LiteralValue | null;
  id?: LiteralValue | null;
}
export interface LiteralValue {
  type: string;
  value: string;
}
export interface DateValue {
  type: string;
  value: string;
}
