export interface IPersonas {
  head: Head;
  results: Results;
}
export interface Head {
  vars?: string[] | null;
}
export interface Results {
  bindings?: IPersonaData[] | null;
}
export interface IPersonaData {
  lastName: FieldSet;
  firstName: FieldSet;
  pictureUrl: FieldSet;
  transit: FieldSet;
  projets: Datatype;
  employeeID: FieldSet;
  type: Datatype;
  userName: FieldSet;
  title: FieldSet;
  email: FieldSet;
  phones: FieldSet;
  group: FieldSet;
  streetAddr: FieldSet;
  location: FieldSet;
  city: FieldSet;
  country: FieldSet;
  prov: FieldSet;
  zipCode: FieldSet;
  count_employee: FieldSet;
  count_consultant: FieldSet;
  organization: FieldSet;
  thumbnail: FieldSet;
  pName: FieldSet;
  competency?: FieldSet | null;
  name: FieldSet;
  position: FieldSet;
  worker: FieldSet;
  gName: FieldSet;
  userId: FieldSet;
  emplSts: FieldSet;
  emplType: FieldSet;
}
/**
 * DEPRECATED : Please use IFieldSet in common/stardog
 *
 * @export
 * @interface FieldSet
 */
export interface FieldSet {
  type: string;
  value: string;
}
export interface Datatype {
  datatype: string;
  type: string;
  value: string;
}
