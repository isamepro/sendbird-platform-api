export enum ChangeTypeValues {
    add = 'Add',
    delete= 'Delete',
    update = 'Update'
}





