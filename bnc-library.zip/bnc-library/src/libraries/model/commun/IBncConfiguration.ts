export interface IBncConfiguration {
  '@odata.null'?: boolean;
  apimUrl: string;
  apimSubscriptionKey: string;
  apimMicroServiceUrl: string;
  apimMicroServiceSubscriptionKey: string;
  appInsightsInstrumentationKey: string;
}
