export interface IDescription {
  description?: string;
  subDescription?: string;
}
