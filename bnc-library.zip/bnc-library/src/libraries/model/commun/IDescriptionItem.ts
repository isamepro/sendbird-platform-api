import { ITagBaseBNC } from "./ITagBaseBNC";
export interface IDescriptionItem extends ITagBaseBNC {
  startMonthYear: Date | null;
  endMonthYear?: Date | null;
  dateText: string;
  logoUrl?: string;

}




export interface IReconnaisance extends IDescriptionItem {

}
