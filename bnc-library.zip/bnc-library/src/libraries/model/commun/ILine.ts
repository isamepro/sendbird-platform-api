export interface ILine {
	line: string;
}
