export interface IQueryRequest{
    id: string;
    query: string;
    rowLimit: number;
    properties: string[];
    sourceId: string;
    queryTemplate: string;
  }

