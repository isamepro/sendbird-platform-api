import { IResult } from "./IResult";

export interface IQueryResult{
  totalCount: number;
  results: IResult[];
}

