import { IPickerTerms } from "@pnp/spfx-property-controls/lib/propertyFields/termPicker/IPropertyFieldTermPicker";

export interface IResult{
  id: number;
  title?: string;
  bncWPContent?: string;
  bncLocation?: any[];
  bncSubject?: any[];
  bncContentType?: any[];
  bncColContentOWSMTXT? : string;
  owstaxIdTaxKeyword? : string;
  TaxKeyword?: any[];
  created?: Date;
  author?: string;
  webUrl?: string;
  pageOriginUrl?: string;
  modifiedDate?:Date;
}

