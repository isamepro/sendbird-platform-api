export interface ISearchResult {
  [key: string]: string;
  IconSrc?: string;
}
