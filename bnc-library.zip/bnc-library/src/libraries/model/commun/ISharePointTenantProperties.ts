import {SPHttpClient} from "@microsoft/sp-http";

export interface ISharePointTenantProperties {
    spHttpClient: SPHttpClient | any;
    serverUrl: string;
    tenantKey: string;
}
