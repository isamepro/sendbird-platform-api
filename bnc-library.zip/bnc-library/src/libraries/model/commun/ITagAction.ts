import { StatusValues } from './StatusValues';

export interface ITagAction {
	id: string;
	name: string;
	status: StatusValues | string ;
	isSuggestedCompetency:boolean;
}
