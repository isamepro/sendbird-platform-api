import { ITagAction } from '../../..';

export interface ITagActionData extends ITagAction {
	email?: string;
}


