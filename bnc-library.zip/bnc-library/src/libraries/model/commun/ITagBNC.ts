import { ITagBaseBNC } from "./ITagBaseBNC";

export interface ITagBNC extends ITagBaseBNC {
  approuved?: boolean;
  status: string;
  description:string;
  category:string;
}


