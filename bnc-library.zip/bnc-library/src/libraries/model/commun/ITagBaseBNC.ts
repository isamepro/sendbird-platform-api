import { IDescriptionItem } from "./IDescriptionItem";

export interface ITagBaseBNC {
  id?: string;
  text: string;
}

