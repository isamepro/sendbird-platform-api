export interface ITitle {
  title?: string;
  subTitle?: string;
}
