export interface IUrl {
  title?: string;
  description?: string;
  url?: string;
}
