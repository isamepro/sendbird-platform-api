export enum SearchResultType {
  document = "documents",
  image = "images",
  video = "videos",
  graph = "graphs",
  conversation = "conversations",
  projet = "projets",
  produit = "produits",
  portailBNC = "portailBNC",
  taches= "taches",
  contacts= "contacts",
  outils="outils",
  succursales="succursales",
  succursaleDetail="succursaleDetail",
  profilsSearch = 'profilsSearch',
  fbn = 'fbns',
  question = 'questions',
  nearestAtm = 'nearestAtms'
}
