export enum SourcesService {
	O365 = 'O365',
	StarDog = 'StarDog',
	Debug = 'Mock',
	SharePoint = 'SharePoint'
}
