export enum StatusValues {
  /**
   * Used to perform feedback
   */
  sugested = 'rating_feedback_valid',

  /**
   * Used to perform feedback
   */
  add = 'rating_feedback_valid',

  /**
   * Used to perform feedback
   */
  delete = 'rating_feedback_rejected',
  suggestedComptency = 'suggestedCompetency',
  validatedCompetency = 'validatedCompetency'
}
