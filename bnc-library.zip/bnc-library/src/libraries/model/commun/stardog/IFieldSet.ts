export interface IFieldSet {
  type?: string;
  value?: string;
}
