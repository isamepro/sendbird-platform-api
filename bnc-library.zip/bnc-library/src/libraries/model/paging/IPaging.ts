export interface IPaging {
	offset: number;
	limit: number;
}
