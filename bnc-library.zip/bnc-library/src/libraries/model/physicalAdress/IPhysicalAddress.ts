export interface IPhysicalAddress {
  city?: string | null;
  countryOrRegion?: string | null;
  postalCode?: string | null;
  postOfficeBox?: string | null;
  state?: string | null;
  street?: string | null;
  type?: "unknown" | "home" | "business" | "other";
}
