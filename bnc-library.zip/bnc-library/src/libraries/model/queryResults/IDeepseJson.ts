export interface IDeepseJSON {
  version?: string;
  responseHeader?: IDeepseJSONResponseHeader;
  response?: IDeepseJSONResponse;
}

export interface IDeepseJSONResponse {
  effectiveLanguage?: string;
  content?: Content;
}

export interface Content {
  responseHeader?: ContentResponseHeader;
  response?: ContentResponse;
  facetCounts?: FacetCounts;
}

export interface FacetCounts {
  facetFields?: FacetFields;
}

export interface FacetFields {
  index?: FacetItem[];
  fileType?: FacetItem[];
}

export interface FacetItem {
  name?: string;
  docCount?: number;
}

export interface ContentResponse {
  total?: number;
  maxScore?: number;
  docs?: Doc[];
}

export interface Doc {
  highlight?: Highlight;
  source?: Source;
}

export interface Highlight {
  title?: string[];
  content?: string[];
}

export interface LastModified {
  name?:     string;
  docCount?: number;
  from?:     Date;
  to?:       Date;
}

export interface Source {
  lastModified?: Date;
  createdDate?: Date;
  title?: string;
  url?: string;
  fileType?: string;
  content?: string;
  keywords?: string[];
  spaceName?:            string;
  spaceKey?:             string;
  createdByDisplayName?: string;
  projectLeadName?: string;
  projectTypeKey?: string;
  docType?: string;
  issueType?: string;
  projectKey?: string;
  assigneeDisplayName?: string;
}

export interface ContentResponseHeader {
  took?: number;
}

export interface IDeepseJSONResponseHeader {
  searchServiceQTime?: number;
  params?: Params;
}

export interface Params {}
