export interface IQueryResultBase {
  total: number;
  values: any[];
  isNewQuery: boolean;
  key?: string;
  error?: string;
  page?: number;
  isPaging?: boolean;
}
