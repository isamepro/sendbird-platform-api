interface IResult {
  title: string;
  firstLineDescription: string;
  secondLineDescription: string;
  url: string;
  previewUrl: string;
  footer: string;
  site: string;
  action: string;
  filename: string;
}

export default IResult;
