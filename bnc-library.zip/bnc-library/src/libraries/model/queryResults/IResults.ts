import IResult from './IResult';
import { IQueryResultBase } from './IQueryResultBase';
interface IResults extends IQueryResultBase {
  total: number;
  values: IResult[];
}

export default IResults;
