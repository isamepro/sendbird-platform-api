import { ITitle } from "../commun/ITitle";
import { IDescription } from "../commun/IDescription";
import { IUrl } from "../commun/IUrl";

/**
 * ******* NOM TEMPORAIRE, LE TEMPS QU'ON REFACTORE LE RESTE
 * Cette interface genrique contient toutes les données d'une recherche faite hors sharepoint.
 *
 * @export
 * @interface ISearchQueryResult
 * @extends {ITitle}
 * @extends {IDescription}
 */
export interface ISearchQueryResult extends ITitle, IDescription {
  url?: IUrl;
  previewUrl?: IUrl;
  image?: string;
  metadata?: string[];
  type?: string;
  fields?: Field;
  json?: string;
}

export interface Field {
  [key: string]: string | Date | undefined | number | boolean | null;
}
