export interface ISearchQueryResultBase {
  total: number;
  isNewQuery: boolean;
  key?: string;
  error?: string;
  page?: number;
  isPaging?: boolean;
}
