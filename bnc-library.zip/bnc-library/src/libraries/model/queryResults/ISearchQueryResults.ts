import { IQueryResultBase } from "./IQueryResultBase";
import { ISearchQueryResult } from "./ISearchQueryResult";
import { ISearchQueryResultBase } from "./ISearchQueryResultBase";

export interface ISearchQueryResults extends ISearchQueryResultBase {
  values: ISearchQueryResult[];
}
