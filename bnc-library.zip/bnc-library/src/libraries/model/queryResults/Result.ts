import IResult from "./IResult";

export default class Result implements IResult {
  public title: string;
  public firstLineDescription: string;
  public secondLineDescription: string;
  public url: string;
  public previewUrl: string;
  public footer: string;
  public site: string;
  public action: string;
  public filename: string;

  constructor(
    title: string,
    firstLineDescription: string,
    secondLineDescription: string,
    url: string,
    previewUrl: string,
    footer: string,
    site: string,
    action: string,
    filename: string
  ) {
    this.title = title;
    this.firstLineDescription = firstLineDescription;
    this.secondLineDescription = secondLineDescription;
    this.url = url;
    this.footer = footer;
    this.site = site;
    this.action = action;
    this.previewUrl = previewUrl;
    this.filename = filename;
  }
}
