export interface IRefinementFilter {
  FilterName: string;
  Value: IRefinementValue;
}

export interface IRefinementResult {
  filterName: string;
  values: IRefinementValue[];
}

export interface IRefinementValue {
  refinementCount: number;
  refinementName: string;
  refinementToken: string;
  refinementValue: string;
}
