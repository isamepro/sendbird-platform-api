import { IATM } from './IATM';
import { BaseSuccursale } from './BaseSuccursale';

export class ATM extends BaseSuccursale implements IATM {

    /***********************************************
     * constructor Produit item
     **********************************************/
    constructor(aTMId: string, withDrawOnly: boolean, exchange: boolean, title: string, open24h7d: boolean,
        printer: boolean, civicNum: string, displayStreetFr: string, displayStreetEn: string, displayCityFr: string,
        displayCityEn: string, postalCode: string, provinceFr: string, provinceEn: string, handicappedAccess: boolean,
        displayIntersectionFr: string, displayIntersectionEn: string, displaySiteFr: string, displaySiteEn: string, transitId?: number) {

        super(title, open24h7d, printer, civicNum, displayStreetFr, displayStreetEn, displayCityFr,
            displayCityEn, postalCode, provinceFr, provinceEn, handicappedAccess,
            displayIntersectionFr, displayIntersectionEn, displaySiteFr, displaySiteEn, transitId);

        this.atmId = aTMId;
        this.withDrawOnly = withDrawOnly;
        this.exchange = exchange;
    }

    public atmId: string;
    public withDrawOnly: boolean;
    public exchange: boolean;
   
}

