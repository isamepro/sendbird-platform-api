import { ISuccursaleHours } from './ISuccursaleHours';
import { IBaseSuccursale } from './IBaseSuccursale';

export class BaseSuccursale implements IBaseSuccursale {

    /***********************************************
     * constructor Produit item
     **********************************************/
    constructor(title: string, open24h7d: boolean,
        printer: boolean, civicNum: string, displayStreetFr: string, displayStreetEn: string, displayCityFr: string,
        displayCityEn: string, postalCode: string, provinceFr: string, provinceEn: string, handicappedAccess: boolean,
        displayIntersectionFr: string, displayIntersectionEn: string, displaySiteFr: string, displaySiteEn: string, transitId?: number) {

        
        this.title = title;
        this.transitId = transitId;
        this.open24h7d = open24h7d;
        this.printer = printer;
        this.civicNum = civicNum;
        this.displayStreetFr = displayStreetFr;
        this.displayStreetEn = displayStreetEn;
        this.displayCityFr = displayCityFr;
        this.displayCityEn = displayCityEn;
        this.postalCode = postalCode;
        this.provinceFr = provinceFr;
        this.provinceEn = provinceEn;
        this.handicappedAccess = handicappedAccess;
        this.displayIntersectionFr = displayIntersectionFr;
        this.displayIntersectionEn = displayIntersectionEn;
        this.displaySiteFr = displaySiteFr;
        this.displaySiteEn = displaySiteEn;
    }

    
    public title: string;
    public transitId?: number;
    public open24h7d: boolean;
    public printer: boolean;
    public civicNum: string;
    public displayStreetFr: string;
    public displayStreetEn: string;
    public displayCityFr: string;
    public displayCityEn: string;
    public postalCode: string;
    public provinceFr: string;
    public provinceEn: string;
    public handicappedAccess: boolean;
    public displayIntersectionFr: string;
    public displayIntersectionEn: string;
    public displaySiteFr: string;
    public displaySiteEn: string;

    public hours: ISuccursaleHours[];
    
    public addHour = (data:ISuccursaleHours) => {
        this.hours.push(data);
    }
    
    public getHoursByType = (type:number):ISuccursaleHours[] => {
        return this.hours.filter(h => {h.hoursTypeId = type;});
    }

}

