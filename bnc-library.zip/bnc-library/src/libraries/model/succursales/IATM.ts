import { IBaseSuccursale } from "./IBaseSuccursale";

export interface IATM extends IBaseSuccursale {
    atmId: string;
    withDrawOnly: boolean;
    exchange: boolean;
}