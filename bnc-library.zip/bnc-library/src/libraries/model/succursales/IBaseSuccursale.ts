import { ISuccursaleHours } from "./ISuccursaleHours";


export interface IBaseSuccursale {
    title: string;
    transitId?: number;
    open24h7d: boolean;
    printer: boolean;
    civicNum: string;
    displayStreetFr: string;
    displayStreetEn: string;
    displayCityFr: string;
    displayCityEn: string;
    postalCode: string;
    provinceFr: string;
    provinceEn: string;
    handicappedAccess: boolean;
    displayIntersectionFr: string;
    displayIntersectionEn: string;
    displaySiteFr: string;
    displaySiteEn: string;
    hours: ISuccursaleHours[];
}

