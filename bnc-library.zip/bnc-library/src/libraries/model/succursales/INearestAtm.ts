import { IFieldSet } from "../commun/stardog/IFieldSet";

export interface INearestAtm {
  inputTransit?: IFieldSet;
  outputStreetAddr?: IFieldSet;
  outputCity?: IFieldSet;
  outputProv?: IFieldSet;
  outputCountry?: IFieldSet;
  outputZipCode?: IFieldSet;
  distance?: IFieldSet;
  atmLocFunct?: IFieldSet;
  atmFunct?: IFieldSet;
}
