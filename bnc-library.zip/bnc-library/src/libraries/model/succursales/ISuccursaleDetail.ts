export interface ISuccursaleDetail {
    detail: string;
    address: string;
    contacts: string;
}
