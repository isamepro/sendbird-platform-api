
export interface ISuccursaleHours {
    id: number;
    hoursTypeId: number;
    dayOfWeek: number;
    openHour1: string;
    closeHour1: string;
    openHour2: string;
    closeHour2: string;
    openHour3: string;
    closeHour3: string;
    dayOfWeekEn: string;
    dayOfWeekFr: string;
    hoursTypeEn: string;
    hoursTypeFr: string;
}