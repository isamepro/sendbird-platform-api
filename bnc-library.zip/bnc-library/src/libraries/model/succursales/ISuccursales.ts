import { ITransit } from "./ITransit";
import { IATM } from "./IATM";

export interface ISuccursales {
    values: (ITransit | IATM)[];
    totalCount:number;
}