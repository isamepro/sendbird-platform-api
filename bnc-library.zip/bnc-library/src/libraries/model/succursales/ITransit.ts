import { IBaseSuccursale } from "./IBaseSuccursale";

export interface ITransit extends IBaseSuccursale {
    displayNameFr: string;
    displayNameEn: string;
    phone: string;
    fax: string;
    aTMCount: number;
    exchangeOffice: boolean;
    transitTypeId: number;
    transitTypeFr: string;
    transitTypeEn: string;

}