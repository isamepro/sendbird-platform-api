import { ISuccursaleDetail } from "./ISuccursaleDetail";
import { TooltipHost } from "office-ui-fabric-react";

export class SuccursaleDetail implements ISuccursaleDetail {
    public detail: string;
    public address: string;
    public contacts: string;

    constructor(detail: string, address: string, contacts: string) {
        this.address = address;
        this.detail = detail;
        this.contacts=contacts;
    }
}