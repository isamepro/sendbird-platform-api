import { ISuccursaleHours } from "./ISuccursaleHours";

export class SuccursaleHours implements ISuccursaleHours {

    public id: number;
    public hoursTypeId: number;
    public dayOfWeek: number;
    public openHour1: string;
    public closeHour1: string;
    public openHour2: string;
    public closeHour2: string;
    public openHour3: string;
    public closeHour3: string;
    public dayOfWeekEn: string;
    public dayOfWeekFr: string;
    public hoursTypeEn: string;
    public hoursTypeFr: string;

    constructor(id: number, hoursTypeId: number, dayOfWeek: number, openHour1: string, closeHour1: string,
        openHour2: string, closeHour2: string, openHour3: string, closeHour3: string,
        dayOfWeekEn: string, dayOfWeekFr: string, hoursTypeEn: string, hoursTypeFr: string) {
        this.id = id;
        this.hoursTypeId = hoursTypeId;
        this.dayOfWeek = dayOfWeek;
        this.openHour1 = openHour1;
        this.closeHour1 = closeHour1;
        this.openHour2 = openHour2;
        this.closeHour2 = closeHour2;
        this.openHour3 = openHour3;
        this.closeHour3 = closeHour3;
        this.dayOfWeekEn = dayOfWeekEn;
        this.dayOfWeekFr = dayOfWeekFr;
        this.hoursTypeEn = hoursTypeEn;
        this.hoursTypeFr = hoursTypeFr;
    }

}