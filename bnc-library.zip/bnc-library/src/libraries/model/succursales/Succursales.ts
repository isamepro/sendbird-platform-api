import { ISuccursales } from "./ISuccursales";
import { ITransit } from "./ITransit";
import { IATM } from "./IATM";


export class Succursales implements ISuccursales {

    constructor(values:  (ITransit | IATM)[], totalCount: number) {
        this.values = values;
        this.totalCount = totalCount;
    }

    public values:  (ITransit | IATM)[];
    public totalCount: number;
   
}