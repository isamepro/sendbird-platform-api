import { ITransit } from './ITransit';
import { BaseSuccursale } from './BaseSuccursale';

export class Transit extends BaseSuccursale implements ITransit {

    /***********************************************
     * constructor Produit item
     **********************************************/
    constructor(displayNameFr: string, displayNameEn: string, phone: string, fax: string, aTMCount: number, exchangeOffice: boolean,
        transitTypeId: number, transitTypeFr: string, transitTypeEn: string, title: string, open24h7d: boolean,
        printer: boolean, civicNum: string, displayStreetFr: string, displayStreetEn: string, displayCityFr: string,
        displayCityEn: string, postalCode: string, provinceFr: string, provinceEn: string, handicappedAccess: boolean,
        displayIntersectionFr: string, displayIntersectionEn: string, displaySiteFr: string, displaySiteEn: string, transitId?: number) {

        super(title, open24h7d, printer, civicNum, displayStreetFr, displayStreetEn, displayCityFr,
            displayCityEn, postalCode, provinceFr, provinceEn, handicappedAccess,
            displayIntersectionFr, displayIntersectionEn, displaySiteFr, displaySiteEn, transitId);

        this.displayNameFr = displayNameFr;
        this.displayNameEn = displayNameEn;
        this.phone = phone;
        this.fax = fax;
        this.aTMCount = aTMCount;
        this.exchangeOffice = exchangeOffice;
        this.transitTypeId = transitTypeId;
        this.transitTypeFr = transitTypeFr;
        this.transitTypeEn = transitTypeEn;
    }

    public displayNameFr: string;
    public displayNameEn: string;
    public phone: string;
    public fax: string;
    public aTMCount: number;
    public exchangeOffice: boolean;
    public transitTypeId: number;
    public transitTypeFr: string;
    public transitTypeEn: string;




}

