export interface INatBotUserSettings {
  languageCode: number;
  notificationTypes: INotificationPreference[];
}

export interface INotificationPreference {
  categoryName: string;
  optIn: number;
}
