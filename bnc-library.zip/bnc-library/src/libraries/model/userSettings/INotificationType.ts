export interface INotificationType {
  name: string;
  labelFr: string;
  labelEn: string;
  descriptionFr: string;
  descriptionEn: string;
  isActive: boolean;
}
