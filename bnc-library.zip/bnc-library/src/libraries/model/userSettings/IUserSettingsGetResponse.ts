import {INatBotUserSettings} from "./INatBotUserSettings";
import {INotificationType} from "./INotificationType";


interface IGetResponse {
  requestStatus: boolean;
}

export interface IUserSettingsGetResponse extends IGetResponse{
    natBotUserSettings: INatBotUserSettings;
}

export interface INotificationTypesGetResponse extends IGetResponse {
  notificationTypes: INotificationType[];
}
