import { EnvironmentType } from '@microsoft/sp-core-library';
import MapServiceMock from './mapService/MapServiceMock';
import { SourcesService } from '../model/commun/SourcesService';
import PersonaRawDataServiceO365 from './profil/rawDataServices/PersonaRawDataServiceO365';
import PersonaRawDataServiceStarDog from './profil/rawDataServices/PersonaRawDataServiceStarDog';
import { IRawDataService } from '../interfaces/commun/IRawDataService';
import { IMapService } from '../interfaces/map/IMapService';
import { MapService, IHubServiceFactoryContext, IRawServiceFactoryContext, IFactoryContext } from '../..';
import PersonaRawDataServiceMock from './profil/rawDataServices/PersonaRawDataServiceMock';
import PersonaRawDataServiceSP from './profil/rawDataServices/PersonaRawDataServiceSP';

/**
 *
 *
 * @export
 * @class EnterpriseServicesBNCFactory
 * @extends {PersonasBaseService}
 * @implements {IEnterpriseServicesBNCFactory}
 */
export class EnterpriseServicesBNCFactory {
	/**
   *
   *
   * @static
   * @param {(IHubServiceFactoryContext | IRawServiceFactoryContext)} context
   * @returns {IRawDataService}
   *
   * @memberOf EnterpriseServicesBNCFactory
   */
  public static getPersonaRawService(context: IHubServiceFactoryContext | IRawServiceFactoryContext, source?: SourcesService): IRawDataService {
    if (!context) throw new Error('Context is need in getRawService().');
    if (context.environmentType === EnvironmentType.Local) return new PersonaRawDataServiceMock(context);
    switch (source) {
      case SourcesService.O365:
        return new PersonaRawDataServiceO365(context);

			case SourcesService.StarDog:
            return new PersonaRawDataServiceStarDog(context);

         case SourcesService.SharePoint:
            return new PersonaRawDataServiceSP(context);

      case SourcesService.Debug:
        return new PersonaRawDataServiceMock(context);

      default:
        return new PersonaRawDataServiceO365(context);
    }
  }
	/*************************************************************************************
    *
   *
   * @static
   * @param {(IHubServiceFactoryContext | IFactoryContext)} context
   * @returns {IRawDataService}
   *
   * @memberOf EnterpriseServicesBNCFactory
   ************************************************************************************/
  public static getMapService = (context: IHubServiceFactoryContext | IFactoryContext): IMapService => {
    return context.environmentType === EnvironmentType.Local ? new MapServiceMock() : new MapService(context.spfxContext, context.spfxContext.serviceScope);
  }

}
