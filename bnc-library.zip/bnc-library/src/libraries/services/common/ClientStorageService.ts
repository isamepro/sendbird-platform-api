import { bncTenantPropertiesNamespace } from "../../constants/Constants";

export interface IStoreObject<T> {
  value: T;
  expiration: string;
}

export interface KeyValuePair {
  key: string;
  value: any;
}

export enum StorageType {
  localStorage = 1,
  sessionStorage
}

export class ClientStorageService {
  private static localStore = window.localStorage;
  private static sessionStore = window.sessionStorage;

  /**
   * Retrieve an item from the storage
   * @param key
   * @param type
   */
  public static get<T>(key: string, type: StorageType = StorageType.sessionStorage): T {
    // Check if local storage exists
    if (!this.localStore && type === StorageType.localStorage) {
      return undefined;
    }

    // Check if session storage exists
    if (!this.sessionStore && type === StorageType.sessionStorage) {
      return undefined;
    }

    // Retrieve object and check if it exists
    const o: string = type === StorageType.localStorage ? this.localStore.getItem(this.getKey(key)) : this.sessionStore.getItem(this.getKey(key));
    if (o === null) {
      return undefined;
    }

    const storeObj: IStoreObject<T> = JSON.parse(o);
    if (new Date(storeObj.expiration) <= new Date()) {
      this.delete(this.getKey(key), type);
      return undefined;
    } else {
      return storeObj.value as T;
    }
  }

  /**
   * Create a new item in the store
   * @param key
   * @param o
   * @param type
   * @param expire
   */
  public static put(key: string, o: any, type: StorageType = StorageType.sessionStorage, expire?: Date): void {
    if (this.localStore && type === StorageType.localStorage) {
      this.localStore.setItem(this.getKey(key), this.createPersistable(o, expire));
    }

    if (this.sessionStore && type === StorageType.sessionStorage) {
      this.sessionStore.setItem(this.getKey(key), this.createPersistable(o, expire));
    }
  }

  /**
   * Delete an item from the storage
   * @param key
   * @param type
   */
  public static delete(key: string, type: StorageType = StorageType.sessionStorage): void {
    if (this.localStore && type === StorageType.localStorage) {
      this.localStore.removeItem(this.getKey(key));
    }

    if (this.sessionStore && type === StorageType.sessionStorage) {
      this.sessionStore.removeItem(this.getKey(key));
    }
  }

  /**
   * Delete all keys starting with a string
   *
   * @param key
   * @param type
   */
  public static clear(key: string, type: StorageType = StorageType.sessionStorage): any {
    if (this.localStore && type === StorageType.localStorage) {
      let removeKeys = [];
      for (let i = 0; i < this.localStore.length; i++) {
        const crntKey = localStorage.key(i);

        if (crntKey.indexOf(this.getKey(key)) === 0) {
          removeKeys.push(crntKey);
        }
      }
      // Remove all the keys
      for (const rKey of removeKeys) {
        this.localStore.removeItem(rKey);
      }
    }

    if (this.sessionStore && type === StorageType.sessionStorage) {
      let removeKeys = [];
      for (let i = 0; i < this.sessionStore.length; i++) {
        const crntKey = this.sessionStore.key(i);

        if (crntKey.indexOf(this.getKey(key)) === 0) {
          removeKeys.push(crntKey);
        }
      }
      // Remove all the keys
      for (const rKey of removeKeys) {
        this.sessionStore.removeItem(rKey);
      }
    }
  }

  /**
   * Creates a presistable object for the store
   * @param o
   * @param expire
   */
  private static createPersistable(o: any, expire?: Date): string {
    if (typeof expire === "undefined") {
      expire = new Date();
      // 5 minutes default value
      expire.setTime(expire.getTime() + 120 * 1000);
    }

    return JSON.stringify({ expiration: expire, value: o });
  }

  /**
   * Creates a presistable object for the store
   * @param o
   * @param expire
   */
  private static getKey(key: string): string {
    return `${bncTenantPropertiesNamespace}:${key}`;
  }
}
