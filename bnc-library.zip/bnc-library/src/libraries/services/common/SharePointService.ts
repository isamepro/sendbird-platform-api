import { SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';
import { ConsoleListener, Logger, LogLevel } from "@pnp/logging";
import _ from "lodash";

import { ISharePointService } from '../../interfaces/commun/ISharePointService';
import { sp, SearchQuery, SearchResults, SPRest, PermissionKind, ItemAddResult, Web, Fields } from '@pnp/sp';
import { IWebPartContext } from '@microsoft/sp-webpart-base';
import { Guid } from '@microsoft/sp-core-library';
import * as moment from 'moment';
import { IQueryRequest } from '../../model/commun/IQueryRequest';
import { IQueryResult } from '../../model/commun/IQueryResult';
import { ISearchResult } from '../../model/commun/ISearchResult';
import { IResult } from '../../model/commun/IResult';
import { dateAdd } from '@pnp/common';
import { SPPermission } from '@microsoft/sp-page-context';
import { Subscription } from '@pnp/sp/src/subscriptions';
import { IWebhook } from '../../interfaces/commun/IWebhook';

export interface ITenantProperty {
  Value: string;
  Description?: string;
  Comment?: string;
}

export class SharePointService implements ISharePointService {
  private initialSearchResult: SearchResults = null;
  private loginNamePrefix = 'i:0#.f|membership|';
  private context: IWebPartContext;
  private enableQueryRules: boolean;
  private localPnPSetup: SPRest;

  constructor(spfxContext: IWebPartContext) {
    // Setup the PnP JS instance
    this.context = spfxContext;
    Logger.subscribe(new ConsoleListener());

    sp.setup({
      spfxContext: this.context,
    });

    this.localPnPSetup = sp.configure(
      {
        headers: {
          Accept: 'application/json; odata=nometadata',
        },
      },
      this.context.pageContext.web.absoluteUrl,
    );
  }

  public async search(queryRequest: IQueryRequest): Promise<IQueryResult> {
    let results: IQueryResult = { totalCount: 0, results: [] };

    if (queryRequest === undefined || queryRequest === null) {
      Logger.write('La query request est vide ou null.', LogLevel.Error);
      return results;
    }

    let selectedProperties: string[];
    let query: string = queryRequest.query;
    let searchQuery: SearchQuery = {};

    searchQuery.ClientType = 'ContentSearchRegular';
    searchQuery.Querytext = query;
    // Disable query rules by default if not specified
    searchQuery.EnableQueryRules = this.enableQueryRules ? this.enableQueryRules : false;
    searchQuery.EnableStemming = true;

    try {
      if (queryRequest.properties && queryRequest.properties.length > 0) {
        selectedProperties = queryRequest.properties;
      }

      if (queryRequest.queryTemplate) {
        searchQuery.QueryTemplate = queryRequest.queryTemplate;
      }

      if (queryRequest.sourceId !== undefined && queryRequest.sourceId) {
        searchQuery.SourceId = queryRequest.sourceId;
      }

      searchQuery.RowLimit = queryRequest.rowLimit;
      searchQuery.SelectProperties = selectedProperties;
      searchQuery.EnableStemming = true;

      // TODO: A Garder ???
      let page = 1;

      if (!this.initialSearchResult || page == 1) {
        this.initialSearchResult = await this.localPnPSetup.search(searchQuery);
      }

      const allItemsPromises: any[] = [];

      if (this.initialSearchResult.RawSearchResults.PrimaryQueryResult) {
        let searchResultsSecondary = this.initialSearchResult;
        if (page > 1) {
          searchResultsSecondary = await this.initialSearchResult.getPage(page, queryRequest.rowLimit);
        }

        const resultRows = searchResultsSecondary.RawSearchResults.PrimaryQueryResult.RelevantResults.Table.Rows;
        // Map search results
        _.forEach(resultRows, result => {
          let res: ISearchResult = {};

          result.Cells.map(item => {
            res[item.Key] = item.Value;
          });

          allItemsPromises.push(res);
        });
        results.results = allItemsPromises;
        results.totalCount = this.initialSearchResult.TotalRows;
      }

      return results;
    } catch (error) {
      Logger.write('[SearchService.search()]: Error: ' + error, LogLevel.Error);
      throw new Error(error);
    }
  }

  public getListIdByName(listName: string): Promise<string> {
    return new Promise<string>((resolve, reject) => {
      sp.web.lists
        .getByTitle(listName).get().then(list => {
          resolve(list.Id);
        });
    });
  }

  public getWebhook(listName: string, webhookUrl: string): Promise<IWebhook> {
    return (Guid.tryParse(listName)) ? this.getWebhookIdByListGuid(listName, webhookUrl) : this.getWebhookIdByListName(listName, webhookUrl);
  }

  private getWebhookIdByListName(listName: string, webhookUrl: string): Promise<IWebhook> {
    return this.getListIdByName(listName).then(listId => {
      return this.getWebhookIdByListGuid(listId, webhookUrl);
    });
  }

  private getWebhookIdByListGuid(listGuid: string, webhookUrl: string): Promise<IWebhook> {
    return new Promise<IWebhook>((resolve, reject) => {
      sp.web.lists
        .getById(listGuid.toString())
        .subscriptions.get()
        .then(webhooks => {
          webhooks.forEach(webhook => {
            if (webhook.notificationUrl == webhookUrl) {
              resolve({webhookId:webhook.id,expirationDate:webhook.expirationDateTime});
            }
          });
          resolve(null);
        })
        .catch(error => Logger.write(`Erreur pour ajouté le Webhook à la liste ${listGuid} avec un post sur l'url . Message: ${error}.`, LogLevel.Error));
    });
  }

  public addWebhook(listName: string, webhookUrl: string): void {
    return (Guid.tryParse(listName)) ? this.addWebhookByListGuid(listName, webhookUrl) : this.addWebhookByListName(listName, webhookUrl);
  }

  private addWebhookByListName(listName: string, webhookUrl: string): void {

    this.getListIdByName(listName).then(listId => {
      this.addWebhookByListGuid(listId, webhookUrl);
    });
  }

  private addWebhookByListGuid(listGuid: string, webhookUrl: string): void {
    if (!this.userIsAuthorizedToManageContent(listGuid)) return;

    if (!webhookUrl) {
      Logger.write(`Impossible de recupérer la clé de config WebHookUrl sur le site ${webhookUrl}. La config existe mais la clé n'y est pas.`);
      return;
    }

    let formatDate: string = this.setNewDate();
    sp.web.lists
      .getById(listGuid.toString())
      .subscriptions.add(webhookUrl, formatDate)
      .then(_sucess => {
        Logger.write(`Webhook ajouté à la liste ${listGuid} avec un post sur l'url ${webhookUrl}.`, LogLevel.Info);
      })
      .catch(error => Logger.write(`Erreur pour ajouté le Webhook à la liste ${listGuid} avec un post sur l'url ${webhookUrl}. Message: ${error}.`, LogLevel.Error));
  }

  public updateWebhook(listName: string, webhookId: string): void {
    return (Guid.tryParse(listName)) ? this.updateWebhookByListGuid(listName, webhookId) : this.updateWebhookByListName(listName, webhookId);
  }

  private updateWebhookByListName(listName: string, webhookId: string): void {

    this.getListIdByName(listName).then(listId => {
      this.updateWebhookByListGuid(listId, webhookId);
    });
  }

  private updateWebhookByListGuid(listGuid: string, webhookId: string): void {
    if (!this.userIsAuthorizedToManageContent(listGuid)) return;

    if (!webhookId) {
      Logger.write(`Impossible de recupérer la clé de config WebHookUrl sur le site ${webhookId}. La config existe mais la clé n'y est pas.`);
      return;
    }

    sp.web.lists.getById(listGuid.toString()).subscriptions.getById(webhookId).get().then((webhook) => {
      const expirationDateTime = moment(webhook.expirationDateTime);
      if (expirationDateTime.diff(moment()) <= 0) {
        let formatDate: string = this.setNewDate();
        sp.web.lists.getById(listGuid.toString()).subscriptions.getById(webhookId).update(formatDate)
          .then(_sucess => {
            Logger.write(`Webhook a ete mise a jour dans la liste ${listGuid} avec un post sur l'id ${webhookId}.`, LogLevel.Info);
          })
          .catch(error => Logger.write(`Erreur pour la mise a jour du Webhook à la liste ${listGuid} avec un post sur l'id ${webhookId}. Message: ${error}.`, LogLevel.Error));
      }
    });
  }

  public addFieldToCurrentList(fieldName: string, fieldDisplayName: string): void {
    if (fieldName === undefined || fieldName === '') throw new Error('Vous devez définir une colonne à rechercher dans la collection de site.');
    let listId: string = this.getCurrentListId();
    sp.web.lists
      .getById(listId)
      .fields.getByInternalNameOrTitle(fieldName)
      .get()
      .then(_findField => {
        Logger.write(`Field ${fieldName} already exist in current library!`, LogLevel.Info);
      })
      .catch(_errorNotFoundField => {
        //get field from site columns
        this.getFieldFromSiteColection(fieldName)
          .then(field => {
            this.addFieldtoLibrary(sp.web.lists.getById(listId).fields, field, listId, fieldDisplayName);
            Logger.write(`Field ${fieldName} added to current library!`, LogLevel.Info);
          })
          .catch(error => {
            Logger.write(`Erreur dans l'ajout de la colonne ${fieldName}! \n Message d'erreur : ${error}`, LogLevel.Error);
          });
      });
  }

  public getCurrentListId(): string {
    return this.context.pageContext.list.id.toString();
  }

  public getFieldFromSiteColection(fieldName: string): Promise<any> {
    if (fieldName === undefined || fieldName === '') return Promise.reject('Vous devez définir une colonne à rechercher dans la collection de site.');
    return new Promise<any>((resolve, reject) => {
      try {
        sp.web.fields
          .getByInternalNameOrTitle(fieldName)
          .get()
          .then(field => {
            resolve(field);
          })
          .catch(error => {
            return reject(error);
          });
      } catch (e) {
        return reject(e);
      }
    });
  }

  private addFieldtoLibrary(listFields: Fields, field: any, listId: any, displayName: string): void {

    const internalName: string = field.InternalName;
    let schemaXml: string = field.SchemaXml;

    schemaXml = schemaXml.replace(displayName, internalName);
    if (listFields !== undefined && schemaXml !== undefined) {
      listFields.createFieldAsXml(schemaXml).then((newField) => {
        sp.web.lists
          .getById(listId)
          .fields.getByInternalNameOrTitle(field.InternalName).update({
            'Title': displayName
          }).catch((error) => {
            console.log(error);
          });
      });
    }
  }

  private setNewDate(): string {
    const dateNow: Date = new Date();
    const dateAddSixMonth: Date = dateAdd(dateAdd(dateNow, 'month', 6), 'day', -5);
    const formatDate: string = moment(dateAddSixMonth).format('YYYY-MM-DD') + 'T00:00:00+00:00';
    return formatDate;
  }

  public async getFileContent(webUrl: string, listname: string, filename: string): Promise<string> {
    if (webUrl === undefined || webUrl === null || filename === '' || filename === null) {
      Logger.write('SharePointService.getFileContent: Url ou filename est vide. Impossible de récupérer le fichier de Config.', LogLevel.Error);
      return new Promise<string>(reject => {
        reject(undefined);
      });
    }

    try {
      return new Promise<string>((resolve) => {
        let web = new Web(webUrl);

        const webServerRelativeUrl: string = this.getWebRelativeUrl(webUrl);

        web
          .getFolderByServerRelativeUrl(`${webServerRelativeUrl}/${listname}`)
          .files.getByName(filename)
          .getText()
          .then((text: string) => {
            resolve(text);
          });
      });
    } catch (error) {
      Logger.write("Une errreur s'est produite dans la recuperation du contenu du fichier. Error: " + error, LogLevel.Error);

      return new Promise<string>(reject => {
        reject(undefined);
      });
    }
  }

  public listExists(listName: string): Promise<boolean> {
    if (listName === undefined || listName === null) {
      Logger.write('SharePointService.listExists: Le nom de la liste est vide.', LogLevel.Error);
      return new Promise(reject => {
        reject(false);
      });
    }

    return new Promise((resolve, reject) => {
      this.localPnPSetup.web.lists
        .getByTitle(listName)
        .get()
        .then(() => {
          resolve(true);
        })
        .catch(() => {
          resolve(false);
        });
    });
  }
  /**
   * Check if the current user is authorize to manage content
   * Return true if yes.
   */
  public async userIsAuthorizedToManageContent(guid: string): Promise<boolean> {
    return new Promise<boolean>((resolve, reject) => {
      this.localPnPSetup.web.lists
        .getById(guid)
        .userHasPermissions('i:0#.f|membership|' + this.context.pageContext.user.loginName, PermissionKind.AddListItems | PermissionKind.EditListItems | PermissionKind.ManageWeb)
        .then(perm => {
          resolve(perm);
        })
        .catch(error => {
          Logger.writeJSON("Une erreur s'est produite dans la vérification des droits de l'usager. Erreur: " + error, LogLevel.Error);
          reject(false);
        });
    });
  }

  public async isSiteOwner(): Promise<boolean> {
    return new Promise<boolean>((resolve, reject) => {
      this.localPnPSetup.web.getCurrentUserEffectivePermissions()
        .then(perm => {
          const permission = new SPPermission(perm);
          const isOwner = permission.hasPermission(SPPermission.manageWeb);
          resolve(isOwner);
        })
        .catch(error => {
          Logger.writeJSON("Une erreur s'est produite dans la vérification des droits de l'usager. Erreur: " + error, LogLevel.Error);
          reject(false);
        });
    });
  }

  public async isUserInOwnerGroup(loginName: string): Promise<boolean> {
    if (!loginName)
      return;

    const users: any = await sp.web.associatedOwnerGroup.users.get();
    return !!users.find(user => user.LoginName.toLowerCase() == `${this.loginNamePrefix}${loginName}`.toLowerCase());
  }

  public async addUserToOwnerGroup(loginName): Promise<boolean> {
    if (!loginName)
      return;

    return new Promise<boolean>((resolve, reject) => {
      this.localPnPSetup.web.associatedOwnerGroup.users.add(`${this.loginNamePrefix}${loginName}`).
        then(() => {
          resolve(true);
        })
        .catch(error => {
          Logger.writeJSON("Une erreur s'est produite dans la vérification des droits de l'usager. Erreur: " + error, LogLevel.Error);
          reject(false);
        });
    });
  }

  public getWebRelativeUrl(url: string): string {
    return url.replace(/https?:\/\/[^\/]+/i, "");
  }

  public getTenantProperty(value: string): Promise<any> {
    return new Promise<string>((resolve: (value: string) => void, reject: (error: any) => void): void => {
      this.context.spHttpClient
        .get(`${this.context.pageContext.web.absoluteUrl}/_api/web/GetStorageEntity('${value}')`, SPHttpClient.configurations.v1)
        .then((res: SPHttpClientResponse) => {
          return res.json();
        })
        .then((tenantProperty: ITenantProperty) => {
          resolve(JSON.parse(tenantProperty.Value));
        });
    });
  }
}

