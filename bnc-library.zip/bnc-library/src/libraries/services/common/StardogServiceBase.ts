import { Logger, LogLevel, ConsoleListener } from '@pnp/logging';
import * as _ from 'lodash';
import { HttpClient, IHttpClientOptions } from '@microsoft/sp-http';

import { WebPartContext } from '@microsoft/sp-webpart-base';
import { IHubServiceFactoryContext } from '../../interfaces/context/IHubServiceFactoryContext';

/*************************************************************************************
 * @export
 * @class PersonasBaseService
 *************************************************************************************/
export default class StardogServiceBase {
  public context: IHubServiceFactoryContext;
  protected spfxContext: WebPartContext;
  protected language: string;
  protected subscriptionkey: string;
  private baseServiceUrl: string;

	/*************************************************************************************
   * Creates an instance of StardogServiceBase.
   * @param {IHubServiceFactoryContext} context
   *************************************************************************************/
  constructor( context: IHubServiceFactoryContext ) {
    const consoleListener = new ConsoleListener();
    Logger.subscribe( consoleListener );

    this.context = context;
    this.spfxContext = context.spfxContext;
    this.language = !context.language  ? 'fr' : context.language;

    if (!context.serviceDomainUrl) throw new Error (`L'Url de service est manquant. SVP, contacter l'admistrateur.`);
    if (!context.subscriptionkey) throw new Error (`L'API Key est manquante. SVP, contacter l'admistrateur.`);

    this.subscriptionkey = context.subscriptionkey;
    this.baseServiceUrl = `${context.serviceDomainUrl}stardog/Profil_Social/`;
  }

  public getData(query: string): Promise<any> {
    return new Promise<any>(async (resolve, reject) => {
      if (!query) {
        return reject(`[StardogServiceBase::getData()]: Error: 'query' parameter can not be empty `);
      }
      this.validatedServiceContext(reject);

      // Make the call to the Api Management
      const url = `${this.baseServiceUrl}query?query=${query}`;
      this.getCurrentUserToken().then((token: any) => {

        this.spfxContext.httpClient
          .get(url, HttpClient.configurations.v1, this.getHeaders(token))
          .then((data): void => {
              return resolve(data);
            },
            (error: any): void => {
              let message = `[StarDog StardogServiceBase.setTopicCompetenciessRawData()]: Error: '${error}' `;
              return reject(message);
            }
          );
      });
    });
  }

  /********************************************************************************************************
   * @param {(reason?: any) => void} reject  validate parameters , if not well format reject promise
   ********************************************************************************************************/
  private validatedServiceContext(reject: (reason?: any) => void) {
    let errorMessage: string = '';
    if (!this.baseServiceUrl) {
      errorMessage = `[validatedServiceContext()]: Error: 'Service url not found' `;
      this.rejectMessageLog(reject, errorMessage);
    }
    if (!this.spfxContext) {
      errorMessage = `[validatedServiceContext()]: Error: 'webpart context not found' `;
      this.rejectMessageLog(reject, errorMessage);
    }
    if (!this.language) {
      errorMessage = `[validatedServiceContext()]: Error: 'Language  not found' `;
      this.rejectMessageLog(reject, errorMessage);
    }
    if (!this.subscriptionkey) {
      errorMessage = `[validatedServiceContext()]: Error: 'subscriptionkey  not found' `;
      this.rejectMessageLog(reject, errorMessage);
    }
  }

  /*********************************************************************************************************************
   * @returns {Promise<string>} : Current user tokens
   **********************************************************************************************************************/
  protected getCurrentUserToken = (): Promise<string> => {
    if ( !this.spfxContext ) throw new Error( 'getCurrentUserToken() need webpart context' );
    let resource = `https://${ window.location.hostname }`;
    return new Promise<string>( ( resolve, reject ) => {
      this.spfxContext.aadTokenProviderFactory
        .getTokenProvider()
        .then( ( provider: any ) => {
          provider
            .getToken( resource, true )
            .then( ( token: string ) => {
              resolve( token );
            } )
            .catch( ( error: string ) => {
              reject( error );
            } );
        } )
        .catch( ( error: string ) => {
          reject( error );
        } );
    } );
  }


  protected rejectMessageLog( reject: ( reason?: any ) => void, errorMessage: string ) {
    Logger.write( errorMessage, LogLevel.Error );
    return reject( errorMessage );
  }

	/********************************************************************************************************
   * @param {string} token get user baarer token
   * @returns return all headers to query data
   ********************************************************************************************************/
  private getHeaders(token: string) : IHttpClientOptions{
    const requestHeaders: Headers = new Headers();
    requestHeaders.append('Content-type', 'application/json');
    requestHeaders.append('Cache-Control', 'no-cache');
    requestHeaders.append('Ocp-Apim-Subscription-Key', this.subscriptionkey);
    requestHeaders.append('Authorization', `Bearer ${token}`);

    return {
      headers: requestHeaders
    };
  }
}
