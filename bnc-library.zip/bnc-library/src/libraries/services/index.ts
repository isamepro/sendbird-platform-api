// Common
export { TenantPropertiesManagerService, ITenantPropertiesManagerService } from "./sharePoint/TenantPropertiesManagerService";

// SharePoint Service
export { SharePointService, ISharePointService, ITenantProperty } from './sharePoint/SharePointService';

// Succursales Service
export { SuccursalesService } from './succursales/SuccursalesService';
export { ISuccursalesServiceSetting, ISuccursalesService } from './succursales/SuccursalesService.types';

// Taxonomy Service
export { TaxonomyService, ITaxonomyService } from './taxonomy/TaxonomyService';

// Profil Social Service
export { ProfilSocialService, IProfilSocialService } from './profilSocial/ProfilSocialService';
export { CompetencyStatus, ManageCompetencyStatus } from './profilSocial/ProfilSocialService.status';
export { IExtendedProfil, IProfilData, IProfilDataItem, DataSource,DataOperationQueryType } from './profilSocial/ProfilSocialService.types';
export { IWebhook } from '../interfaces/commun/IWebhook';
// Telemetry Service
export { ITelemetryContext, ITelemetryService, TelemetryEventName } from './telemetry/TelemetryService.types';
export { TelemetryService } from './telemetry/TelemetryService';
export { ServiceScope } from '@microsoft/sp-core-library';
