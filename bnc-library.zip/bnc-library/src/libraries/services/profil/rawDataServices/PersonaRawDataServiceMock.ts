
import PersonasBaseService from "../searchPersonasServices/PersonasBaseService";
import { IRawDataService, ISearchPersonas, IPresenceInfo, IHubServiceFactoryContext, ITagActionData } from "../../../..";
import { IPaging } from "../../../model/paging/IPaging";
import { User } from "@microsoft/microsoft-graph-types";
import { ResultsApplicationBNCStarDog, ResultsLanguagesStardog, ResultsCertificationStardog } from "../../../model/Profil/stardog/IObjectsBNCStardog";
import  ApplicationBNCStarDog_MOCK from "./fake/jsonMockFiles/applicationsBNC.json";
import Competencies_MOCK from "./fake/jsonMockFiles/competencies.json";
import LanguageBNCStarDog_MOCK from "./fake/jsonMockFiles/languesBNC.json";
import CertificationBNCStarDog_MOCK from "./fake/jsonMockFiles/certificationsBNC.json";


export default class PersonaRawDataServiceMock extends PersonasBaseService
  implements IRawDataService {
  private applicationBNCStarDog_MOCK;
  private competenciesStarDog;
  private languageBNCStarDog_MOCK;
  private certificationBNCStarDog_MOCK;
  private data:Map<string, string> = new Map<string, string>();

  /**
   *Constructor
   */
  constructor(context: IHubServiceFactoryContext) {
    super(context);
    this.applicationBNCStarDog_MOCK = ApplicationBNCStarDog_MOCK.results;
    this.competenciesStarDog = Competencies_MOCK.results;
    this.languageBNCStarDog_MOCK = LanguageBNCStarDog_MOCK.results;
    this.certificationBNCStarDog_MOCK = CertificationBNCStarDog_MOCK.results;
  }


  public addPropertieValue(tagValues: ITagActionData): Promise<any> {
    this.data.set(tagValues.name,tagValues.status);
    return new Promise<any>(async (resolve) => {
      resolve(this.data);
    });
  }

  public getPresence(email: string): Promise<IPresenceInfo> {
    throw new Error("Method not implemented.");
  }

  public getPeoplesByEmail(email: string, paging: IPaging): Promise<User[]> {
    throw new Error("Method not implemented.");
  }

  public getPersonaRawData(email: string): Promise<any> {
    throw new Error("Method not implemented.");
  }

  public getPersonasRawData(
    keywords: string,
    paging?: IPaging
  ): Promise<ISearchPersonas> {
    throw new Error("Method not implemented.");
  }

  public getCompetenciesRawData(email: any): Promise<any> {
    return new Promise<any>(async (resolve) => {
      resolve(this.competenciesStarDog);
    });
  }

  public getSugestCompetenciesRawData(email: string): Promise<any> {
    return new Promise<any>(async (resolve) => {
      resolve(this.competenciesStarDog);
    });
  }

  public setPropertieValue(tagValues: ITagActionData): Promise<any> {
    this.data[tagValues.name] = tagValues.status;
    return new Promise<any>(async (resolve) => {
      return resolve(true);
    });
  }

  public getApplicationBNCRawData(email: string): Promise<any> {
    return new Promise<any>(async (resolve) => {
      resolve(this.applicationBNCStarDog_MOCK);
    });
  }

  public getLanguagesRawData(email: string): Promise<ResultsLanguagesStardog> {
    return new Promise<ResultsLanguagesStardog>(async (resolve) => {
      resolve(this.languageBNCStarDog_MOCK);
    });
  }
  public getCertificationsRawData(email: string): Promise<ResultsCertificationStardog> {
    return new Promise<ResultsCertificationStardog>(async (resolve) => {
      resolve(this.certificationBNCStarDog_MOCK);
    });
  }

}
