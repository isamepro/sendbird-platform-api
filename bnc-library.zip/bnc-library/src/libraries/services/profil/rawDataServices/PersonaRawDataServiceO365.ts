import { Logger, LogLevel } from "@pnp/logging";
import * as _ from "lodash";
import {
  ODataVersion,
  SPHttpClient,
  MSGraphClient,
  SPHttpClientConfiguration,
  SPHttpClientResponse
} from "@microsoft/sp-http";
import * as MicrosoftGraph from "@microsoft/microsoft-graph-types";
import PersonasBaseService from "../searchPersonasServices/PersonasBaseService";
import { IRawDataService } from "../../../interfaces/commun/IRawDataService";
import {
  IHubServiceFactoryContext,
  IPresenceInfo,
  ITagActionData
} from "../../../..";
import { HttpClient } from '@microsoft/sp-http';
import { IPaging } from "../../../model/paging/IPaging";
import { ResultsApplicationBNCStarDog, ResultsLanguagesStardog, ResultsCertificationStardog } from "../../../model/Profil/stardog/IObjectsBNCStardog";

export default class PersonaRawDataServiceO365 extends PersonasBaseService
  implements IRawDataService {

  private currentEmail: string;

  protected language: string;
  /********************************************************************************************************
   *  Constructor
   ********************************************************************************************************/
  constructor(context: IHubServiceFactoryContext) {
    super(context);
  }

  public addPropertieValue(tagValues: ITagActionData): Promise<any> {
    throw new Error("Method not implemented.");
  }
  public setPropertieValue(tagValues: ITagActionData): Promise<any> {
    throw new Error("Method not implemented.");
  }

  /********************************************************************************************************
   * @description : Call service to get one profil with email id
   * @param string email: email or employee id to find people
   * @returns { Promise<any>} :  Profil schema object from StarDog
   ********************************************************************************************************/
  public getPersonaRawData = async (
    email: string
  ): Promise<MicrosoftGraph.User> => {
    return new Promise<any>(async (resolve, reject) => {
      if (!email) return reject("No email defined");
      this.currentEmail = email;
      this.spfxContext.msGraphClientFactory
        .getClient()
        .then((client: MSGraphClient) => {
          client
            .api(`/users/${this.currentEmail}`)
            .select([
              "JobTitle",
              "preferredLanguage",
              "businessPhones",
              "mobilePhone",
              "displayName",
              "officeLocation",
              "userPrincipalName",
              "streetAddress",
              "city",
              "state",
              "usageLocation",
              "postalCode",
              "skills",
              "interests"
            ])
            .get()
            .then(rawResponse => {
              if (rawResponse !== undefined) {
                return rawResponse;
              }
            },
              (error: any): void => {
                let message = `[PersonaService.getPersonaRawData() - MS GRAPH]: Error: '${error}' `;
                Logger.write(message, LogLevel.Error);
                return reject(message);
              })
            .then(
              (data: MicrosoftGraph.User): void => {
                return resolve(data);
              },
              (error: any): void => {
                let message = `[PersonaService.getPersonaRawData() - MS GRAPH]: Error: '${error}' `;
                Logger.write(message, LogLevel.Error);
                return reject(message);
              }
            );
        });
    });
  }


  public getPresence(email: string): Promise<IPresenceInfo> {
    return new Promise<any>(async (resolve, reject) => {
      if (!email) return reject("getPresence() : No email defined");
      this.spfxContext.msGraphClientFactory
        .getClient()
        .then((client: MSGraphClient) => {
          client
            .api(`/users/${email.toLowerCase().trim()}/presence`)
            .version('beta')
            .get()
            .then(rawResponse => {
              // console.log("---- getPresence rawResponse: ",rawResponse);
              if (rawResponse !== undefined) {
                return rawResponse;
              }
            })
            .then(
              (data: IPresenceInfo): void => {
                // console.log("---- getPresence: ",data);
                return resolve(data);
              },
              (error: any): void => {
                let message = `[PersonaService.getPresence() - MS GRAPH]: Error: '${error}' `;
                Logger.write(message, LogLevel.Error);
                return reject(message);
              }
            );
        });
    });
  }

  /********************************************************************************************************
   * @description : Call service to get all profil with this attribute
   * @param {Array<string>} attribute: keyword to find some thing like competency 'Developer'
   * @param {IPaging} paging: information value
   * @returns { Promise<any>} :  Profil schema object from SharePoint search
   *
   ********************************************************************************************************/
  public getPersonasRawData = async (attributes: string, paging: IPaging): Promise<any> => {
    return new Promise<any>(async (resolve, reject) => {
      this.validatedServiceContext(reject);
      if (attributes.length === 0) return resolve(undefined);
      if ((!paging.limit && paging.limit != 0) || (!paging.offset && paging.offset != 0)) return resolve(undefined);

      let attributesQuery = attributes;

      const url = this.spfxContext.pageContext.web.absoluteUrl + `/_api/search/query?querytext='${attributesQuery}*'&sourceid='B09A7990-05EA-4AF9-81EF-EDFAB16C4E31'&enablenicknames=true&enablephonetic=true&sortlist='rank:descending'&refiners='JobTitle'&rowlimit=${paging.limit}&$count=true&StartRow=${paging.offset}`;
      let config: SPHttpClientConfiguration = new SPHttpClientConfiguration({});
      config = SPHttpClient.configurations.v1;
      config = config.overrideWith({ defaultODataVersion: ODataVersion.v3 });

      this.spfxContext.spHttpClient
        .get(url, config, {
          headers: {
            Accept: "application/json;odata=minimalmetadata;charset=utf-8"
          }
        })
        .then((response: SPHttpClientResponse) => {
          if (response.ok) {
            response.json().then(
              (data: any): void => {
                let rows: any[] = _.get(
                  data,
                  "PrimaryQueryResult.RelevantResults.Table.Rows"
                );
                let totalRows: any[] = _.get(
                  data,
                  "PrimaryQueryResult.RelevantResults.TotalRows"
                );
                resolve({ rows: rows, totalRows: totalRows });
              },
              (error: any): void => {
                let message = `[PersonaRawDataService.getPersonasRawData(attributes: string, paging: IPaging)]: Error: '${error}' `;
                return reject(message);
              }
            );
          } else throw new Error(response.statusText);
        },
          (error: any): void => {
            let message = `[PersonaRawDataService.getPersonasRawData(attributes: string, paging: IPaging)]: Error: '${error}' `;
            return reject(message);
          });
    });
  }


  /********************************************************************************************************
 * @description : Call service to get all peoples around me
 * @param {string} email: email of the current user
 * @param {IPaging} paging: information value
 * @returns { Promise<any>} :  Profil schema object graph
 *
 ********************************************************************************************************/
  public getPeoplesByEmail = async (email: string, paging: IPaging): Promise<MicrosoftGraph.User[]> => {
    return new Promise<any>(async (resolve, reject) => {
      this.validatedServiceContext(reject);
      if (email.length === 0) return resolve(undefined);
      if ((!paging.limit && paging.limit != 0) || (!paging.offset && paging.offset != 0)) return resolve(undefined);
      this.spfxContext.msGraphClientFactory
        .getClient()
        .then((client: MSGraphClient) => {
          client
            .api(
              `/users/${email}/people`
            ).select([
              "JobTitle",
              "phones",
              "displayName",
              "officeLocation",
              "userPrincipalName",
              "scoredEmailAddresses",
              "birthday",
              "surname",
              "givenName",
              "department",
              "imAddress",
            ])
            .filter(`personType/class eq 'Person' and personType/subclass eq 'OrganizationUser'`)
            .count(true).skip(paging.offset).top(paging.limit)
            .get()
            .then(rawResponse => {
              if (
                rawResponse !== undefined &&
                rawResponse.value !== undefined
              ) {
                return rawResponse.value;
              }
            },
              (error: any): void => {
                let message = `[PersonaRawDataServiceO365.getPeoplesByEmail()]: Error: '${error}' `;
                Logger.write(message, LogLevel.Error);
                return reject(message);
              })
            .then(
              (data: MicrosoftGraph.User[]): void => {


                return resolve(data.filter((user: MicrosoftGraph.User) => {
                  const userEmail: string = _.get(user, 'userPrincipalName', '').toLocaleLowerCase().trim();
                  return email !== userEmail;
                }));
              },
              (error: any): void => {
                let message = `[PersonaRawDataServiceO365.getPeoplesByEmail()]: Error: '${error}' `;
                Logger.write(message, LogLevel.Error);
                return reject(message);
              }
            );
        });
    });
  }

  /********************************************************************************************************
   * @param {(reason?: any) => void} reject  validate parameters , if not well format reject promise
   ********************************************************************************************************/
  private validatedServiceContext(reject: (reason?: any) => void) {
    let errorMessage: string = "";

    if (!this.spfxContext) {
      errorMessage = `[validatedServiceContext()]: Error: 'webpart context not found' `;
      this.rejectMessageLog(reject, errorMessage);
    }
    if (!this.language) {
      errorMessage = `[validatedServiceContext()]: Error: 'Language  not found' `;
      this.rejectMessageLog(reject, errorMessage);
    }
  }

  public getCompetenciesRawData(email: string): Promise<any> {
    throw new Error("Method not implemented.");
  }

  public getApplicationBNCRawData(email: string): Promise<any> {
    throw new Error("Method not implemented.");
  }

  public getLanguagesRawData(email: string): Promise<ResultsLanguagesStardog> {
    throw new Error("Method not implemented.");
  }

  public getCertificationsRawData(email: string): Promise<ResultsCertificationStardog> {
    throw new Error("Method not implemented.");
  }

}
