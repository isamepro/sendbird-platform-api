import { IRawDataService, IPresenceInfo, IPaging, ISearchPersonas, ITagActionData, IHubServiceFactoryContext } from "../../../..";
import PersonasBaseService from "../searchPersonasServices/PersonasBaseService";
import { SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';
import { PageContext } from '@microsoft/sp-page-context';
import { ServiceScope, ServiceKey } from "@microsoft/sp-core-library";
import { IUserProfile } from "../../../model/Profil/IUserProfile";
import { ILanguagesBNCStardog, ICertificationStardog, IApplicationBNCStarDog, ResultsLanguagesStardog, ResultsCertificationStardog, ResultsApplicationBNCStarDog } from "../../../model/Profil/stardog/IObjectsBNCStardog";

export default class PersonaRawDataServiceSP extends PersonasBaseService
    implements IRawDataService {
    private currentWebUrl: string;

    constructor(context: IHubServiceFactoryContext) {
        super(context);
        this.currentWebUrl = context.spfxContext.PageContext.web.absoluteUrl;
    }
  public getLanguagesRawData(email: string): Promise<ResultsLanguagesStardog> {
    throw new Error("Method not implemented.");
  }
  public getCertificationsRawData(email: string): Promise<ResultsCertificationStardog> {
    throw new Error("Method not implemented.");
  }
 public  getApplicationBNCRawData(email: string): Promise<any|ResultsApplicationBNCStarDog>
  {
    throw new Error("Method not implemented.");
  }

    public getPersonaRawData = (email: string): Promise<IUserProfile> => {
        return new Promise<IUserProfile>((resolve: (itemId: IUserProfile) => void, reject: (error: any) => void): void => {
            this.readUserProfile(email)
                .then((orgChartItems: IUserProfile): void => {
                    resolve(this.processUserProfile(orgChartItems));
                });
        });
    }

    public getPresence = (email: string): Promise<IPresenceInfo> => {
        throw new Error("Method not implemented.");
    }

    public getPersonasRawData = (keywords: string, paging?: IPaging): Promise<ISearchPersonas> => {
        throw new Error("Method not implemented.");
    }

    public getPeoplesByEmail = (email: string, paging: IPaging): Promise<any[]> => {
        throw new Error("Method not implemented.");
    }

    public getCompetenciesRawData = (email: string): Promise<any> => {
        throw new Error("Method not implemented.");
    }

    public getSugestCompetenciesRawData = (email: string): Promise<any> => {
        throw new Error("Method not implemented.");
    }

    public setPropertieValue = (tagValues: ITagActionData): Promise<any> => {
        return new Promise<any>(async (resolve, reject) => {
            let method: string = "SetSingleValueProfileProperty";
            let formatedValue: string | string[] = tagValues.status;

            if (tagValues.status.indexOf('|')) {
                method = "SetMultiValuedProfileProperty";
                formatedValue = tagValues.status.split("|");
            }

            let apiUrl = this.context.spfxContext.pageContext.web.absoluteUrl + "/_api/SP.UserProfiles.PeopleManager/" + method;
            let userData = {
                'accountName': "i:0#.f|membership|" + tagValues.email,
                'propertyName': tagValues.name, //can also be used to set custom single value profile properties
                'propertyValues': formatedValue
            };
            let httpClient: SPHttpClient = this.context.spfxContext.spHttpClient;
            let spOpts = {
                headers: {
                    'Accept': 'application/json;odata=nometadata',
                    'Content-type': 'application/json;odata=verbose',
                    'odata-version': '',
                },
                body: JSON.stringify(userData)
            };
            httpClient.post(apiUrl, SPHttpClient.configurations.v1, spOpts).then(response => {
                resolve();
            }).catch((error) => {
                reject(error);
            });
        });
    }

    public addPropertieValue(tagValues: ITagActionData): Promise<any> {
        throw new Error('Method not implemented.');
      }


    private readUserProfile(email: string): Promise<IUserProfile> {
        return new Promise<IUserProfile>((resolve: (itemId: IUserProfile) => void, reject: (error: any) => void): void => {
            const account = encodeURIComponent("i:0#.f|membership|" + email);

            this.context.spfxContext.SPHttpClient.get(`${this.currentWebUrl}/_api/SP.UserProfiles.PeopleManager/GetPropertiesFor(accountName=@v)?@v='${account}'`,

                SPHttpClient.configurations.v1,
                {
                    headers: {
                        'Accept': 'application/json;odata=nometadata',
                        'odata-version': ''
                    }
                })
                .then((response: SPHttpClientResponse): Promise<{ value: IUserProfile }> => {
                    return response.json();
                })
                .then((response: { value: IUserProfile }): void => {
                    //resolve(response.value);
                    var output: any = JSON.stringify(response);
                    resolve(output);
                }, (error: any): void => {
                    reject(error);
                });
        });
    }

    private processUserProfile(orgChartItems: any): any {
        return JSON.parse(orgChartItems);
    }



    private updateUPValue = (email: string, propertyName: string, value: string): void => {
        let method: string = "SetSingleValueProfileProperty";
        let formatedValue: string | string[] = value;

        if (value.indexOf('|')) {
            method = "SetMultiValuedProfileProperty";
            formatedValue = value.split("|");
        }

        let apiUrl = this.context.spfxContext.pageContext.web.absoluteUrl + "/_api/SP.UserProfiles.PeopleManager/" + method;
        let userData = {
            'accountName': "i:0#.f|membership|" + email,
            'propertyName': propertyName, //can also be used to set custom single value profile properties
            'propertyValues': formatedValue
        };
        let httpClient: SPHttpClient = this.context.spfxContext.spHttpClient;
        let spOpts = {
            headers: {
                'Accept': 'application/json;odata=nometadata',
                'Content-type': 'application/json;odata=verbose',
                'odata-version': '',
            },
            body: JSON.stringify(userData)
        };
        httpClient.post(apiUrl, SPHttpClient.configurations.v1, spOpts).then(response => {
            console.log("Updated");
        });
    }

}
