import { User } from '@microsoft/microsoft-graph-types';
import { HttpClient, HttpClientResponse, IHttpClientOptions } from '@microsoft/sp-http';
import * as _ from 'lodash';
import { IHubServiceFactoryContext, IPresenceInfo, ITagAction, ITagBNC, ITagActionData } from '../../../..';
import { IRawDataService } from '../../../interfaces/commun/IRawDataService';
import { IPaging } from '../../../model/paging/IPaging';
import PersonasBaseService from '../searchPersonasServices/PersonasBaseService';
import { StatusValues } from '../../../model/commun/StatusValues';
import { ResultsApplicationBNCStarDog, ResultsLanguagesStardog, ResultsCertificationStardog, IApplicationBNCStarDog } from '../../../model/Profil/stardog/IObjectsBNCStardog';
import { ICompetenciesStardog, BindingCompetencie } from './fake/jsonMockFiles/ICompetenciesStardog';

export default class PersonaRawDataServiceStarDog extends PersonasBaseService implements IRawDataService {
  private databaseName: string = 'Profil_Social';
  public getPresence(email: string): Promise<IPresenceInfo> {
    throw new Error("Method not implemented.");
  }
  public getPeoplesByEmail(email: string, paging: IPaging): Promise<User[]> {
    throw new Error("Method not implemented.");
  }

  private getSarDogUrlForUpdate(identity: string, skills: string, status: StatusValues) {
    let serviceUrl = `${this.serviceDomainUrl}stardog`;
    let emailValue = `<mailto:${this.getEmailBNC(identity.toLowerCase().trim())}>`;
    // TODO ajouter un parametre pour le type de mise a jour
    return `${serviceUrl}/${this.databaseName}/update?query=updateCompetencyFeedback&$email=${emailValue}&$compId="${skills}"&$inputFdbk="${status}"`;
  }

  private getSarDogUrlForAdd(identity: string, skill: string) {
    let serviceUrl = `${this.serviceDomainUrl}stardog`;
    const emailValue = `<mailto:${this.getEmailBNC(identity.toLowerCase().trim())}>`;
    // TODO ajouter un parametre pour le type de mise a jour
    return `${serviceUrl}/${this.databaseName}/update?query=insertCompetency&$email=${emailValue}&$compId="${skill}"`;
  }

  private getSarDogUrlForDelete(identity: string, skill: string, status: StatusValues) {
    let serviceUrl = `${this.serviceDomainUrl}stardog`;
    const emailValue = `<mailto:${this.getEmailBNC(identity.toLowerCase().trim())}>`;
    // TODO ajouter un parametre pour le type de mise a jour
    return `${serviceUrl}/${this.databaseName}/update?query=updateCompetencyFeedback&$email=${emailValue}&$compId="${skill}"&$inputFdbk="${status}"`;
  }

  private async updateStarDog(url: string): Promise<string> {

    const token = await this.getCurrentUserToken();
    let postOptions: IHttpClientOptions = this.getPostOptions(token);
    try {
      const response = await this.spfxContext.httpClient
        .post(url, HttpClient.configurations.v1, postOptions);
      if (response.ok) {
        return "";
      }
      else {
        let message = `[StarDog PersonaRawDataService.setTopicCompetenciessRawData()]: Error: '${response.status + ":" + response.statusText}' `;
        return message;
      }
    }
    catch (error) {
      let message_1 = `[StarDog PersonaRawDataService.setTopicCompetenciessRawData()]: Error: '${error}' `;
      return message_1;
    }
  }

	/********************************************************************************************************
   *  Constructor
   ********************************************************************************************************/
  constructor(context: IHubServiceFactoryContext) {
    super(context);
  }


  public getApplicationBNCRawData(email: string): Promise<any> {
    throw new Error("Method not implemented.");
  }


  public addPropertieValue(tagValues: ITagActionData): Promise<any> {
    throw new Error("Method not implemented.");
  }
  public setPropertieValue(tagValues: ITagActionData): Promise<any> {
    throw new Error("Method not implemented.");
  }

	/********************************************************************************************************
   * @description : Call service to get one profil with email id
   * @param string email: email or employee id to find people
   * @param {IContextualMenuItem[]} filters: filters result 'Developer'
   * @returns { Promise<any>} :  Profil schema object from StarDog
   ********************************************************************************************************/
  public getPersonaRawData = async (email: string): Promise<any> => {
    return new Promise<any>(async (resolve, reject) => {
      if (!email) {
        let errorMessage = `[getPersonaRawData()]: Error: 'email not found' `;
        return reject(errorMessage);
      }
      this.validatedServiceContext(reject);

      // Make the call to the Api Management
      let serviceUrl = `${this.serviceDomainUrl}stardog`;
      const url = `${serviceUrl}/${this.databaseName}/query?query=getPerson&$email=<mailto:${this.getEmailBNC(email.toLowerCase().trim())}>&$limit=1&$language='${this.language}'`;
      this.getCurrentUserToken().then((token: any) => {
        const postOptions: IHttpClientOptions = this.getPostOptions(token);
        this.spfxContext.httpClient
          .get(url, HttpClient.configurations.v1, postOptions)
          .then((res: HttpClientResponse): Promise<any> => {
            if (res.ok) return res.json();
            else throw new Error(res.statusText);
          })
          .then(
            (data: any): void => {
              return resolve(data);
            },
            (error: any): void => {
              let message = `[PersonaRawDataService.getPersonaRawData()]: Error: '${error}' `;
              return reject(message);
            }
          );
      });
    });
  }

	/********************************************************************************************************
   * @description : Call service to get competencies email id
   * @param string email: email or employee id to find people
   * @returns { Promise<any>} :  Profil schema object from StarDog
   ********************************************************************************************************/
  public getCompetenciesRawData = async (email: string): Promise<any| ICompetenciesStardog> => {
    return new Promise<any|ICompetenciesStardog>(async (resolve, reject) => {
      if (!email) {
        let errorMessage = `[getCompetenciesRawData()]: Error: 'email not found' `;
        return reject(errorMessage);
      }
      this.validatedServiceContext(reject);

      // Make the call to the Api Management
      let serviceUrl = `${this.serviceDomainUrl}stardog`;
      const url = `${serviceUrl}/${this.databaseName}/query?query=getPersonCurrentCompetency&$email=<mailto:${this.getEmailBNC(email.toLowerCase().trim())}>&$limit=1&$language='${this.language}'`;
      this.getCurrentUserToken().then((token: any) => {
        const postOptions: IHttpClientOptions = this.getPostOptions(token);
        this.spfxContext.httpClient
          .get(url, HttpClient.configurations.v1, postOptions)
          .then((res: HttpClientResponse): Promise<any> => {
            if (res.ok) return res.json();
            else throw new Error(res.statusText);
          },
          (error: any): void => {
            let message = `[PersonaRawDataService.getCompetenciesRawData()]: Error: '${error}' `;
            return reject(message);
          })
          .then(
            (data: any): void => {

              return resolve(data);
            },
            (error: any): void => {
              let message = `[PersonaRawDataService.getCompetenciesRawData()]: Error: '${error}' `;
              return reject(message);
            }
          );
      });
    });
  }

	/********************************************************************************************************
   * @description : Call service to get all profil with this attribute
   * @deprecated: not use startdog now
   * @param {Array<string>} attribute: keword to find some thing like competency 'Developer'
   * @returns { Promise<any>} :  Profil schema object from StarDog
   *
   * @see:&limit=10&offset=10
   * Limit -> nombre d’éléments à afficher par page
   *
   * Offset -> index d'entrée du prochain champ
   * 0 pour recevoir les champs 0 à 9
   * 10 pour les champs 10 à 19
   * 20 pour les champs 20 à 29
   ********************************************************************************************************/
  public getPersonasRawData = async (attributes: string, paging: IPaging): Promise<any> => {
    return new Promise<any>(async (resolve, reject) => {
      this.validatedServiceContext(reject);
      //clear list

      if (attributes.length === 0) return resolve(undefined);
      if ((!paging.limit && paging.limit != 0) || (!paging.offset && paging.offset != 0)) return resolve(undefined);
      let attributesQuery = attributes == '*' ? '' : attributes;

      // Make the call to the Api Management
      let serviceUrl = `${this.serviceDomainUrl}stardog`;
      const url = `${serviceUrl}/${this.databaseName}/query?query=searchPersonShort&limit=${paging.limit}&offset=${paging.offset}&$searchString="${attributesQuery}"&$minScore=${7}&$maxTextQty=${50}&$language="${this.language}"`;
      this.getCurrentUserToken().then((token: any) => {
        const postOptions: IHttpClientOptions = this.getPostOptions(token);
        this.spfxContext.httpClient
          .get(url, HttpClient.configurations.v1, postOptions)
          .then((res: HttpClientResponse): Promise<any> => {
            if (res.ok) return res.json();
            else throw new Error(res.statusText);
          },
          (error: any): void => {
            let message = `[PersonaRawDataService.getPersonasRawData()]: Error: '${error}' `;
            return reject(message);
          })
          .then(
            (data: any): void => {
              resolve(data);
            },
            (error: any): void => {
              let message = `[PersonaRawDataService.getPersonasRawData()]: Error: '${error}' `;
              return reject(message);
            }
          );
      });
    });
  }




  /********************************************************************************************************
   * @param {string} email email to change domain for bnc.ca
   * @returns {string} return email bnc.ca
   ********************************************************************************************************/
  private getEmailBNC(email: string): string {
    let parts = email.split('@');
    return (parts.length === 2 && (parts[1].indexOf(".onmicrosoft.com")>0)) ? parts[0] + '@bnc.ca' : email;
  }
	/********************************************************************************************************
   * @param {string} token
   * @returns {IHttpClientOptions}
   ********************************************************************************************************/
  private getPostOptions(token: string): IHttpClientOptions {
    return {
      headers: this.getHeaders(token),
      referrerPolicy: "no-referrer-when-downgrade"
    };
  }

	/********************************************************************************************************
   * @param {string} token get user baarer token
   * @returns return all headers to query data
   ********************************************************************************************************/
  private getHeaders(token: string) {
    const requestHeaders: Headers = new Headers();
    requestHeaders.append('Content-type', 'application/json');
    requestHeaders.append('Cache-Control', 'no-cache');
    requestHeaders.append('Ocp-Apim-Subscription-Key', this.subscriptionkey);
    requestHeaders.append('Authorization', `Bearer ${token}`);
    return requestHeaders;
  }

	/********************************************************************************************************
   * @param {(reason?: any) => void} reject  validate parameters , if not well format reject promise
   ********************************************************************************************************/
  private validatedServiceContext(reject: (reason?: any) => void) {
    let errorMessage: string = '';
    if (!this.serviceDomainUrl) {
      errorMessage = `[getPersonasRawData()]: Error: 'Service url not found' `;
      this.rejectMessageLog(reject, errorMessage);
    }
    if (!this.spfxContext) {
      errorMessage = `[getPersonasRawData()]: Error: 'webpart context not found' `;
      this.rejectMessageLog(reject, errorMessage);
    }
    if (!this.language) {
      errorMessage = `[getPersonasRawData()]: Error: 'Language  not found' `;
      this.rejectMessageLog(reject, errorMessage);
    }
    if (!this.subscriptionkey) {
      errorMessage = `[getPersonasRawData()]: Error: 'subscriptionkey  not found' `;
      this.rejectMessageLog(reject, errorMessage);
    }
  }

	/********************************************************
 * Returns the city or location in the correct language ELSE in french ELSE undefined
 *    Eg.  "Floor 17@en|Étage 17@fr"   =>   "Floor 17"
 * @param {string} citiesOrLocationsString
 * @returns {string}
 ********************************************************/
  protected formatCityOrLocation(citiesOrLocationsString: string, isCity: boolean): string {
    if (!this.validateString(citiesOrLocationsString)) return undefined;
    let listInformation: string[] = citiesOrLocationsString.split(',');

    const cityOrLocationLanguageRegex = `(?<=\\|).*(?=@${this.language}\\|)|[^|]*(?=@${this.language})`;
    const cityOrLocationInCorrectLanguage = new RegExp(cityOrLocationLanguageRegex, 'g').exec(citiesOrLocationsString);
    if (cityOrLocationInCorrectLanguage) return cityOrLocationInCorrectLanguage[0];
    return isCity ? _.get(listInformation, '[0]', '') : _.get(listInformation, '[1]', '');
  }



  public getLanguagesRawData(email: string): Promise<ResultsLanguagesStardog> {
    throw new Error("Method not implemented.");
  }

  public getCertificationsRawData(email: string): Promise<ResultsCertificationStardog> {
    throw new Error("Method not implemented.");
  }

}
