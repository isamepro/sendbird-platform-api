export const LanguageCharCode = {
  char_english: 'en',
  char_french: 'fr',
};
