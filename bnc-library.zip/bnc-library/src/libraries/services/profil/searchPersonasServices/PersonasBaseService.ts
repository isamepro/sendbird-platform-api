import { IPhone } from '../../../model/IPhone';
import { Logger, LogLevel, ConsoleListener } from '@pnp/logging';
import * as _ from 'lodash';

import { WebPartContext } from '@microsoft/sp-webpart-base';
import { IPersonaData } from '../../../model/Profil/stardog/IPersonas';
import { IHubServiceFactoryContext } from '../../../..';
import { PersonaPresence } from 'office-ui-fabric-react';

/*************************************************************************************
 * @export
 * @class PersonasBaseService
 *************************************************************************************/
export default class PersonasBaseService {
  public context: IHubServiceFactoryContext;
  protected spfxContext: WebPartContext;
  protected language: string;
  protected serviceDomainUrl: string;
  protected subscriptionkey: string;

	/*************************************************************************************
   * Creates an instance of PersonasBaseService.
   * @param {IHubServiceFactoryContext} context
   *************************************************************************************/
  constructor( context: IHubServiceFactoryContext ) {
    const consoleListener = new ConsoleListener();
    Logger.subscribe( consoleListener );

    this.context = context;
    this.spfxContext = context.spfxContext;
    this.language = !context.language  ? 'fr' : context.language;

    if (!context.serviceDomainUrl) throw new Error (`L'Url de service est manquant. SVP, contacter l'admistrateur.`);
    if (!context.subscriptionkey) throw new Error (`L'API Key est manquante. SVP, contacter l'admistrateur.`);

    this.serviceDomainUrl = context.serviceDomainUrl;
    this.subscriptionkey = context.subscriptionkey;
  }

	/*********************************************************************************************************************
   * @returns {Promise<string>} : Current user tokens
   **********************************************************************************************************************/
  protected getCurrentUserToken = (): Promise<string> => {
    if ( !this.spfxContext ) throw new Error( 'getCurrentUserToken() need webpart context' );
    let resource = `https://${ window.location.hostname }`;
    return new Promise<string>( ( resolve, reject ) => {
      this.spfxContext.aadTokenProviderFactory
        .getTokenProvider()
        .then( ( provider: any ) => {
          provider
            .getToken( resource, true )
            .then( ( token: string ) => {
              resolve( token );
            } )
            .catch( ( error: string ) => {
              reject( error );
            } );
        } )
        .catch( ( error: string ) => {
          reject( error );
        } );
    } );
  }


  protected rejectMessageLog( reject: ( reason?: any ) => void, errorMessage: string ) {
    Logger.write( errorMessage, LogLevel.Error );
    return reject( errorMessage );
  }

	/*************************************************************************************
 * @returns {string}
 *************************************************************************************/
  public getTitle( row: any ): string {
    const value: string = _.get( _.find( row.Cells, { Key: 'JobTitle' } ), 'Value', '' );
    return value === null ? '' : value.trim();
  }
	/*************************************************************************************
   * @description lire le "PreferredName" sinon prendre l'adresse de courriel de l'usager
 * @returns {string}
 *************************************************************************************/
  public getDisplayName( row: any ): string {
    const value: string = _.get( _.find( row.Cells, { Key: 'PreferredName' } ), 'Value', this.getEmail( row ) );
    return value === null ? this.getEmail( row ) : value.trim();
  }

	/*************************************************************************************
 * @returns {string}
 *************************************************************************************/
  public getPictureUrl( email: string ): string {
    const url: string = ' /_layouts/15/userphoto.aspx?size=L&username=';
    return email !== undefined ? `${ url }${ email }` : '';
  }
	/*************************************************************************************
  * @description: Lire le WorkEmail sinon prendre le AccountName et stripper la partie inutile
  * @returns {string}
 *************************************************************************************/
  public getEmail( row: any ): string {
    const value: string = _.get( _.find( row.Cells, { Key: 'WorkEmail' } ), 'Value', '' );
    if (!value) {
      //i:0#.f|membership|user@devbnc.onmicrosoft.com
      const valueAccount: string = _.get( _.find( row.Cells, { Key: 'AccountName' } ), 'Value', '' );
      return valueAccount === null ? '' : valueAccount.replace( 'i:0#.f|membership|', '' ).trim();
    }
    return (value)?value.trim():value;
  }
	/*************************************************************************************
 * @returns {IPhone}
 *************************************************************************************/
  protected getPhones( phone: string ): IPhone {
    if ( !phone  ) return undefined;
    const extensionLabel = ';ext=';
    let phoneClean = phone.trim().toLowerCase().replace( 'tel:+', '' ).replace( '-', '.' );

    let returnValue: IPhone = phoneClean.indexOf( extensionLabel ) > 0 ? { phone: phoneClean.split( extensionLabel )[ 0 ], ext: phoneClean.split( extensionLabel )[ 1 ] } : { phone: phoneClean, ext: '' };

    return returnValue;
  }
	/********************************************************
 * @returns {boolean}
 * @param valueToValidate
 ********************************************************/
  protected validateString = ( valueToValidate: string ): boolean => valueToValidate !== undefined && valueToValidate !== null && typeof valueToValidate === 'string' && valueToValidate.length > 0;

	/************************************************************
 * @description : log message and throw errors
 * @param {string} message : error message
 * @param {string} funcName: function name where the error
 *************************************************************/
  protected logError( message: string, funcName: string ): void {
    let returnMessage: string = `[ApimProvider.${ funcName }()]: Error: '${ message }'.`;
    Logger.write( returnMessage, LogLevel.Error );
    throw new Error( returnMessage );
  }


}
