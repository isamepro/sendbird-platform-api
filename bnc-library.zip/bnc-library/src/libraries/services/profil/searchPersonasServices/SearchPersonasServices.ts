import * as _ from 'lodash';
import { ISearchProfilsService } from '../../../interfaces/profil/ISearchProfilsService';
import { IRawDataService } from '../../../interfaces/commun/IRawDataService';
import { ISearchPersonas } from '../../../model/Profil/ISearchPersonas';
import { IPaging } from '../../../model/paging/IPaging';
import { User } from '@microsoft/microsoft-graph-types';
import { IPresenceInfo, IPersonaData } from '../../../..';

export class SearchPersonasService implements ISearchProfilsService {

  private count: number;
  private rawDataService: IRawDataService;
	/*************************************************************************************
   * Creates an instance of SearchPersonasService.
   * @param {IRawDataService} rawDataService
   *************************************************************************************/
  constructor(rawDataService: IRawDataService) {
    this.rawDataService = rawDataService;
  }

	/*************************************************************************************
   * @param {string} [keyword]
   * @returns {Promise<ISearchPersonas>}
   *************************************************************************************/
  public getProfils(keyword: string, paging: IPaging): Promise<ISearchPersonas> {
    return new Promise<ISearchPersonas>((resolve, reject) => {
      if (keyword === undefined) return reject(this.rawDataService.context.strings.errors.KeywordNotFound);
      if (paging === undefined) return reject('Paging not found');
      this.rawDataService
        .getPersonasRawData(keyword, paging)
        .then((data: any) => {
          this.process(data.rows).then((personas) => {
            let searchprops: ISearchPersonas = {
              keyword: keyword,
              header: this.getHeaderMessage(keyword),
              data: personas,
              totalRows: data.totalRows
            };
            resolve(searchprops);
          });
        })
        .catch(() => {
          resolve({
            keyword: keyword,
            header: this.getHeaderMessage(keyword),
            data: undefined,
            totalRows: 0
          });
        });
    });
  }


  public getPeoplesByEmail(email: string, paging: IPaging): Promise<User[]> {
    return new Promise<any[]>((resolve, reject) => {
      if (!email) return reject('email not found');
      if (!paging) return reject('Paging not found');
      this.rawDataService
        .getPeoplesByEmail(email, paging)
        .then((data) => {
          resolve(data);
        })
        .catch((error) => {
          reject(error);
        });
    });
  }

  /*************************************************************************************/
  private getHeaderMessage(keyword: string): string {
    if (!keyword) return '';
    return _.replace(this.rawDataService.context.strings.profilLabel.ColleguesFound, '{0}', _.get(this, "count.toString()", ""));
  }

  /*************************************************************************************/
  private process(rows: any): Promise<IPersonaData[]> {
    return new Promise<any[]>((resolve, reject) => {
      try {
        let count = 0;
        if (!rows) {
          return [];
        }
        let promises = [];
        rows.map((row: any) => {
          promises.push(this.processPersona(row));
        });

        Promise.all(promises).then((returnPersonas: IPersonaData[]) => {
          count = returnPersonas.length;
          resolve(returnPersonas);
        });
      } catch (error) {
        reject(error);
      }
    });
  }

  /*************************************************************************************/
  private async processPersona(row: any): Promise<IPersonaData> {
    return new Promise<any>((resolve, reject) => {
      try {
        const email: string = this.rawDataService.getEmail(row);
        const displayName = this.rawDataService.getDisplayName(row);
        const title = this.rawDataService.getTitle(row);
        const pictureUrl = this.rawDataService.getPictureUrl(email);
        const presence = undefined;
        // on ne peut pas aller chercher la presence car la securité est par application
        // https://docs.microsoft.com/en-us/graph/api/presence-get?view=graph-rest-beta&tabs=http
        // this.rawDataService.getPresence(email).then((presence) => {
          resolve({
            lines: [
              { line: displayName },
              { line: title },
              { line: email }
            ],
            pictureUrl: pictureUrl,
            personaStatus: presence.availability,
          });
        // }).catch((error) => {
        //   reject(error);
        // });
      }
      catch (error) {
        reject(error);
      }
    });
  }


  /*************************************************************************************/
  protected isEmpty(obj: any): boolean {
    for (var key in obj) {
      if (obj.hasOwnProperty(key)) return false;
    }
    return true;
  }
}
