import { ServiceKey, ServiceScope } from '@microsoft/sp-core-library';
import { ConsoleListener, Logger } from '@pnp/logging';
import * as _ from 'lodash';
import { PageContext } from '@microsoft/sp-page-context';
import { SPHttpClient } from "@microsoft/sp-http";
import { HttpClient, HttpClientResponse, IHttpClientOptions } from '@microsoft/sp-http';
import { MSGraphClientFactory, MSGraphClient } from '@microsoft/sp-http';
import { AadTokenProviderFactory } from "@microsoft/sp-http";
import { ITenantPropertiesManagerService, TenantPropertiesManagerService } from '../sharePoint/TenantPropertiesManagerService';


export default class ApimServiceBase {
  protected spHttpClient: SPHttpClient;
  protected httpClient: HttpClient;
  protected pageContext: PageContext;
  protected msGraphClientFactory: MSGraphClientFactory;
  protected msGraphClient: MSGraphClient;
  protected aadTokenProviderFactory: AadTokenProviderFactory;
  protected tenantPropertiesManagerService: ITenantPropertiesManagerService;
  protected o365ApiVersion: string = 'v1.0';

  constructor(serviceScope: ServiceScope) {
    serviceScope.whenFinished( async () => {
      this.spHttpClient = serviceScope.consume(SPHttpClient.serviceKey);
      this.httpClient = serviceScope.consume(HttpClient.serviceKey);
      this.pageContext = serviceScope.consume(PageContext.serviceKey);
      this.msGraphClientFactory = serviceScope.consume(MSGraphClientFactory.serviceKey);
      this.aadTokenProviderFactory = serviceScope.consume(AadTokenProviderFactory.serviceKey);
      this.tenantPropertiesManagerService = serviceScope.consume(TenantPropertiesManagerService.serviceKey);
    });

    Logger.subscribe(new ConsoleListener());
  }

  protected doGetBase = async (url: string, apimSubscriptionKey: string): Promise<any> => {

    if (!url || url === '') {
      return Promise.reject('GetOperationUrlIsUndefinedException');
    }

    const token: string = await this.getBearerToken();
    const httpHeader = await this.generateHttpHeader(token,apimSubscriptionKey);
    const response = await this.httpClient.get(url, SPHttpClient.configurations.v1, httpHeader);
    return await response.json();
  }

  protected doPostBase = async(url: string, data: any, apimSubscriptionKey:string, contentType:string = 'application/x-www-form-urlencoded'): Promise<HttpClientResponse> => {

    if (!data) return Promise.reject('PostOperationDataIsUndefinedException');
    if (!url || url === '') { return Promise.reject('PostOperationUrlIsUndefinedException'); }

    const token = await this.getBearerToken();

    const options: IHttpClientOptions = {
      body: data,
      headers: this.generateHttpHeaderString(token, apimSubscriptionKey, contentType),
    };
    const response = await this.httpClient
      .post(url,
        HttpClient.configurations.v1,
        options);

    return response;
  }

  protected doFetchBase = async(url: string, data: any, apimSubscriptionKey:string, method:string,contentType:string = 'application/x-www-form-urlencoded'): Promise<HttpClientResponse> => {

    if (!data) return Promise.reject('PostOperationDataIsUndefinedException');
    if (!url || url === '') { return Promise.reject('PostOperationUrlIsUndefinedException'); }

    const token = await this.getBearerToken();

    const options: IHttpClientOptions = {
      method: method,
      headers: this.generateHttpHeaderString(token, apimSubscriptionKey, contentType),
    };
    options.body = JSON.stringify(data);
    const response = await this.httpClient 
      .fetch(url,
        HttpClient.configurations.v1,
        options);

    return response;
  }

  public getBearerToken = async (): Promise<string> => {
    const provider = await this.aadTokenProviderFactory.getTokenProvider();
    return await provider.getToken(`https://${ window.location.hostname }`);
  }

  protected generateHttpHeader = async (token: string,apimSubscriptionKey: string) : Promise<IHttpClientOptions> => {
    const requestHeaders: Headers = new Headers();
    requestHeaders.append('Content-type', 'application/json');
    requestHeaders.append('Cache-Control', 'no-cache');

    
// ajouter Cross Cors
    requestHeaders.append('Ocp-Apim-Subscription-Key', apimSubscriptionKey);
    requestHeaders.append('Authorization', `Bearer ${token}`);
    

    return {
      headers: requestHeaders,
    };
  }

  protected generateHttpHeaderString = (token: string, apimSubscriptionKey: string, contentType: string= 'application/x-www-form-urlencoded') : any => {
      return {
        'Content-type': contentType,
        'Cache-Control': 'no-cache',
        'Ocp-Apim-Subscription-Key': apimSubscriptionKey,
        'Authorization': `Bearer ${token}`};
  }

  protected getFieldValue(field: any): any {
    if (!field) return '';
    return field;
  }
}
