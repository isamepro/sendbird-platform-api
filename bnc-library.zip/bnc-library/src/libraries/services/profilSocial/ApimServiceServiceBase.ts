import { ServiceScope } from '@microsoft/sp-core-library';
import { ConsoleListener, Logger } from '@pnp/logging';
import * as _ from 'lodash';
import { HttpClientResponse } from '@microsoft/sp-http';
import { ITenantPropertiesManagerService, TenantPropertiesManagerService } from '../sharePoint/TenantPropertiesManagerService';
import { IBncConfiguration } from '../../model/commun/IBncConfiguration';
import ApimServiceBase from './ApimServiceBase';

export default class ApimServiceServiceBase extends ApimServiceBase {

  protected static bncConfiguration: IBncConfiguration;
  protected tenantPropertiesManagerService: ITenantPropertiesManagerService;

  constructor(serviceScope: ServiceScope) {
    super(serviceScope);
    serviceScope.whenFinished( async () => {
      
      this.tenantPropertiesManagerService = serviceScope.consume(TenantPropertiesManagerService.serviceKey);

      ApimServiceServiceBase.bncConfiguration = await this.tenantPropertiesManagerService.getBncConfiguration();

    });

    Logger.subscribe(new ConsoleListener());
  }

  protected doGet = async (url: string): Promise<any> => {
    if (!ApimServiceServiceBase.bncConfiguration) {
        ApimServiceServiceBase.bncConfiguration = await this.tenantPropertiesManagerService.getBncConfiguration();
    }
    
    return await this.doGetBase(url,ApimServiceServiceBase.bncConfiguration.apimMicroServiceSubscriptionKey);
  }

  protected doPost = async (url: string, data: any, contentType:string = 'application/x-www-form-urlencoded'): Promise<HttpClientResponse> => {
    if (!ApimServiceServiceBase.bncConfiguration) {
        ApimServiceServiceBase.bncConfiguration = await this.tenantPropertiesManagerService.getBncConfiguration();
    }

    return await this.doPostBase(url,data, ApimServiceServiceBase.bncConfiguration.apimMicroServiceSubscriptionKey, contentType);
  }

  protected doFetch = async (url: string, data: any, method:string, contentType:string = 'application/x-www-form-urlencoded'): Promise<HttpClientResponse> => {
    if (!ApimServiceServiceBase.bncConfiguration) {
        ApimServiceServiceBase.bncConfiguration = await this.tenantPropertiesManagerService.getBncConfiguration();
    }

    return await this.doFetchBase(url,data, ApimServiceServiceBase.bncConfiguration.apimMicroServiceSubscriptionKey, method, contentType);
  }
}