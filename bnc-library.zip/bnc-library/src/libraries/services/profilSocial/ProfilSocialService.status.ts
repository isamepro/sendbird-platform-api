/**
 * Use this enum to filter competencies from Stardog.
 *
 * @export
 * @enum {number}
 */
export enum CompetencyStatus {
  valid = "valid",
  suggested = "suggested",
}

/**
 * Use this enum to interact with stardog for CRUD operation on a competency.
 *
 * @export
 * @enum {number}
 */
export enum ManageCompetencyStatus {
  /**
   * Used to perform feedback
   */
  sugested = 'rating_feedback_valid',

  /**
   * Used to perform feedback
   */
  add = 'rating_feedback_valid',

  /**
   * Used to perform feedback
   */
  delete = 'rating_feedback_rejected'
}
