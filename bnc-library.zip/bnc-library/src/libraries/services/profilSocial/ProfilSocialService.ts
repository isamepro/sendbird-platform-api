import { ServiceKey, ServiceScope } from '@microsoft/sp-core-library';
import { ConsoleListener, Logger } from '@pnp/logging';
import * as _ from 'lodash';
import { INatBotUserSettings } from '../../..';
import {
  INotificationTypesGetResponse,
  IUserSettingsGetResponse
} from '../../model/userSettings/IUserSettingsGetResponse';
import { DataOperationQueryType, DataSource, IExtendedProfil, IProfilData, IProfilDataItem, IProfilSocialDataService } from './ProfilSocialService.types';
import { ProfilSocialServiceMicroService } from './ProfilSocialServiceMicroService';
import { ProfilSocialServiceMock } from './ProfilSocialServiceMock';
import { ProfilSocialServiceO365 } from './ProfilSocialServiceO365';
import { ProfilSocialServiceStardog } from './ProfilSocialServiceStardog';

export interface IProfilSocialService {
  updateProfil(email: string, delta: IExtendedProfil, datasource?: DataSource): Promise<void>;
  getUserInformation(email: string, datasource?: DataSource): Promise<IProfilData>;
  getData(email: string, operationType: DataOperationQueryType, language: string, datasource?: DataSource): Promise<IProfilDataItem[]>;
  getPeopleAround(email: string, offset: number, limit: number, datasource?: DataSource): Promise<IProfilData[]>;
  updateSuggestedCompetency(email: string, suggestedCompetency: IProfilDataItem, datasource?: DataSource): Promise<void>;
  getNatBotUserPreferences(url: string, datasource?: DataSource): Promise<IUserSettingsGetResponse>;
  getNotificationTypes(url: string, datasource?: DataSource): Promise<INotificationTypesGetResponse>;
  setNatBotUserPreferences(url: string, userSettings: INatBotUserSettings, datasource?: DataSource): Promise<boolean>;
}

export class ProfilSocialService implements IProfilSocialService {

  private _serviceScope: ServiceScope;

  //#region Public Static Members
  public static serviceKey: ServiceKey<IProfilSocialService> =
    ServiceKey.create<ProfilSocialService>(`BNC:IProfilSocialService`, ProfilSocialService);
  //#endregion

  constructor(serviceScope: ServiceScope) {
    this._serviceScope = serviceScope;
    Logger.subscribe(new ConsoleListener());
  }

  /**
   * This function return an instance of the type of Datasource
   *
   * @private
   * @memberof ProfilSocialService
   */
  private getDatasourceInstance = (datasource: DataSource): IProfilSocialDataService => {

    switch (datasource) {
      case DataSource.o365:
        return new ProfilSocialServiceO365(this._serviceScope);
      case DataSource.stardog:
        return new ProfilSocialServiceStardog(this._serviceScope);
      case DataSource.mock:
        return new ProfilSocialServiceMock();
      case DataSource.microService:
        return new ProfilSocialServiceMicroService(this._serviceScope);
      default:
        return new ProfilSocialServiceMock();
    }
  }

  public getUserInformation = async (email: string = "", datasource: DataSource = DataSource.o365): Promise<IProfilData> => {
    return await this.getDatasourceInstance(datasource).getUserInformation(email);
  }

  public getPeopleAround = async (email: string, offset: number, limit: number, datasource: DataSource = DataSource.o365): Promise<IProfilData[]> => {
    return await this.getDatasourceInstance(datasource).getPeopleAround(email, offset, limit);
  }

  public getData = async (email: string, operationType: DataOperationQueryType, language: string, datasource: DataSource = DataSource.stardog): Promise<IProfilDataItem[]> => {
    return await this.getDatasourceInstance(datasource).getData(email, operationType, language);
  }

  public updateSuggestedCompetency = async (email: string, suggestedCompetency: IProfilDataItem, datasource: DataSource = DataSource.stardog): Promise<void> => {
    await this.getDatasourceInstance(datasource).updateSuggestedCompetency(email, suggestedCompetency);
  }

  public updateProfil = async (email: string, delta: IProfilData, datasource: DataSource = DataSource.stardog): Promise<void> => {

    if (datasource == DataSource.mock) {
      // for Unit Tests
      await this.getDatasourceInstance(datasource).updateProfil(email, delta);
    }
    else {
      // for save the competency
      datasource = DataSource.stardog;
      await this.getDatasourceInstance(datasource).updateProfil(email, delta);
      // for save the softwares
      datasource = DataSource.microService;
      await this.getDatasourceInstance(datasource).updateProfil(email, delta);
    }
  }

  public getNatBotUserPreferences = async (url: string, datasource: DataSource = DataSource.o365): Promise<IUserSettingsGetResponse> => {
    return this.getDatasourceInstance(datasource).getUserPreferences(url);
  }

  public getNotificationTypes = async (url: string, datasource: DataSource = DataSource.o365): Promise<INotificationTypesGetResponse> => {
    return this.getDatasourceInstance(datasource).getNotificationTypes(url);
  }

  public setNatBotUserPreferences = async (url: string, userSettings: INatBotUserSettings, datasource: DataSource = DataSource.o365): Promise<boolean> => {
    return this.getDatasourceInstance(datasource).setUserPreferences(url, userSettings);

  }
}
