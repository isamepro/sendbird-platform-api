import { INatBotUserSettings, ManageCompetencyStatus } from "../../..";
import * as MicrosoftGraph from '@microsoft/microsoft-graph-types';
import { PersonaPresence } from '@fluentui/react';
import { ITag } from "@fluentui/react";
import { Field } from "../../model/queryResults/ISearchQueryResult";
import { IPhone } from "../../model/IPhone";
import { Guid } from '@microsoft/sp-core-library';
import {
  INotificationTypesGetResponse,
  IUserSettingsGetResponse
} from "../../model/userSettings/IUserSettingsGetResponse";

export interface ICompetenciesResponse {
  head: Head;
  results: Results;
}

export interface Head {
  vars?: (string)[] | null;
}

export interface Results {
  bindings?: (ICompetencyItem | ILanguageCompetencyItem)[] | null;
}

export interface IToolItem {
  id: string;
  guid: Guid;
  titles: ITitleItem[];
  status: Status;
}

export interface ITitleItem {
  title: string;
  language: string;
}

export interface ICompetencyItem {
  comptType: NodeSD;
  feedback: Status;
  email: NodeSD;
  compLabel: CompLabel;
  compId: CompId;
  status: Status;
}

export interface ILanguageCompetencyItem {
  feedback: NodeSD;
  UPN: NodeSD;
  persComp: NodeSD;
  fdbkDate: NodeSD;
  languageId: NodeSD;
  employeeId: NodeSD;
  ability: NodeSD;
  languageCode: NodeSD;
  languageName: LanguageName;
  weightValue: NodeSD;
  status: NodeSD;

}

export interface NodeSD {
  type: string;
  value: string;
}
export interface LanguageName {
  type: string;
  value: string;
  "xml:lang": string | null;
}
export interface CompLabel {
  type: string;
  value: string;
  xml: string | null;
}

export interface Status {
  type: string;
  value: string;
  xml: string | null;
}

export interface CompId {
  type:        Type;
  value:       string;
}

export enum Type {
  Literal = "literal",
  URI = "uri",
}

export enum StardogCompetencyQueryType {
  updateCompetencyFeedback = 'updateCompetencyFeedback',
  insertCompetency = 'insertCompetency'
}

export enum DataOperationQueryType {
  competency,
  language,
  certification,
  software
}

export enum DataSource {
  o365,
  stardog,
  mock,
  microService
}

export interface IExtendedProfil {
  certifications?: IProfilDataItem[];
	suggestedCompetencies?: IProfilDataItem[];
  softwares?: IProfilDataItem[];
  validatedCompetencies?: IProfilDataItem[];
  languages?: IProfilDataItem[];
}

export interface IProfilData extends IExtendedProfil {

  persona?: MicrosoftGraph.User;
  /**
   * Use enum from '@fluentui/react'. If you need another type of presence (northstar, ...), please change the object type.
   *
   * @type {PersonaPresence}
   * @memberof IProfilData
   */
  personaPresence?: PersonaPresence;
  pictureUrl?: string;
  /**
   * O365 formated phone number.
   *
   * @type {IPhone[]}
   * @memberof IProfilData
   */
  phonesFormated?: IPhone[];
  /**
   * Url of user office location (google, Bing, ...).
   *
   * @type {string}
   * @memberof IProfilData
   */
  userLocationMapUrl?: string;
}

export interface IProfilDataItem extends ITag {
  description?: string;
  date?: Date;
  value?: string;
  /**
   * This property is used to specify the status of item (competencies, suggested competencies).
   *
   * @type {StatusValues}
   * @memberof IProfilDataItem
   */
  status?: ManageCompetencyStatus;
  fields?: Field;
  json?: string;
}

export interface IProfilSocialDataService {
  getData( userPrincipalName: string, operationType: DataOperationQueryType, language: string, dataSource?: DataSource): Promise<any>;
  updateProfil( userPrincipalName: string, delta: IExtendedProfil, dataSource?: DataSource): Promise<void>;
  getUserInformation( userPrincipalName: string, dataSource?: DataSource): Promise<IProfilData>;
  getPeopleAround( userPrincipalName: string, offset: number, limit: number, dataSource?: DataSource): Promise<IProfilData[]>;
  updateSuggestedCompetency( userPrincipalName: string, suggestedCompetency: IProfilDataItem, dataSource?: DataSource): Promise<void>;
  getUserPreferences(url: string): Promise<IUserSettingsGetResponse>;
  setUserPreferences(url: string,userSettings: INatBotUserSettings): Promise<boolean>;
  getNotificationTypes(url: string): Promise<INotificationTypesGetResponse>;
}
