import { ConsoleListener, Logger } from "@pnp/logging";
import {
  DataOperationQueryType,
  DataSource,
  ICompetenciesResponse,
  ICompetencyItem,
  IExtendedProfil,
  ILanguageCompetencyItem,
  IProfilData,
  IProfilDataItem,
  IProfilSocialDataService,
  ITitleItem,
  IToolItem
} from "./ProfilSocialService.types";

import { ServiceScope } from '@microsoft/sp-core-library';
import _ from "lodash";
import { INatBotUserSettings, ManageCompetencyStatus } from "../../..";
import {
  INotificationTypesGetResponse,
  IUserSettingsGetResponse
} from "../../model/userSettings/IUserSettingsGetResponse";
import ApimServiceServiceBase from "./ApimServiceServiceBase";
interface KeyValuePair {
  key: string;
  value: string;
}
export class ProfilSocialServiceMicroService extends ApimServiceServiceBase implements IProfilSocialDataService {

  constructor(serviceScope: ServiceScope) {
    super(serviceScope);
    Logger.subscribe(new ConsoleListener());
  }

  public getUserPreferences = async (url: string): Promise<IUserSettingsGetResponse> => {
    throw new Error("Method not implemented.");
  }
  public setUserPreferences = (url: string, userSettings: INatBotUserSettings): Promise<boolean> => {
    throw new Error("Method not implemented.");
  }
  public getNotificationTypes = async (url: string): Promise<INotificationTypesGetResponse> => {
    throw new Error("Method not implemented.");
  }

  /**
  * Return data from Stardog. You need to specify the type of information you want to retrieve.
  *
  * @memberof ProfilSocialServiceStardog
  */
  public getData = async (userPrincipalName: string, operationType: DataOperationQueryType, language: string): Promise<any> => {

    let url: string;
    let result: IProfilDataItem[];

    if (!userPrincipalName || userPrincipalName === '') {
      return Promise.reject('GetDataUserPrincipalNameNullException');
    }

    switch (operationType) {
      case DataOperationQueryType.competency:
        throw new Error("Method not implemented.");
      case DataOperationQueryType.language:
        throw new Error("Method not implemented.");
      case DataOperationQueryType.certification:
        throw new Error("Method not implemented.");

      case DataOperationQueryType.software:
        url = `${await this.getMicroServiceApiUrl()}tool?identifier=${userPrincipalName}`;
        // const toolsFromMicroService: IToolsResponse = await this.doGet(url);
        const toolsFromMicroService = await this.doGet(url);
        // dans le cas d'une erreur cote micro service, on retourne un status code sinon on n'a pas le status code
        result = this.ParseMicroserviceSoftwareToProfilDataItem(toolsFromMicroService, url, language);
        return Promise.resolve(result);
      default:
        break;
    }

  }

  public updateProfil = async (userPrincipalName: string, delta: IExtendedProfil): Promise<void> => {

    if (!userPrincipalName || userPrincipalName === '') {
      return Promise.reject('UpdateProfilUserPrincipalNameNullException');
    }
    if (!delta) {
      return Promise.reject('UpdateProfilDeltaNullException');
    }
    if (delta.softwares) {
      let softwaresIdAndUuid = await this.LoadSoftwareToGetIdFromUuid(delta.softwares, ManageCompetencyStatus.add);
      await this.updateSoftwareOperation(userPrincipalName, 'createtools', "PUT", softwaresIdAndUuid, ManageCompetencyStatus.add);
      await this.updateSoftwareOperation(userPrincipalName, 'deletetools', "DELETE",delta.softwares, ManageCompetencyStatus.delete);
    }
  }

  private LoadSoftwareToGetIdFromUuid = async (softwares: IProfilDataItem[],status : ManageCompetencyStatus): Promise<IProfilDataItem[]> => {
    if (!softwares) return undefined;
    const softwaresFiltered: IProfilDataItem[] = softwares.filter((value: IProfilDataItem) => { return value.status === status; });
    if (!softwaresFiltered || (softwaresFiltered && softwaresFiltered.length === 0)) return Promise.resolve(softwares);

    const softwaresUUID = _.map(softwaresFiltered, 'key');

    const url = `${await this.getMicroServiceApiUrl()}tool?guid=${softwaresUUID.join('&guid=')}`;
    const toolsFromMicroService = await this.doGet(url);
    const result = this.ParseMicroserviceSoftwareToProfilDataItem(toolsFromMicroService, url, "");
    result.forEach(element => {
      element.status = status;
    });
    return (result)?Promise.resolve(result):Promise.resolve(softwares);

  }

  private updateSoftwareOperation = async (userPrincipalName: string, operation: string, method:string, softwares: IProfilDataItem[],status : ManageCompetencyStatus|string): Promise<void> => {
    if (!softwares) return undefined;
    const softwaresFiltered: IProfilDataItem[] = softwares.filter((value: IProfilDataItem) => { return value.status === status; });
    if (!softwaresFiltered || (softwaresFiltered && softwaresFiltered.length === 0)) return undefined;

    const softwaresKeys = _.map(softwaresFiltered, 'key');

    const url = `${await this.getMicroServiceApiUrl()}Person/${userPrincipalName}/${operation}`;
    const body = {toolids: softwaresKeys};

    const reponse = await this.doFetch(url, body,method,"application/json");
    if (reponse.status && reponse.status != 200) {
      throw new Error("microservice ressouce not found at " + url + " message : " + reponse.statusText);
    }
  }


  private ParseMicroserviceSoftwareToProfilDataItem(toolsFromMicroService: any, url: string, language: string): IProfilDataItem[] {
    let result: IProfilDataItem[]=[];
    if (!toolsFromMicroService.statusCode)
      toolsFromMicroService.statusCode = 200;
    switch (toolsFromMicroService.statusCode) {
      case 404:
        throw new Error("microservice ressouce not found at " + url);
        break;
      case 500:
        throw new Error("erreur interne dans le microservice a " + url);
        break;
      case 200:
        toolsFromMicroService.forEach((item: IToolItem) => {

          let titleItem: ITitleItem = item.titles.find(titleInResult => (titleInResult.language.toLowerCase() == language.toLowerCase() || (titleInResult.language == "" && item.titles.length == 1)));

          let tool: IProfilDataItem = {
            key: _.get(item, "id", ""),
            value: _.get(item, "guid", "").toString(),
            name: _.get(titleItem, "title", ""),
            status: (_.get(item, "status", "")).toString().replace("https://ee.kg.bnc.ca/taxonomy#", "") as ManageCompetencyStatus
          };
          result.push(tool);
        });
        break;
      default:
        break;
    }
    return result;
  }

  public getUserInformation(userPrincipalName: string, dataSource: DataSource.o365): Promise<IProfilData> {
    throw new Error("Method not implemented.");
  }

  public getPeopleAround(userPrincipalName: string, offset: number, limit: number): Promise<IProfilData[]> {
    throw new Error("Method not implemented.");
  }

  public updateSuggestedCompetency = async (userPrincipalName: string, suggestedCompetency: IProfilDataItem): Promise<void> => {

    throw new Error("Method not implemented.");
  }

  private getMicroServiceApiUrl = async (): Promise<string> => {
    if (!ApimServiceServiceBase.bncConfiguration) {
      ApimServiceServiceBase.bncConfiguration = await this.tenantPropertiesManagerService.getBncConfiguration();
    }
    return `${ApimServiceServiceBase.bncConfiguration.apimMicroServiceUrl}v1/`;
  }

}
