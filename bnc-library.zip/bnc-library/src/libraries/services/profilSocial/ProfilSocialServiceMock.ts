import { ConsoleListener, Logger } from "@pnp/logging";
import {
  DataOperationQueryType,
  DataSource,
  ICompetenciesResponse,
  ICompetencyItem,
  IExtendedProfil,
  IProfilData,
  IProfilDataItem,
  IProfilSocialDataService,
  StardogCompetencyQueryType } from "./ProfilSocialService.types";
import ApimServiceBase from "./ApimServiceBase";
import { ServiceKey, ServiceScope } from '@microsoft/sp-core-library';
import _ from "lodash";
import { CompetencyStatus, ManageCompetencyStatus } from "./ProfilSocialService.status";
import { INatBotUserSettings } from "../../..";
import {
  INotificationTypesGetResponse,
  IUserSettingsGetResponse
} from "../../model/userSettings/IUserSettingsGetResponse";

import profildata_MOCK from "./fake/jsonMockFiles/ProfilData.json";

export class ProfilSocialServiceMock implements IProfilSocialDataService  {

  constructor() {
    Logger.subscribe(new ConsoleListener());
  }
  public getUserPreferences = async (url: string): Promise<IUserSettingsGetResponse> => {
    throw new Error("Method not implemented.");
  }
  public setUserPreferences = (url: string, userSettings: INatBotUserSettings): Promise<boolean> => {
    throw new Error("Method not implemented.");
  }
  public getNotificationTypes = async (url: string): Promise<INotificationTypesGetResponse> => {
    throw new Error("Method not implemented.");
  }

  /**
  * Return data from Stardog. You need to specify the type of information you want to retrieve.
  *
  * @memberof ProfilSocialServiceStardog
  */
  public getData = async (userPrincipalName: string, operationType: DataOperationQueryType, language: string): Promise<any> => {

    if (!userPrincipalName || userPrincipalName === '') {
      return Promise.reject('GetDataUserPrincipalNameNullException');
    }

    switch(operationType) {
      case DataOperationQueryType.competency:
        return new Promise<IProfilDataItem[]>(async (resolve) => {
            resolve(profildata_MOCK.validatedCompetencies);
          });
        break;
        case DataOperationQueryType.language:
            return new Promise<IProfilDataItem[]>(async (resolve) => {
                resolve(profildata_MOCK.languages);
              });
          break;  
        case DataOperationQueryType.software:
            return new Promise<IProfilDataItem[]>(async (resolve) => {
                resolve(profildata_MOCK.tools);
              });
          break;  
      default:
        break;
    }

  }

  public updateProfil = async (userPrincipalName: string, delta: IExtendedProfil): Promise<void> => {

    if (!userPrincipalName || userPrincipalName === '') {
      return Promise.reject('UpdateProfilUserPrincipalNameNullException');
    }
    if (!delta) {
      return Promise.reject('UpdateProfilDataNullException');
    }
  }

  public getUserInformation(userPrincipalName: string, dataSource: DataSource.o365): Promise<IProfilData> {
    return new Promise<IProfilData>(async (resolve) => {
        resolve(profildata_MOCK);
      });
  }

  public getPeopleAround(userPrincipalName: string, offset: number, limit: number): Promise<IProfilData[]> {
    throw new Error("Method not implemented.");
  }

  public updateSuggestedCompetency = async (userPrincipalName: string, suggestedCompetency: IProfilDataItem): Promise<void> => {

    if (!userPrincipalName || userPrincipalName === '') {
      return Promise.reject('UpdateSuggestedCompetencyUserPrincipalNameNullException');
    }
    if (!suggestedCompetency) {
      return Promise.reject('UpdateSuggestedCompetencyNullException');
    }
  }

  

}
