import { ConsoleListener, Logger } from "@pnp/logging";
import {FormatHelper, INatBotUserSettings, INotificationType} from "../../..";
import { DataOperationQueryType, DataSource, IExtendedProfil, IProfilData, IProfilDataItem, IProfilSocialDataService } from "./ProfilSocialService.types";
import { ServiceScope } from '@microsoft/sp-core-library';
import * as MicrosoftGraph from '@microsoft/microsoft-graph-types';
import _ from "lodash";
import { bncHeadquarterAddress } from "../../constants/Constants";
import { IPhone } from "../../model/IPhone";
import {
  INotificationTypesGetResponse,
  IUserSettingsGetResponse
} from "../../model/userSettings/IUserSettingsGetResponse";
import { HttpClientResponse } from '@microsoft/sp-http';
import { Utils } from "../../../helpers/Utils";
import ApimMhiServiceBase from "./ApimMhiServiceBase";

export class ProfilSocialServiceO365 extends ApimMhiServiceBase implements IProfilSocialDataService  {

  constructor(serviceScope: ServiceScope) {
    super(serviceScope);

    Logger.subscribe(new ConsoleListener());
  }

  public getData(userPrincipalName: string, operationType: DataOperationQueryType): Promise<any> {
    throw new Error("Method not implemented.");
  }

  public updateProfil(userPrincipalName: string, delta: IExtendedProfil): Promise<void> {
    throw new Error("Method not implemented.");
  }

  public getUserInformation = async (userPrincipalName: string): Promise<IProfilData> => {

    try {
      // s'il n'y a pas d'email, alors on retourne le compte de l'usager courant
      const api = (userPrincipalName === '') ? '/me' : `/users/${userPrincipalName}`;

      this.msGraphClient = await this.msGraphClientFactory.getClient().then();
      const user: MicrosoftGraph.User = await this.msGraphClient.api(api).version(this.o365ApiVersion)
          .select([
            "JobTitle",
            "preferredLanguage",
            "businessPhones",
            "mobilePhone",
            "displayName",
            "officeLocation",
            "userPrincipalName",
            "streetAddress",
            "city",
            "mail",
            "state",
            "usageLocation",
            "postalCode",
            "skills",
            "interests"])
          .get();

      return Promise.resolve({
        persona: user,
        pictureUrl: `/_layouts/15/userphoto.aspx?size=L&username=${user.userPrincipalName}`,
        phonesFormated: this.getPhoneFromO365(user),
        userLocationMapUrl: this.getMapLocationUrl(user)
      });
    } catch (error) {
      // Si l'exception provient du graph, elle est deja ajouté dans le log. si ce n'est pas une exception MS alors retourner le message.
        throw (error && Utils.isJson(error)) ? error.code : error;
    }

  }

  public getPeopleAround = async (userPrincipalName: string, offset: number, limit: number): Promise<IProfilData[]> => {

      let result: IProfilData[] = [];
      // s'il n'y a pas d'email, alors on retourne le compte de l'usager courant
      let api = (userPrincipalName === '') ? '/me/people' : `/users/${userPrincipalName}/people`;
      try {
        this.msGraphClient = await this.msGraphClientFactory.getClient().then();
        let users: any = await this.msGraphClient.api(api).version(this.o365ApiVersion)
            .select([
              "JobTitle",
              "phones",
              "displayName",
              "officeLocation",
              "userPrincipalName",
              "scoredEmailAddresses",
              "birthday",
              "surname",
              "givenName",
              "department",
              "imAddress"])
            .filter(`personType/class eq 'Person' and personType/subclass eq 'OrganizationUser'`)
            .count(true).skip(offset).top(limit)
            .get();

        users.value.map((user: MicrosoftGraph.User) => {
          if (user.userPrincipalName.toLocaleLowerCase() !== userPrincipalName.toLocaleLowerCase()) {
            result.push({
              persona: user,
              pictureUrl: `/_layouts/15/userphoto.aspx?size=L&username=${user.userPrincipalName}`,
              phonesFormated: this.getPhoneFromO365(user),
              userLocationMapUrl: this.getMapLocationUrl(user)
            });
          }
        });

        return Promise.resolve(result);
    } catch (error) {
      // Si l'exception provient du graph, elle est deja ajouté dans le log. si ce n'est pas une exception MS alors retourner le message.
        throw (error && Utils.isJson(error)) ? error.code : error;
    }
  }
  public updateSuggestedCompetency(userPrincipalName: string, suggestedCompetency: IProfilDataItem): Promise<void> {
    throw new Error("Method not implemented.");
  }

  public getUserPreferences = async (url: string): Promise<IUserSettingsGetResponse> => {
    const userSettings: INatBotUserSettings = await this.doGet(url);
    return Promise.resolve({natBotUserSettings: userSettings, requestStatus: true});
  }


  public getNotificationTypes = async (url: string): Promise<INotificationTypesGetResponse> => {
    const types: INotificationType[] = await this.doGet(url);
    return Promise.resolve({notificationTypes: types, requestStatus: true});
  }

  public setUserPreferences = async (url: string, userSettings: INatBotUserSettings): Promise<boolean> => {
    const body = JSON.stringify(userSettings);
    const result: HttpClientResponse = await this.doPost(url, body, 'application/json');

    return Promise.resolve(result.ok);
  }

  private getPhoneFromO365(persona: MicrosoftGraph.User): IPhone[] {
    let phones: IPhone[] = [];
    if (_.get(persona, 'businessPhones[0]') !== undefined) phones.push(this.getIPhoneFromO365(persona.businessPhones[0]));
    if (_.get(persona, 'mobilePhone') !== undefined) phones.push(this.getIPhoneFromO365(persona.mobilePhone));

    return phones;
  }

	/***************************************************************************************
    * @param {string} phone
    * @example :+1 5141112222x123 or 514-412-6041; 26041
    * @returns {IPhone}
    **************************************************************************************/
  private getIPhoneFromO365(phonefield: string): IPhone {
    let phone: string = this.getFieldValue(phonefield).replace('x', ';');
    if (phone === '+') return undefined;
    if (phone.indexOf(';') > 0) {
      let values = phone.split(';');

      return { phone: FormatHelper.formatPhoneNumber(values[0]), ext: values[1].replace(/[^0-9]/g, '').trim() };
    } else {
      return { phone: FormatHelper.formatPhoneNumber(phone), ext: undefined };
    }
  }

  private getMapLocationUrl = (persona: MicrosoftGraph.User) : string => {
    const googleMapUrlQuery: string = 'https://maps.google.com/maps?q=';
    const googleEmbedUrl: string = '&t=&z=13&ie=UTF8&iwloc=&output=embed';
    const cityStateCountryZipCode = `${this.getFieldValue(persona.city).trim()} ${this.getFieldValue(persona.state).trim()} ${this.getFieldValue(persona.usageLocation).trim()} ${this.getFieldValue(persona.postalCode).trim()}`;
    const formatGoogleMapUrl = this.getFieldValue(persona.streetAddress).trim() + cityStateCountryZipCode.trim();

    return formatGoogleMapUrl.trim() === ''
        ? `${googleMapUrlQuery}${encodeURI(bncHeadquarterAddress)}${googleEmbedUrl}`
        : `${googleMapUrlQuery}${encodeURI(formatGoogleMapUrl)}${googleEmbedUrl}`;

  }
}
