import { ConsoleListener, Logger } from "@pnp/logging";
import {
  DataOperationQueryType,
  DataSource,
  ICompetenciesResponse,
  ICompetencyItem,
  IExtendedProfil,
  ILanguageCompetencyItem,
  IProfilData,
  IProfilDataItem,
  IProfilSocialDataService,
  StardogCompetencyQueryType
} from "./ProfilSocialService.types";
import { ServiceKey, ServiceScope } from '@microsoft/sp-core-library';
import _ from "lodash";
import { CompetencyStatus, ManageCompetencyStatus } from "./ProfilSocialService.status";
import { INatBotUserSettings } from "../../..";
import {
  INotificationTypesGetResponse,
  IUserSettingsGetResponse
} from "../../model/userSettings/IUserSettingsGetResponse";
import ApimMhiServiceBase from "./ApimMhiServiceBase";

export class ProfilSocialServiceStardog extends ApimMhiServiceBase implements IProfilSocialDataService {

  constructor(serviceScope: ServiceScope) {
    super(serviceScope);
    Logger.subscribe(new ConsoleListener());
  }
  public getUserPreferences = async (url: string): Promise<IUserSettingsGetResponse> => {
    throw new Error("Method not implemented.");
  }
  public setUserPreferences = (url: string, userSettings: INatBotUserSettings): Promise<boolean> => {
    throw new Error("Method not implemented.");
  }
  public getNotificationTypes = async (url: string): Promise<INotificationTypesGetResponse> => {
    throw new Error("Method not implemented.");
  }

  /**
  * Return data from Stardog. You need to specify the type of information you want to retrieve.
  *
  * @memberof ProfilSocialServiceStardog
  */
  public getData = async (userPrincipalName: string, operationType: DataOperationQueryType, language: string): Promise<any> => {

    let url: string;
    let result: IProfilDataItem[];

    if (!userPrincipalName || userPrincipalName === '') {
      return Promise.reject('GetDataUserPrincipalNameNullException');
    }

    switch (operationType) {
      case DataOperationQueryType.competency:
        url = `${this.getStardogApiUrl()}/query?query=getPersonCurrentCompetency&$UPN='${userPrincipalName}'&$limit=1&$language='${language}'`;
        const comptenciesFromStardog: ICompetenciesResponse = await this.doGet(url);
        // const comptenciesFromStardog = await this.doGet(url);
        result = comptenciesFromStardog.results.bindings.map((item: ICompetencyItem) => {
          return {
            key: item.compId.value.toString(),
            name: item.compLabel.value,
            fields: {
              ['competencyStatus']: item.status.value as CompetencyStatus,
              // ['competenceType']:item.comptType.value
            }
          };
        });
        return Promise.resolve(result);

      case DataOperationQueryType.language:
        url = `${this.getStardogApiUrl()}/query?query=getPersonCurrentLanguageCompetency&$UPN='${userPrincipalName}'&$language='${language}'`;
        const languagesComptenciesFromStardog: ICompetenciesResponse = await this.doGet(url);
        languagesComptenciesFromStardog.results.bindings.forEach((item: ILanguageCompetencyItem) => {
          let languageContetency: IProfilDataItem;
          if (result) {
            languageContetency = result.find(itemInResult => itemInResult.key == _.get(item,"languageId.value",""));
          } 
          else {
            result = [];
          }
          if (languageContetency) {
            languageContetency.fields[_.get(item,"ability.value","")] = _.get(item,"weightValue.value","");
          }
          else {
            languageContetency = {
              key: _.get(item,"languageId.value",""),
              name: _.get(item,"languageName.value",""),
              value:"3" // a changer apres avoir recu la maquette

            };
            languageContetency.fields={};
            languageContetency.fields[_.get(item,"ability.value","")] = _.get(item,"weightValue.value");
            result.push(languageContetency);
          }
        });
        return Promise.resolve(result);
      default:
        break;
    }

  }

  public updateProfil = async (userPrincipalName: string, delta: IExtendedProfil): Promise<void> => {

    if (!userPrincipalName || userPrincipalName === '') {
      return Promise.reject('UpdateProfilUserPrincipalNameNullException');
    }
    if (!delta) {
      return Promise.reject('UpdateProfilDataNullException');
    }

    const bodyInserted = this.getCompetencyHttpBodyForStarDogQuery(userPrincipalName, delta.validatedCompetencies, ManageCompetencyStatus.add);
    const bodyDeteled = this.getCompetencyHttpBodyForStarDogQuery(userPrincipalName, delta.validatedCompetencies, ManageCompetencyStatus.delete);

    const urlPrefix = `${this.getStardogApiUrl()}/update?query=`;

    let promises: any[] = [];
    if (bodyDeteled) {
      promises.push(this.doPost(urlPrefix + StardogCompetencyQueryType.updateCompetencyFeedback, bodyDeteled));
    }
    if (bodyInserted) {
      promises.push(this.doPost(urlPrefix + StardogCompetencyQueryType.insertCompetency, bodyInserted));
    }

    await Promise.all(promises);
  }

  public getUserInformation(userPrincipalName: string, dataSource: DataSource.o365): Promise<IProfilData> {
    throw new Error("Method not implemented.");
  }

  public getPeopleAround(userPrincipalName: string, offset: number, limit: number): Promise<IProfilData[]> {
    throw new Error("Method not implemented.");
  }

  public updateSuggestedCompetency = async (userPrincipalName: string, suggestedCompetency: IProfilDataItem): Promise<void> => {

    if (!userPrincipalName || userPrincipalName === '') {
      return Promise.reject('UpdateSuggestedCompetencyUserPrincipalNameNullException');
    }
    if (!suggestedCompetency) {
      return Promise.reject('UpdateSuggestedCompetencyNullException');
    }

    const competencies: IProfilDataItem[] = [suggestedCompetency];
    const body = this.getCompetencyHttpBodyForStarDogQuery(userPrincipalName, competencies, suggestedCompetency.status as ManageCompetencyStatus);
    const url = `${this.getStardogApiUrl()}/update?query=${StardogCompetencyQueryType.updateCompetencyFeedback}`;

    await this.doPost(url, body);
  }

  private getCompetencyHttpBodyForStarDogQuery = (userPrincipalName: string, competencies: IProfilDataItem[], status: ManageCompetencyStatus): string => {

    const competenciesFiltered: IProfilDataItem[] = competencies.filter((value: IProfilDataItem) => { return value.status === status; });
    if (!competenciesFiltered || (competenciesFiltered && competenciesFiltered.length === 0)) return undefined;

    const competenciesKeys = _.map(competenciesFiltered, 'key');
    const competenciesJoined = _.join(competenciesKeys, ',,,');

    var urlEncoded = new URLSearchParams();
    urlEncoded.append("$UPN", `\"${userPrincipalName}\"`);
    urlEncoded.append("$compId", `\"${competenciesJoined}\"`);
    if (status === ManageCompetencyStatus.delete || status === ManageCompetencyStatus.sugested) {
      urlEncoded.append("$inputFdbk", `\"${status}\"`);
    }

    return urlEncoded.toString();
  }

  private getStardogApiUrl = (): string => {
    return `${ApimMhiServiceBase.bncConfiguration.apimUrl}/stardog/Profil_Social`;
  }

}
