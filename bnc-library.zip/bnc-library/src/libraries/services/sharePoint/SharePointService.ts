import { ServiceKey, ServiceScope } from '@microsoft/sp-core-library';
import { SPHttpClient, SPHttpClientResponse } from "@microsoft/sp-http";
import { PageContext } from '@microsoft/sp-page-context';
import { AadHttpClientFactory, HttpClient, HttpClientResponse, IHttpClientOptions } from '@microsoft/sp-http';

export interface ISharePointService {
    getTenantProperty(key: string): Promise<string>;
}

export interface ITenantProperty {
  '@odata.null'?: boolean;
  Value: string;
  Description?: string;
  Comment?: string;
}

export class SharePointService implements ISharePointService {
  private spHttpClient: SPHttpClient;
  private pageContext: PageContext;

  public static readonly serviceKey: ServiceKey<ISharePointService> =
      ServiceKey.create<SharePointService>(`BNC:ISharePointService`, SharePointService);

  constructor(serviceScope: ServiceScope) {
    serviceScope.whenFinished(() => {
      this.spHttpClient = serviceScope.consume(SPHttpClient.serviceKey);
      this.pageContext = serviceScope.consume(PageContext.serviceKey);
    });
  }

  public getTenantProperty(value: string): Promise<string> {
    return new Promise<string>((resolve: (value: string) => void, reject: (error: any) => void): void => {
      this.spHttpClient
        .get(`${this.pageContext.web.absoluteUrl}/_api/web/GetStorageEntity('${value}')`, SPHttpClient.configurations.v1)
        .then((res: SPHttpClientResponse) => {
          return res.json();
        })
        .then((tenantProperty: ITenantProperty) => {
          resolve(tenantProperty.Value);
        });
    });
  }
}
