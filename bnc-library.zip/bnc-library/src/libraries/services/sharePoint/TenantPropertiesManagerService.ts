import { ConsoleListener, Logger, LogLevel } from "@pnp/logging";
import { ISharePointService, SharePointService } from "./SharePointService";
import { ServiceKey, ServiceScope } from '@microsoft/sp-core-library';
import { IBncConfiguration } from "../../model/commun/IBncConfiguration";
import { ClientStorageService } from "../common/ClientStorageService";
import { bncTenantPropertiesNamespaceCommon } from "../../constants/Constants";

export interface ITenantPropertiesManagerService {
  getStringProperty(key: string): Promise<string>;
  getBncConfiguration(): Promise<IBncConfiguration>;
  getProperty<T>(key: string): Promise<T>;
}

/**
 * This class helps retrieving properties from SharePoint Tenant Properties or Session Storage.
 *
 * @export
 * @class TenantPropertiesManager
 */
export class TenantPropertiesManagerService   {
  private sharepointService: ISharePointService;

  //#region Public Static Members
  public static serviceKey: ServiceKey<ITenantPropertiesManagerService> =
  ServiceKey.create<ITenantPropertiesManagerService>(`BNC:ITenantPropertiesManagerService`, TenantPropertiesManagerService);
  //#endregion

  constructor(serviceScope: ServiceScope) {
    serviceScope.whenFinished(() => {
      this.sharepointService = serviceScope.consume(SharePointService.serviceKey);
    });
    Logger.subscribe(new ConsoleListener());
  }

  public getStringProperty = async (key: string): Promise<string> =>{
    // Add session storage logic
    let result: string = ClientStorageService.get(key);
    if (!result){
      result = await this.sharepointService.getTenantProperty(key);
      ClientStorageService.put(key, result);
    }

    return Promise.resolve(result);
  }

  public async getProperty<T>(key: string): Promise<T> {
    const value = await this.getStringProperty(key);
    if (!value) return undefined;

    const obj: T = JSON.parse(value);

    return Promise.resolve(obj);
  }

  /**
   * Return an object of global config BNC.Common
   *
   * @memberof TenantPropertiesManagerService
   */
  public getBncConfiguration = async (): Promise<IBncConfiguration> => {

    try {

      const value = await this.getProperty<IBncConfiguration>(bncTenantPropertiesNamespaceCommon);
      return Promise.resolve(value);
    } catch (error) {

      Logger.error (error);
      throw error;
    }
  }

}
