import { SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';
import { User } from '@microsoft/microsoft-graph-types';
import _ from 'lodash';
import { IATM } from '../../model/succursales/IATM';
import { ITransit } from '../../model/succursales/ITransit';
import { ATM } from '../../model/succursales/ATM';
import { Transit } from '../../model/succursales/Transit';
import { ISuccursaleHours } from '../../model/succursales/ISuccursaleHours';
import { SuccursaleHours } from '../../model/succursales/SuccursaleHours';
import { ISuccursaleDetail } from '../../model/succursales/ISuccursaleDetail';
import { IPaging } from '../../model/paging/IPaging';
import { IRawDataService, SearchPersonasService, ISearchProfilsService, IHubServiceFactoryContext } from '../../..';
import { ISearchQueryResults } from '../../model/queryResults/ISearchQueryResults';
import { IRefinementValue } from '../../model/refinement/IRefinement';
import { ISearchQueryResult } from '../../model/queryResults/ISearchQueryResult';
import { searchQueryResultFields, EnumLinePersonaData } from '../../constants/Constants';
import StardogServiceBase from '../common/StardogServiceBase';
import { INearestAtm } from '../../model/succursales/INearestAtm';
import { Logger, ConsoleListener } from '@pnp/logging';
import { ISuccursalesService, ISuccursalesServiceSetting } from './SuccursalesService.types';
import { IPersonaData } from '../../model/Profil/persona/IPersonaData';


export class SuccursalesService extends StardogServiceBase implements ISuccursalesService {

    private httpClient: SPHttpClient;
    private listeSuccursales: ISearchQueryResults = null;
    private webUrl: string;
    private succursaleslistName: string;
    private transitHoursListName: string;
    private atmHoursListName: string;


    public constructor(context: IHubServiceFactoryContext, spHttpClient: any, absoluteUrl:string, settings:ISuccursalesServiceSetting) {
      super(context);

      this.language = context.language;
      this.httpClient = spHttpClient;
      Logger.subscribe(new ConsoleListener());

      this.listeSuccursales = { values: [], total: 0, isNewQuery: true };
      const webAbsoluteUrl: string = absoluteUrl;
      if (!settings.succursalesListName) {
          this.succursaleslistName = "Transit";
      }
      else {
          this.succursaleslistName = settings.succursalesListName;
      }

      if (!settings.transitHoursListName) {
          this.transitHoursListName = "Transit_Hours";
      }
      else {
          this.transitHoursListName = settings.transitHoursListName;
      }

      if (!settings.atmHoursListName) {
          this.atmHoursListName = "ATM_Hours";
      }
      else {
          this.atmHoursListName = settings.atmHoursListName;
      }

      if (!settings.url) {
          this.webUrl = webAbsoluteUrl;
      }
      else {
          this.webUrl = settings.url;
      }
    }
    /**
     *Cette fonction permet de retourner tous les ATMs proches d'un ATM
    *
    * @memberof SuccursalesService
    */
    public getBranchNearestAtm = (transit: string, limit: number):  Promise<ISearchQueryResults> => {

      return new Promise<ISearchQueryResults> (async (resolve, reject) => {

        const query: string = `getBranchNearestATM&$inputTransit="${transit}"&limit=${limit}&offset=0&$language="${this.language}"&$minDistance=1`;
        this.getData(query)
        .then((response: SPHttpClientResponse) => {

          try {

            let result : ISearchQueryResults = { values: [], isNewQuery: true, total: 0 };
            response.json().then((data) => {
              data.results.bindings.map((neareastAtm: INearestAtm) => {
                if (neareastAtm){
                  // On fait une verification ici pour valider que les champs suivants ne sont pas vides.
                  // Stardog retourne des lignes vides quand il n'y a aucun resultat.
                    const address = _.get(neareastAtm, "outputStreetAddr.value", "");
                    const city = _.get(neareastAtm, "outputCity.value", "");
                    const distance = _.get(neareastAtm, "distance.value", "");

                    if (!!address && !!city && !!distance) {
                    let atm: ISearchQueryResult = {
                      title: neareastAtm.outputStreetAddr.value,
                      type: 'ATM',
                      fields: {
                        [searchQueryResultFields.displaySiteFr]: address,
                        [searchQueryResultFields.displaySiteEn]:  address,
                        [searchQueryResultFields.transitId]: neareastAtm.inputTransit.value,
                        [searchQueryResultFields.postalCode]: neareastAtm.outputZipCode.value,
                        [searchQueryResultFields.displayCityFr]: city,
                        [searchQueryResultFields.displayCityEn]: city,
                        [searchQueryResultFields.provinceFr]: neareastAtm.outputProv.value,
                        [searchQueryResultFields.provinceEn]: neareastAtm.outputProv.value,
                        [searchQueryResultFields.distanceAtm]: distance
                      }
                    };

                    result.values.push(atm);
                  }
                }
              });

              result.total = result.values.length;
              return resolve(result);
            });

          } catch (error) {
            Logger.write(`Une erreur s'est produite dans le traitement de 'getBranchNearestAtm': ${error}`);
          }

        }, (error: any): void => {
          return reject(`Can retrieve nearest ATMs : ${error} `);
        });

      });
    }

    public getSuccursales = (searchValue: string, maxRows: number, offset: number, pageSize: number): Promise<{ data: ISearchQueryResults, filters: IRefinementValue[] }> => {


        let url: string = this.webUrl;

        url += "/_api/Lists/getByTitle('" + this.succursaleslistName + "')/items?" +
            "$select=ATM_Id,Transit_Id,WithDraw_Only,Exchange,Open_24h_7d,Printer,Civic_Num,Display_Street_Fr,Display_Street_En,"
            + "Display_City_Fr,Display_City_En,Postal_Code,Province_Fr,Province_En,Handicapped_Access,Display_Intersection_Fr,Display_Intersection_En,"
            + "Display_Site_Fr,Display_Site_En,Display_Name_Fr,Display_Name_En,Phone,Fax,ATM_Count,Exchange_Office,Transit_Type_Id,"
            + "Transit_Type_Fr,Transit_Type_En,SuccursalesType";

        //filter
        if (searchValue !== "*") {
            // url += `&$filter=(substringof(%27${searchValue}%27,Display_Street_Fr))`;
            url += `&$filter=(substringof(%27${searchValue}%27,Display_Street_Fr) or substringof(%27${this.getTransit(searchValue)}%27,Transit_Id) or`;
            url += ` substringof(%27${searchValue}%27,ATM_Id) or substringof(%27${searchValue}%27,Civic_Num) or substringof(%27${searchValue}%27,Display_Street_En) or`;
            url += ` substringof(%27${searchValue}%27,Display_City_Fr) or substringof(%27${searchValue}%27,Display_City_En) or substringof(%27${searchValue}%27,Postal_Code) or`;
            url += ` substringof(%27${searchValue}%27,Province_Fr) or substringof(%27${searchValue}%27,Province_En) or substringof(%27${searchValue}%27,Display_Name_Fr) or`;
            url += ` substringof(%27${searchValue}%27,Display_Name_En) or substringof(%27${searchValue}%27,Phone) or substringof(%27${searchValue}%27,Fax) or`;
            url += ` substringof(%27${searchValue}%27,Display_Intersection_Fr) or substringof(%27${searchValue}%27,Display_Intersection_En) or substringof(%27${searchValue}%27,Display_Site_Fr) or`;
            url += ` substringof(%27${searchValue}%27,Display_Site_En) or substringof(%27${searchValue}%27,Transit_Type_Fr) or substringof(%27${searchValue}%27,Transit_Type_En))`;
        }

        if (maxRows != -1) {
            url += `&$top=${maxRows}`;
        }
        // else {
        //     //url += `&$skiptoken=Paged=TRUE%26p_ID=${offset}&$top=${pageSize}`;
        //     url += `&$top=${offset + pageSize}`;
        // }
        const self = this;
        return this.httpClient.get(url, SPHttpClient.configurations.v1)
            .then((response: SPHttpClientResponse) => {
                return response.json().then((data) => {
                    //data["@odata.nextLink"]
                    if (data.value) {
                        let i = 1;
                        data.value.forEach(spTransit => {
                            if ((i > offset && i <= offset + pageSize) || (maxRows != -1)) {
                                let succursaleAtm: ISearchQueryResult = {
                                    title: spTransit.Title,
                                    type: spTransit.SuccursalesType,
                                    fields: {
                                        [searchQueryResultFields.transitId]: spTransit.Transit_Id,
                                        [searchQueryResultFields.open24h7d]: spTransit.Open_24h_7d,
                                        [searchQueryResultFields.printer]: spTransit.Printer,
                                        [searchQueryResultFields.civicNum]: spTransit.Civic_Num,
                                        [searchQueryResultFields.displayStreetFr]: spTransit.Display_Street_Fr,
                                        [searchQueryResultFields.displayStreetEn]: spTransit.Display_Street_En,
                                        [searchQueryResultFields.displayCityFr]: spTransit.Display_City_Fr,
                                        [searchQueryResultFields.displayCityEn]: spTransit.Display_City_En,
                                        [searchQueryResultFields.postalCode]: spTransit.Postal_Code,
                                        [searchQueryResultFields.provinceFr]: spTransit.Province_Fr,
                                        [searchQueryResultFields.provinceEn]: spTransit.Province_En,
                                        [searchQueryResultFields.handicappedAccess]: spTransit.Handicapped_Access,
                                        [searchQueryResultFields.displayIntersectionFr]: spTransit.Display_Intersection_Fr,
                                        [searchQueryResultFields.displayIntersectionEn]: spTransit.Display_Intersection_En,
                                        [searchQueryResultFields.displaySiteFr]: spTransit.Display_Site_Fr,
                                        [searchQueryResultFields.displaySiteEn]: spTransit.Display_Site_En
                                    }
                                };
                                if (spTransit.SuccursalesType == "ATM") {
                                    succursaleAtm.fields[searchQueryResultFields.atmId] = spTransit.ATM_Id;
                                    succursaleAtm.fields[searchQueryResultFields.withDrawOnly] = spTransit.WithDraw_Only;
                                    succursaleAtm.fields[searchQueryResultFields.exchange] = spTransit.Exchange;
                                }
                                else {
                                    succursaleAtm.fields[searchQueryResultFields.displayNameFr] = spTransit.Display_Name_Fr;
                                    succursaleAtm.fields[searchQueryResultFields.displayNameEn] = spTransit.Display_Name_En;
                                    succursaleAtm.fields[searchQueryResultFields.phone] = spTransit.Phone;
                                    succursaleAtm.fields[searchQueryResultFields.fax] = spTransit.Fax;
                                    succursaleAtm.fields[searchQueryResultFields.aTMCount] = spTransit.ATM_Count;
                                    succursaleAtm.fields[searchQueryResultFields.exchangeOffice] = spTransit.Exchange_Office;
                                    succursaleAtm.fields[searchQueryResultFields.transitTypeId] = spTransit.Transit_Type_Id;
                                    succursaleAtm.fields[searchQueryResultFields.transitTypeFr] = spTransit.Transit_Type_Fr;
                                    succursaleAtm.fields[searchQueryResultFields.transitTypeEn] = spTransit.Transit_Type_En;
                                }
                                self.listeSuccursales.values.push(succursaleAtm);
                            }
                            i++;
                        });
                        self.listeSuccursales.total = data.value.length;
                        return {
                            data: self.listeSuccursales,
                            filters: []
                        };
                    }
                });
            });
    }

    public getSuccursalesByTransit = (transitId: string, atmId: string): Promise<IATM | ITransit> => {

        let url: string = this.webUrl;
        url += "/_api/Lists/getByTitle('" + this.succursaleslistName + "')/items?" +
            "$select=ATM_Id,Transit_Id,WithDraw_Only,Exchange,Open_24h_7d,Printer,Civic_Num,Display_Street_Fr,Display_Street_En,"
            + "Display_City_Fr,Display_City_En,Postal_Code,Province_Fr,Province_En,Handicapped_Access,Display_Intersection_Fr,Display_Intersection_En,"
            + "Display_Site_Fr,Display_Site_En,Display_Name_Fr,Display_Name_En,Phone,Fax,ATM_Count,Exchange_Office,Transit_Type_Id,"
            + "Transit_Type_Fr,Transit_Type_En,SuccursalesType";

        if (transitId) {
            transitId = this.getTransit(transitId);
            url += `&$filter=(Transit_Id eq ${transitId})`;
        }
        if (atmId) {
            url += `&$filter=(ATM_Id eq ${atmId})`;
        }
        url += `&$top=1`;

        return this.httpClient.get(url, SPHttpClient.configurations.v1)
            .then((response: SPHttpClientResponse) => {
                return response.json().then(async (data) => {
                    //data["@odata.nextLink"]
                    if (data.value) {
                        let returnValue: IATM | ITransit;
                        const spTransit = data.value[0];

                        if (spTransit.SuccursalesType == "ATM") {
                            returnValue = new ATM(spTransit.ATM_Id, spTransit.WithDraw_Only, spTransit.Exchange, spTransit.Title, spTransit.Open_24h_7d,
                                spTransit.Printer, spTransit.Civic_Num, spTransit.Display_Street_Fr, spTransit.Display_Street_En, spTransit.Display_City_Fr,
                                spTransit.Display_City_En, spTransit.Postal_Code, spTransit.Province_Fr, spTransit.Province_En, spTransit.Handicapped_Access,
                                spTransit.Display_Intersection_Fr, spTransit.Display_Intersection_En, spTransit.Display_Site_Fr, spTransit.Display_Site_En,
                                spTransit.Transit_Id);
                        }
                        else {
                            returnValue = new Transit(spTransit.Display_Name_Fr, spTransit.Display_Name_En, spTransit.Phone, spTransit.Fax,
                                spTransit.ATM_Count, spTransit.Exchange_Office,
                                spTransit.Transit_Type_Id, spTransit.Transit_Type_Fr, spTransit.Transit_Type_En, spTransit.Title, spTransit.Open_24h_7d,
                                spTransit.Printer, spTransit.Civic_Num, spTransit.Display_Street_Fr, spTransit.Display_Street_En, spTransit.Display_City_Fr,
                                spTransit.Display_City_En, spTransit.Postal_Code, spTransit.Province_Fr, spTransit.Province_En, spTransit.Handicapped_Access,
                                spTransit.Display_Intersection_Fr, spTransit.Display_Intersection_En, spTransit.Display_Site_Fr, spTransit.Display_Site_En,
                                spTransit.Transit_Id);
                        }
                        returnValue.hours = await this.getSuccursalesHoursByTransit(transitId, atmId).then((hours) => {
                            return hours;
                        });
                        return returnValue;
                    }
                });
            });
    }

    private getSuccursalesHoursByTransit = (transitId: string, atmId: string): Promise<ISuccursaleHours[]> => {
        let url: string = this.webUrl;
        url += "/_api/Lists/getByTitle('";

        if (transitId) {
            transitId = this.getTransit(transitId);
            url += this.transitHoursListName + "')/items?" +
                "$select=ID,Title,Hours_Id,Transit_Id,Hours_Type_Id,Day_Of_Week,Open_Hour_1,"
                + "Close_Hour_1,Open_Hour_2,Close_Hour_2,Open_Hour_3,Close_Hour_3,"
                + "Day_Of_Week_En,Day_Of_Week_Fr,Hours_Type_En,Hours_Type_Fr";

            url += `&$filter=(Transit_Id eq ${transitId})`;

        }
        else {

            url += this.atmHoursListName + "')/items?" +
                "$select=ID,Title, Hours_Id,ATM_Id,Hours_Type_Id,Day_Of_Week,Open_Hour_1,Close_Hour_1,"
                + "Open_Hour_2,Close_Hour_2,Open_Hour_3,Close_Hour_3";

            url += `&$filter=(ATM_Id eq ${atmId})`;
        }

        return this.httpClient.get(url, SPHttpClient.configurations.v1)
            .then((response: SPHttpClientResponse) => {
                return response.json().then((data) => {
                    let returnValue: ISuccursaleHours[] = [];
                    if (data.value) {
                        data.value.forEach(spHour => {
                            returnValue.push(new SuccursaleHours(spHour.id, spHour.Hours_Type_Id,
                                spHour.Day_Of_Week,
                                spHour.Open_Hour_1, spHour.Close_Hour_1,
                                spHour.Open_Hour_2, spHour.Close_Hour_2,
                                spHour.Open_Hour_3, spHour.Close_Hour_3,
                                spHour.Day_Of_Week_En, spHour.Day_Of_Week_Fr,
                                spHour.Hours_Type_En, spHour.Hours_Type_Fr));
                        });
                        return returnValue;
                    }
                });
            });
    }

    public getSuccursaleDetailByTransit = (transitId: string, atmId: string, succursaleFieldLabels: any, paging: IPaging, rawDataService: IRawDataService): Promise<ISuccursaleDetail> => {

        let succursaleDetail: ISuccursaleDetail = undefined;

        return new Promise<ISuccursaleDetail>((resolve, reject) => {
            try {

                this.getSuccursalesByTransit(transitId, atmId).then(async succursale => {
                    console.log("after getSuccursalesByTransit " , succursale);
                    succursaleDetail = { detail: undefined, address: undefined, contacts: undefined };
                    succursaleDetail.detail = JSON.stringify(succursale);
                    succursaleDetail.address = (succursale.civicNum + ' ' + succursale[succursaleFieldLabels.displayStreet] + ', ' + succursale[succursaleFieldLabels.displayCity] + ' ' + _.get(succursale, succursaleFieldLabels.province, '') + ' ' + _.get(succursale, 'postalCode', '')).trim();
                    return await this.lauchGetPersonasByTransit((succursale.transitId)?succursale.transitId.toString():null, paging, rawDataService).then(async (persons) => {
                        if (!!persons && !!persons.users) {
                            const response = await Promise.all(persons.users);

                            const employeDetail = {
                                employees: response,
                                total: persons.totalRows
                            };

                            succursaleDetail.contacts = JSON.stringify(employeDetail);
                            resolve(succursaleDetail);

                        }
                        else {
                            resolve(succursaleDetail);
                        }
                    })
                        .catch((error: any) => {
                            reject(error);
                        });
                }).catch((error: any) => {
                    reject(error);
                });
            } catch (error) {
                reject(JSON.stringify(error));
            }
        });
    }

    private getTransit(transitId: string) {
        if (transitId.substr(0, 1) == "0") {
            transitId = transitId.substr(1, transitId.length - 1);
        }
        return transitId;
    }

    private lauchGetPersonasByTransit(transit: string, paging: IPaging, rawDataService: IRawDataService): Promise<{users:User[], totalRows:number}> {
        const searchPersonasService: ISearchProfilsService = new SearchPersonasService(rawDataService);
        let transitQuery: string = "";
        if (!!transit && transit.length > 1) {
            if (transit.substr(0,1) == "0") {
                transit = transit.substr(1,transit.length-1);
            }
            transitQuery="BaseOfficeLocation:" + transit + " OR BaseOfficeLocation:" + transit.replace("-","");
        }

        return new Promise<any>((resolve, reject) => {
            try {
                searchPersonasService.getProfils(transitQuery, paging).then(searchPersonas => {
                    if (searchPersonas && searchPersonas.data) {
                        const users = searchPersonas.data.map(async persona => {
                            let personaData: IPersonaData = await persona;
                            const displayNameLineNumber: number = EnumLinePersonaData.DisplayName !== undefined ? EnumLinePersonaData.DisplayName : 0;
                            const jobTitleLineNumber: number = EnumLinePersonaData.JobTitle !== undefined ? EnumLinePersonaData.JobTitle : 1;
                            const emailLineNumber: number = EnumLinePersonaData.Email !== undefined ? EnumLinePersonaData.Email : 2;

                            const user = {
                                email: personaData.lines[emailLineNumber].line,
                                userPrincipalName: personaData.lines[emailLineNumber].line,
                                displayName: personaData.lines[displayNameLineNumber].line,
                                jobTitle: personaData.lines[jobTitleLineNumber].line,
                                id: -1
                            };

                            return user;
                        });
                        const data = {users:users,totalRows : searchPersonas.totalRows };
                        resolve(data);
                    }
                    else {
                        resolve(null);
                    }
                }).catch((ex) => {

                    reject(ex);
                });
            } catch (error) {
                reject(JSON.stringify(error));
            }
        });
    }
}
