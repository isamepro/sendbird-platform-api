import { IRawDataService } from "../../interfaces/commun/IRawDataService";
import { IPaging } from "../../model/paging/IPaging";
import { ISearchQueryResults } from "../../model/queryResults/ISearchQueryResults";
import { IRefinementValue } from "../../model/refinement/IRefinement";
import { IATM } from "../../model/succursales/IATM";
import { ISuccursaleDetail } from "../../model/succursales/ISuccursaleDetail";
import { ITransit } from "../../model/succursales/ITransit";

export interface ISuccursalesServiceSetting {
  url:string;
  succursalesListName:string;
  transitHoursListName:string;
  atmHoursListName:string;
}

export interface ISuccursalesService {
  getSuccursales( searchValue:string, maxRows:number, offset:number, pageSize:number): Promise<{ data: ISearchQueryResults, filters: IRefinementValue[] }>;
  getSuccursalesByTransit(transitId: string, atmId: string):Promise<IATM|ITransit>;
  getSuccursaleDetailByTransit(transitId: string, atmId: string,succursaleFieldLabels:any,paging:IPaging,rawDataService:IRawDataService): Promise<ISuccursaleDetail>;
}
