import { ApplicationInsights, SeverityLevel } from '@microsoft/applicationinsights-web';
import { ServiceKey, ServiceScope } from '@microsoft/sp-core-library';
import { map, pick } from 'lodash';
import { PageContext } from '@microsoft/sp-page-context';
import { Guid } from '@microsoft/sp-core-library';
import { SearchResultType } from '../../model/commun/SearchResultType';
import { ITelemetryContext, ITelemetryService } from './TelemetryService.types';
import { ITenantPropertiesManagerService, TenantPropertiesManagerService } from '../sharePoint/TenantPropertiesManagerService';
import { IBncConfiguration } from '../../model/commun/IBncConfiguration';
import { ReactPlugin } from '@microsoft/applicationinsights-react-js';
import {
  Logger,
  ILogEntry,
  ConsoleListener,
  LogLevel
} from "@pnp/logging";

export class TelemetryService implements ITelemetryService {
  public instance: ApplicationInsights;
  private userEmail: string;
  private sessionId: Guid;
  protected pageContext: PageContext;
  private tenantPropertiesManagerService: ITenantPropertiesManagerService;
  private bncConfiguration: IBncConfiguration;


  public static readonly serviceKey: ServiceKey<ITelemetryService> =
      ServiceKey.create<TelemetryService>(`BNC:ITelemetryService`, TelemetryService);

  constructor(serviceScope: ServiceScope) {
    serviceScope.whenFinished(() => {
      this.pageContext = serviceScope.consume(PageContext.serviceKey);
      this.tenantPropertiesManagerService = serviceScope.consume(TenantPropertiesManagerService.serviceKey);

      this.tenantPropertiesManagerService.getBncConfiguration().then((configuration: IBncConfiguration) => {
        this.bncConfiguration = configuration;

        if ( !this.instance ) {
          this.instance = this.getApplicationInsights(this.bncConfiguration.appInsightsInstrumentationKey);
          this.userEmail = this.pageContext.user.loginName;

          // SessionId is used to track the current user session during any operation.
          this.sessionId = Guid.newGuid();
        }
      });
    });

    Logger.subscribe(new ConsoleListener());
  }

  private getApplicationInsights(instrumentationKey: string): ApplicationInsights {
    const reactPlugin = new ReactPlugin();
    const applicationInsights = new ApplicationInsights({
        config: {
            instrumentationKey: instrumentationKey,
            extensions: [reactPlugin],
            extensionConfig: {
                // [reactPlugin.identifier]: { history: globalHistory }
            }
        }
    });
    applicationInsights.loadAppInsights();
    return applicationInsights;
  }

  public log(entry: ILogEntry): void {
    if (entry.level == LogLevel.Error) {
      this.instance.trackException({ error: new Error(entry.message), severityLevel: SeverityLevel.Error });
    } else if (entry.level == LogLevel.Warning) {
      this.instance.trackException({ error: new Error(entry.message), severityLevel: SeverityLevel.Warning });
    } else if (entry.level == LogLevel.Info) {
      this.instance.trackException({ error: new Error(entry.message),  severityLevel: SeverityLevel.Information });
    } else {
      this.instance.trackException({ error: new Error(entry.message), severityLevel: SeverityLevel.Verbose });
    }
  }

  public takeSnapshot( eventName: string, context: any ): void {
    try {
      if ( this.instance && eventName !== '' ) {
        context.sessionId = this.sessionId.toString();
        context.userLogin = this.userEmail;
        this.instance.trackEvent( { name: eventName }, context );
      }
    } catch (error) {
      Logger.write(`TelemetryService:takeSnapshot  Une erreur s'est produite dans le service de telemetrie. ${error}`, LogLevel.Error);
    }

  }

  public takeClickSnapshot( eventName: string, context: ITelemetryContext ): void {
    if ( this.instance && eventName ) {
      context.sessionId = this.sessionId.toString();
      context.userLogin = this.userEmail;
      this.instance.trackEvent( { name: eventName }, context );
    }
  }

  public takeSnapshotByResultType( eventName: string, context: ITelemetryContext, searchResultType: string ): void {
    if (!eventName) { Logger.write(`TelemetrieService::takeSnapshotByResultType EventName parameter cannot be null.`, LogLevel.Error); }
    if (!context) { Logger.write(`TelemetrieService::takeSnapshotByResultType context parameter cannot be null.`, LogLevel.Error); }
    if (!searchResultType) { Logger.write(`TelemetrieService::takeSnapshotByResultType searchResultType parameter cannot be null.`, LogLevel.Error); }

    if (context.results){
      try{
        let result: any[] = [];

        switch ( searchResultType as SearchResultType ) {
          case SearchResultType.document:
            result = map( context.results.values, ( i ) => pick( i, 'title', 'path', 'description' ) );
            break;
          case SearchResultType.image:
          case SearchResultType.video:
          case SearchResultType.outils:
          case SearchResultType.contacts:
            result = map( context.results.values, ( i ) => pick( i, 'title', 'path', 'description' ) );
            break;
          default:
            result = map( context.results.values, ( i ) => pick( i, 'title', 'url', 'description' ) );
            break;

        }

        context.sessionId = this.sessionId.toString();
        context.results = result;
        this.takeSnapshot( eventName, context );
      } catch (ex) {
        Logger.write(`TelemetrieService::takeSnapshotByResultType Une exception s'est produite: ${ex}`, LogLevel.Error);
      }
    }
  }
}
