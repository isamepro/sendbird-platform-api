import {
  ILogListener,
  LogLevel
} from "@pnp/logging";

export interface ITelemetryContext {
  // [key: string]: string;
  sessionId?: string;
  keywords?: string;
  optimizedQuery?: string;
  tab?: string;
  filters?: string;
  results: any;
  selectedPage?: number;
  totalCount?: number;
  userLogin?: string;
}

export interface ITelemetryService extends ILogListener {

  takeSnapshot( eventName: string, context: any ): void;
  /**
   * Take a snapshot of the current telemetry context for a specific event by sending a request to the analytics service
   * @param eventName the event name to log
   * @param context the context properties at the time of the event
   */
  //takeSnapshot(eventName: string, context: ITelemetryContext): void;
  takeClickSnapshot(eventName: string, context: ITelemetryContext): void;
  /**
   * Take a snapshot based on type of search results
   *
   * @param {string} eventName
   * @param {ITelemetryContext} context
   * @param {string} searchResultType Search Result Type: documents, images, videos, graphs... You can use MediaType enum.
   * @memberof ITelemetryService
   */
  takeSnapshotByResultType(eventName: string, context: ITelemetryContext, searchResultType: string): void;
}

export const TelemetryEventName = {
  keywords: "keywords",
  openUrl: "openUrl",
  paging: "updatePagingResult",
  filtering: "updateFilterResult",
  newSearch: "newSearch",
  profilSocialOpenColleague: "profil_social_open_colleague",
  profilSocialUpdateProfil: "profil_social_update_profil",
  profilSocialSuggestedCompetencyUpdate: "profil_social_suggested_competency_update",
  profilSocialException: "profil_social_exception"
};
