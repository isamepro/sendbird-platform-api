import { BaseClientSideWebPart} from '@microsoft/sp-webpart-base';
import {IPropertyPaneConfiguration, PropertyPaneDropdown, PropertyPaneTextField, PropertyPaneToggle, IPropertyPaneGroup } from '@microsoft/sp-property-pane';

import * as _ from 'lodash';
import * as React from 'react';
import BncTeamsProfil from './components/BncTeamsProfil';
import * as ReactDom from 'react-dom';

export interface IBncTeamsSearchProfilWebPartProps {
  isMockData: boolean;
  showColleagueSection: boolean;
  language:string;
}

export default class BncTeamsSearchProfilWebPart extends BaseClientSideWebPart<IBncTeamsSearchProfilWebPartProps> {
  public static isMockData: boolean;
  private teamsContext: microsoftTeams.Context;
  private language: string;
  private strings: IBncTeamsProfilWebPartStrings;
  private userPrincipalName: string;
  private inTeams: boolean;

  constructor() {
    super();
  }

  protected onInit(): Promise<void> {
    // Si on est sur Teams
    if (this.context.microsoftTeams) {
      this.inTeams = true;
      this.teamsContext = this.context.sdks.microsoftTeams.context;
    } else {
      // Sinon on est sur SharePoint
      this.inTeams = false;
    }

    this.language = this.getContextLanguage();
    this.userPrincipalName = this.context.pageContext.user.loginName;

    if (!this.strings) {
      this.setStrings();
    }

    return Promise.resolve();
  }

  public render(): void {

    const element: JSX.Element = React.createElement(BncTeamsProfil, {
          microsoftTeams: this.context.microsoftTeams,
          teamsTheme: this.inTeams ? this.context.sdks.microsoftTeams.context.theme : undefined,
          userPrincipalName: this.context.pageContext.user.loginName.toLowerCase(),
          email: this.context.pageContext.user.email.toLowerCase(),
          strings: this.strings,
          language: this.language,
          spfxContext: this.context,
          showColleagueSection: this.properties.showColleagueSection,
          isMockData: this.properties.isMockData
        });
    ReactDom.render(element, this.domElement);
  }

	/*************************************************************************************
   * @description : Get strings in the current language
   *************************************************************************************/
  public setStrings(): void {
    let localizedStrings: IBncTeamsProfilWebPartStrings;

    if (this.language) {
      switch (this.language) {
        case 'en': {
          localizedStrings = require('./loc/en-us');
          break;
        }
        case 'fr': {
          localizedStrings = require('./loc/fr-fr');
          break;
        }
      }
    }
    this.strings = localizedStrings;
  }

  /**
   * Get local value, and get 2 first carateres in lowercase
   * @returns {string} fr or en
   * @private
   * @memberof BncTeamsSearchProfilWebPart
   */
  private getContextLanguage = (): string => {
    const language: string = this.inTeams
                              ? this.teamsContext.locale
                              : this.properties.language;

    return (!language || (language && _.startsWith(language, 'fr') ))
            ? 'fr'
            : language.substring(0, 2).toLowerCase();
  };


  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }


  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {

    let propertyPaneConfiguration: IPropertyPaneConfiguration =  {
      pages:
        [
          {
            header:
            {
              description: this.strings.HeaderDescription
            },
            groups:
              [
                {
                  groupName: this.strings.BasicGroupName,
                  groupFields:
                    [PropertyPaneToggle('isMockData', {
                        checked: this.properties.isMockData,
                        label: this.strings.properties.MockDataLabel,
                        key: "mockDataToggle",
                        onText: this.strings.properties.LabelYes,
                        offText: this.strings.properties.LabelOff
                      }),
                      PropertyPaneToggle('showColleagueSection', {
                        checked: this.properties.showColleagueSection,
                        label: this.strings.properties.showColleagueSectionLabel,
                        key: "showColleagueSectionToggle",
                        onText: this.strings.properties.LabelYes,
                        offText: this.strings.properties.LabelOff
                      })
                    ]
                }
              ]
          }
        ]
    };

    if ( !this.inTeams ) {
      const group:IPropertyPaneGroup = propertyPaneConfiguration.pages[0].groups[0] as IPropertyPaneGroup;
      group.groupFields.push(PropertyPaneDropdown( 'language', {
        label: this.strings.PropertyPaneResultLanguage,
        options: [
          { key: "fr-ca", text: this.strings.Languages.French },
          { key: "en-us", text: this.strings.Languages.English }
        ],
      } ));
    }

    return propertyPaneConfiguration;
  }
}
