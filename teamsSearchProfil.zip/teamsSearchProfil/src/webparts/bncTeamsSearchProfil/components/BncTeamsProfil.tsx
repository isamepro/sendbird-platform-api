import * as React from "react";
import {
  Provider,
  teamsTheme,
  teamsDarkTheme,
  teamsHighContrastTheme,
  ThemePrepared,
  SiteVariablesPrepared,
  TeamsThemeStylesProps
} from '@fluentui/react-northstar';
import TeamsBaseComponent, { ITeamsBaseComponentState } from "msteams-react-base-component";
import ProfilContainer from "./profilContainer/ProfilContainer";
import Colleagues from "./profilContainer/Colleagues";
import * as strings from "BncTeamsProfilWebPartStrings";
import {
  colorsSchemaBackgoundColor
} from "../../common/theme";
import * as _ from "lodash";
import { AppContext, IAppContextProps } from "../../common/AppContext";
import { Logger, LogLevel, ConsoleListener } from "@pnp/logging";
import * as microsoftTeams from '@microsoft/teams-js';
import { WebPartContext } from '@microsoft/sp-webpart-base';
import { Stack, initializeIcons } from "@fluentui/react";

export interface IBncTeamsProfilProps {
  microsoftTeams: typeof microsoftTeams;
  userPrincipalName: string;
  email: string;
  teamsTheme: string;
  spfxContext: WebPartContext;
	strings: IBncTeamsProfilWebPartStrings;
  showColleagueSection: boolean;
  isMockData: boolean;
  language: string;
}

export interface IBncTeamsProfilState extends ITeamsBaseComponentState {
  teamsTheme: ThemePrepared<TeamsThemeStylesProps>;
  errors: string;
}

export default class BncTeamsProfil extends TeamsBaseComponent<IBncTeamsProfilProps, IBncTeamsProfilState > {
  private userPrincipalName: string;
  private isMe: boolean;

  public constructor(props: IBncTeamsProfilProps, state: IBncTeamsProfilState) {
    super(props, state);

    this.state = {
      fontSize: undefined,
      theme: undefined,
      teamsTheme: undefined,
      errors: undefined
    };

    Logger.subscribe(new ConsoleListener());
   }

  private getAppContextProps = () : IAppContextProps =>{
    return {
      siteVariables: this.getSiteVariables(),
      strings: this.props.strings,
      isMe: this.isMe,
      inTeams: (this.props.teamsTheme !== undefined),
      email: this.props.email,
      userPrincipalName: this.userPrincipalName,
      serviceScope: this.props.spfxContext.serviceScope,
      language: this.props.language
    };
  }

  public render(): JSX.Element {

    initializeIcons();
    const profilContext = this.getAppContextProps();
    const backgroundColor = profilContext.inTeams ? colorsSchemaBackgoundColor(this.getSiteVariables()) : 'transparent';

    return (
      <Provider theme={ profilContext.inTeams ? this.state.teamsTheme : teamsTheme}>
        <AppContext.Provider value={profilContext}>
          <Stack horizontal styles={{ root: { background: backgroundColor }}} verticalFill={true} >
            <Stack.Item grow={3}>
              <ProfilContainer isMockData={this.props.isMockData} />
            </Stack.Item>
            { this.props.showColleagueSection
              && <Stack.Item>
                <Colleagues />
              </Stack.Item>}
          </Stack>
        </AppContext.Provider>
      </Provider>);
  }

  private getSiteVariables = (): SiteVariablesPrepared => {
    if (!this.props.teamsTheme) return undefined;

    return !this.state.teamsTheme
      ? teamsTheme.siteVariables
      : this.state.teamsTheme.siteVariables;
  }

  public componentWillMount() {

    // get email in query parameter
    const paramEmail = this.getQueryVariable('email');

    this.userPrincipalName= (!!paramEmail)? paramEmail.toLocaleLowerCase().trim(): this.props.userPrincipalName;
    this.isMe= !paramEmail || (this.props.userPrincipalName === paramEmail);

    this.processWillMountForTeams();
  }

  private updateStardustTheme = (theme: string = "default"): void => {

    let stardustTheme: ThemePrepared<TeamsThemeStylesProps>;

    switch (theme) {
      case "default":
        stardustTheme = teamsTheme;
        break;
      case "dark":
        stardustTheme = teamsDarkTheme;
        break;
      case "contrast":
        stardustTheme = teamsHighContrastTheme;
        break;
      default:
        stardustTheme = teamsTheme;
        break;
    }
    // update the state
    this.setState({ teamsTheme: stardustTheme });
  };

  /**
   * Update theme when we are in Teams.
   *
   * @private
   * @memberof BncTeamsProfil
   */
  private processWillMountForTeams = (): void => {
    // process theme changing only in teams.
    if (this.props.teamsTheme){
      const queryTheme = this.getQueryVariable("theme");
      try {
          const theme = (queryTheme === undefined)
            ? this.props.teamsTheme
            : queryTheme;

          this.updateStardustTheme(theme);
          this.props.spfxContext.sdks.microsoftTeams.teamsJs.registerOnThemeChangeHandler((themeUpdated: string) => {
            this.updateStardustTheme(themeUpdated);
          });
      } catch (error) {
        Logger.write(`BncTeamsProfil::processWillMountForTeams An error occur when changing theme. We will use default theme. ${error}`, LogLevel.Error);
        this.updateStardustTheme("default");
      }
    }
  };
}
