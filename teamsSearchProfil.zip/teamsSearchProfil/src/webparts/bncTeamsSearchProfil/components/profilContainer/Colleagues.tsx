import * as React from "react";
import * as _ from "lodash";
import {
  IProfilDataItem,
  PeopleNetwork,
  PeopleNetworkType,
  IProfilSocialService,
  ProfilSocialService, IProfilData, ITelemetryService, TelemetryService, TelemetryEventName
} from "bnc-library";
import { Logger, ConsoleListener, LogLevel } from "@pnp/logging";
import { Stack, Persona, PersonaSize, PersonaPresence } from "@fluentui/react";
import { AppContext, IAppContextProps } from "../../../common/AppContext";
import { WithAppContext } from "../../../common/WithAppContext";
import { colorsSchemaForeground, colorsSchemaForeground2, colorsSchemaBrandForegroundColor, colorsSchemaBrandBackgoundHover, colorsSchemaBackgoundColorLight } from "../../../common/theme";

export interface IColleaguesProps extends IAppContextProps {
}

export interface IColleaguesState {
  users: IProfilData[];
}

class Colleagues extends React.Component<IColleaguesProps, IColleaguesState> {

  private profilSocialService: IProfilSocialService;
  private telemetryService: ITelemetryService;

  constructor(props: IColleaguesProps, state: IColleaguesState) {
    super(props, state);

    Logger.activeLogLevel = LogLevel.Info;
    Logger.subscribe(new ConsoleListener());
    Logger.subscribe(new TelemetryService(this.props.serviceScope));

    this.props.serviceScope.whenFinished(() => {
      this.profilSocialService = this.props.serviceScope.consume(ProfilSocialService.serviceKey);
      this.telemetryService = this.props.serviceScope.consume(TelemetryService.serviceKey);
    });
  }

  public componentDidMount() {
    this.loadSimilarProfilsData();
  }

  private loadSimilarProfilsData = async (): Promise<void> => {

    this.profilSocialService.getPeopleAround(this.props.userPrincipalName, 0, 10).then((data: IProfilData[]) => {
      this.setState({ users: data });
    }).catch((error) => {
      Logger.write(`Une erreur s'est produite dans la recherche des collegues. Error: ${error}`);
    });
  }

  public render(): JSX.Element {
    if (!this.state) return <></>;

    const getPersonaComponent = (colleague: IProfilData, index: number) => {
      const primaryFontColor = colorsSchemaForeground(this.props.siteVariables);
      const secondaryFontColor = colorsSchemaForeground2(this.props.siteVariables);

      const onRenderPrimaryText = () => {
        return (
          this.props.inTeams
          ? (<Stack><span style={{ color: primaryFontColor }}>{colleague.persona.displayName}</span></Stack>)
          : (<Stack>{colleague.persona.displayName}</Stack>));
      };
      const onRenderSecondaryText = () => {
        return (
          this.props.inTeams
            ? (<span style={{ color: secondaryFontColor }}>{colleague.persona.jobTitle}</span>)
            : <>{colleague.persona.jobTitle}</>);
      };

      return (
        <Persona
          onClick={ () => { this.setProfilUrl(colleague.persona.userPrincipalName); }}
          size={PersonaSize.size48}
          imageAlt={`${colleague.persona.displayName}, ${colleague.persona.jobTitle}`}
          key={`colleague-${index}`}
          imageUrl={ colleague.pictureUrl }
          presence={ PersonaPresence.none }
          onRenderPrimaryText={onRenderPrimaryText}
          onRenderSecondaryText={onRenderSecondaryText}
          styles={{
            root: {
              cursor: 'pointer'
            }
          }}
        />
      );
    };
    return (
          <Stack verticalFill={true} tokens={{ childrenGap: 10 }}>
            {this.state.users && <PeopleNetwork
              colleaguesType={ PeopleNetworkType.Colleagues }
              colleagueMenuLabel={this.props.strings.Network.Colleagues}
              similarProfilesMenuLabel={this.props.strings.Network.SimilarProfiles}
              menuSelectorColor={colorsSchemaBrandForegroundColor(this.props.siteVariables)}
              menuColor={colorsSchemaForeground(this.props.siteVariables)}
              menuHoverColor={colorsSchemaBrandBackgoundHover(this.props.siteVariables)}
              backgroundColor={colorsSchemaBackgoundColorLight(this.props.siteVariables)}>
              { this.state.users &&
                  this.state.users
                  .map((colleague: IProfilData, index: number ) => {
                    return getPersonaComponent(colleague, index);
                })
              }
              {
                !this.state.users || this.state.users.length === 0 &&
                <div>{this.props.strings.Network.NoColleaguesMessage}</div>
              }
            </PeopleNetwork>}
          </Stack>);

  }

  private setProfilUrl = (upn: string) => {

    const parameter: string = "email";
    if ( upn ) {
      this.addToTelemetry(upn);
      // newurl = origin + pathname + search
      const { origin, pathname, search } = window.location;
      let searchParams = new URLSearchParams( search ? search : '' );
      if ( searchParams.has( parameter ) ) {
        searchParams.set( parameter, upn );
      } else {
        searchParams.append( parameter, upn );
      }
      window.location.assign( origin + pathname + '?' + searchParams.toString() );
    }
  }

  private addToTelemetry = (upn: string): void =>  {
    this.telemetryService.takeSnapshot(TelemetryEventName.profilSocialOpenColleague, {colleague : upn});
  }
}
export default WithAppContext(Colleagues);
