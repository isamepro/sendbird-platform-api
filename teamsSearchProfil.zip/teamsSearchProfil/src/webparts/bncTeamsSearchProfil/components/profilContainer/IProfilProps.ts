import { ITag } from "@fluentui/react";
import { IProfilDataItem } from "bnc-library";
import { DataOperationQueryType } from "bnc-library/lib/libraries/services/profilSocial/ProfilSocialService.types";
import { IAppContextProps } from "../../../common/AppContext";

export interface IProfilProps extends IAppContextProps {
  /**
   * A callback for when the selected list of items changes.
   *
   * @memberof IProfilProps
   */
  onChange?: (items: ITag[]) => void;
  /**
   * A callback for when an item is searched.
   *
   * @memberof IProfilProps
   */
  onSearch?: (text: string, dataOperationQueryType: DataOperationQueryType) => Promise<ITag[]>;
  /**
   * A callback for when an item is added.
   *
   * @memberof IProfilProps
   */
  onAddItem?: (item: ITag) => void;
  /**
   * A callback for when an item is removed.
   *
   * @memberof IProfilProps
   */
  onRemoveItem?: (item: ITag) => void;

  items: IProfilDataItem[];
  /**
   * Section title
   *
   * @type {string}
   * @memberof IProfilProps
   */
  title: string;
  noInformationFoundLabel?: string;
  placeholder?: string;
  suggestionPrefixLabel?: string;
  dataOperationQueryType: DataOperationQueryType;
  isLoading: boolean;
}
