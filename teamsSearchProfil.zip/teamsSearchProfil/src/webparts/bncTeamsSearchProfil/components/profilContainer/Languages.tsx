import * as React from "react";
import * as _ from "lodash";
import {
  IProfilDataItem
} from "bnc-library";
import { Logger, ConsoleListener } from "@pnp/logging";
import { IProfilProps } from "./IProfilProps";
import { Stack, ITag } from "@fluentui/react";
import { Spacing10StackTokens } from "./ProfilContainer.styles";
import { BncTagPicker } from "../../../controls/bncTagPicker/BncTagPicker";
import { colorSchemaBackgroundPressed, colorsSchemaForeground, colorsSchemaForeground2, colorsSchemaBackgoundColor } from "../../../common/theme";
import { WithAppContext } from "../../../common/WithAppContext";
import { BncMultiRating } from "../../../controls/bncRating/BncMultiRating";

class Languages extends React.Component<IProfilProps, {}> {

  constructor(props: IProfilProps) {
    super(props);

    Logger.subscribe(new ConsoleListener());
  }

  public render(): JSX.Element {
    const backgroundColor = colorSchemaBackgroundPressed(this.props.siteVariables);
    const secondaryBackgroundColor = colorsSchemaBackgoundColor(this.props.siteVariables);
    const fontColor = colorsSchemaForeground(this.props.siteVariables);
    const secondaryFontColor = colorsSchemaForeground2(this.props.siteVariables);
    
    const labels = this.getLabels();

    return (
      <Stack>
        <h3>{this.props.title}</h3>
        <Stack
          horizontal
          wrap
          tokens={Spacing10StackTokens}
          styles={{
            inner: {
              flexBasis: '100%'
            }
          }}
        >
          {this.props.editMode &&
            <BncTagPicker
              onSearch={this.onSearch}
              items={this.props.items}
              onChange={this.onChange}
              onAddItem={this.props.onAddItem}
              onRemoveItem={this.props.onRemoveItem}
              inTeams={this.props.inTeams}
              placeholder={this.props.placeholder}
              suggestionPrefixLabel={this.props.suggestionPrefixLabel}
            />
          }
          {!this.props.editMode &&
            this.props.items &&
            this.props.items.map((item: IProfilDataItem) => {
              return (
                <Stack.Item>
                <BncMultiRating
                  title={item.name}
                  values={item.fields}
                  tooltip={item.name}
                  readonly={!this.props.editMode}
                  onDelete={null}
                  inTeams={this.props.inTeams}
                  backgroundColor={backgroundColor}
                  secondaryBackgroundColor={secondaryBackgroundColor}
                  fontColor={fontColor}
                  secondaryFontColor={secondaryFontColor}
                  labels={labels}
                  labelForOther={this.props.strings.LanguagesAbility.other}
                  numberOfStars={3}
                  ratingSymbol='&#9733;'
                  emptyRatingSymbol='&#9734;'
                  height='14px'
                >
                </BncMultiRating>
                </Stack.Item>
              );
            })
          }
          {
            !this.props.editMode &&
            !this.props.items &&
            !this.props.isLoading &&
            <>
              {this.props.noInformationFoundLabel}
            </>
          }
        </Stack>
      </Stack>);
  }

  private onSearch = async (filterText: string): Promise<ITag[]> => {
    return await this.props.onSearch(filterText, this.props.dataOperationQueryType);
  }

  private onChange = (items: ITag[]): void => {
    this.props.onChange(items);
  }

  private getLabels = (): { [key: string]: string } => {

    return {
      'oral_expression': this.props.strings.LanguagesAbility.oral_expression,
      'written_expression': this.props.strings.LanguagesAbility.written_expression,
      'written_comprehension': this.props.strings.LanguagesAbility.written_comprehension,
      'oral_comprehension': this.props.strings.LanguagesAbility.written_comprehension

    };
  }
}


export default WithAppContext(Languages);
