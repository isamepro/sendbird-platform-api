import { createTheme, IStackTokens, ITheme, mergeStyleSets, ShimmerElementType, Shimmer } from "@fluentui/react";
import { colorsSchemaBackgoundColor } from "../../../common/theme";

export const Spacing10StackTokens: IStackTokens = {
  childrenGap: 10,
  padding: 0,
};
