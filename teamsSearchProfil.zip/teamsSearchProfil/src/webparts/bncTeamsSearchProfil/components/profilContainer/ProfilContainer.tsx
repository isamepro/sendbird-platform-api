import * as React from "react";
import {
  IProfilData,
  IProfilDataItem,
  IExtendedProfil,
  IProfilSocialService,
  ProfilSocialService,
  DataOperationQueryType,
  CompetencyStatus, ManageCompetencyStatus, TaxonomyService, ITaxonomyService, ITenantPropertiesManagerService, TenantPropertiesManagerService, ITelemetryService, TelemetryService, TelemetryEventName, DataSource
} from "bnc-library";
import * as _ from "lodash";
import { Logger, LogLevel, ConsoleListener } from "@pnp/logging";
import Languages from './Languages';
import SuggestedCompetencies from './SuggestedCompetencies';
import ProfilSection from './ProfilSection';
import { ITag, Stack } from "@fluentui/react";
import { AppContext, IAppContextProps } from "../../../common/AppContext";
import ProfilHeader from './ProfilHeader';
import ProfilHeaderButtons from './ProfilHeaderButtons';
import { ProfilLoader } from './ProfilLoader';
import { WithAppContext } from "../../../common/WithAppContext";
import { IProfilConfiguration } from "../../../models/IProfilConfiguration";
import { ServiceConstants } from "../../../models/Constants";
import { BncAlert } from "../../../controls/bncAlert/BncAlert";

export interface IProfilContainerState {
  profil: IProfilData;
  disabledEditButton: boolean;
  editMode: boolean;
  error?: string;
  isLoadingCompetency: boolean;
}

export interface IProfilContainerProps extends IAppContextProps, IExtendedProfil {
  isMockData: boolean;
}

class ProfilContainer extends React.Component<IProfilContainerProps, IProfilContainerState> {

  private competenciesUpdated: IProfilDataItem[] = [];
  private softwaresUpdated: IProfilDataItem[] = [];
  // private profilManagerService: IProfilManagerService;
  private profilSocialService: IProfilSocialService;
  private taxonomyService: ITaxonomyService;
  private tenantPropertiesManagerService: ITenantPropertiesManagerService;
  private telemetryService: ITelemetryService;
  private profilConfiguration: IProfilConfiguration;

  private constructor(props: IProfilContainerProps, state: IProfilContainerState) {
    super(props, state);

    this.props.serviceScope.whenFinished(() => {
      this.profilSocialService = this.props.serviceScope.consume(ProfilSocialService.serviceKey);
      this.taxonomyService = this.props.serviceScope.consume(TaxonomyService.serviceKey);
      this.telemetryService = this.props.serviceScope.consume(TelemetryService.serviceKey);
      this.tenantPropertiesManagerService = this.props.serviceScope.consume(TenantPropertiesManagerService.serviceKey);
    });
    Logger.subscribe(new ConsoleListener());

    this.state = {
      profil: undefined,
      editMode: false,
      disabledEditButton: false,
      isLoadingCompetency: false
    };
  }

  public componentDidMount() {
    this.loadFullCurrentUserProfil();
    this.loadProfilConfiguration();
  }

  public render(): JSX.Element {

    const alert = this.getAlert();
    try {
      return (<>

        {!this.state.profil && !this.state.error && <ProfilLoader />}
        { alert}
        {this.state.profil &&
          <Stack>
            <Stack verticalFill={true} horizontal horizontalAlign="space-between" >
              <ProfilHeader profil={this.state.profil} />
              <ProfilHeaderButtons
                editMode={this.state.editMode}
                disabled={this.state.disabledEditButton}
                onSaveClick={this.onSave}
                onCancelClick={this.onCancelClick}
                onEditClick={this.onEditClick}
                telephone={this.state.profil.phonesFormated}></ProfilHeaderButtons>
            </Stack>
            <Stack>
              <h2 style={{ margin: '60px 0 0' }}>{this.props.strings.profilLabel.CompetenciesSeactionHeader}</h2>
            </Stack>
            <Stack>
              <ProfilSection
                title={this.props.strings.profilLabel.CompetencesHeader}
                onSearch={this.onTaxonomySearch}
                items={this.state.profil.validatedCompetencies}
                editMode={this.state.editMode}
                dataOperationQueryType={DataOperationQueryType.competency}
                onAddItem={this.onCompetencyAdded}
                onRemoveItem={this.onCompetencyRemoved}
                noInformationFoundLabel={this.props.strings.profilLabel.NoInformationFoundLabel}
                isLoading={this.state.isLoadingCompetency}
                suggestionPrefixLabel={this.props.strings.DropdownValuePrefixCategoryLabel}
                placeholder={this.props.strings.AddLabel} />

              {!this.state.editMode && <SuggestedCompetencies
                items={this.state.profil.suggestedCompetencies}
                title={this.props.strings.profilLabel.SuggestionsHeader}
                onAfterSuggestedCompetencyUpdated={this.onAfterSuggestedCompetencyUpdated}
                isLoading={false}
                editMode={false}
                buttonApproveTitle={this.props.strings.Actions.AddToMyProfil}
                buttonRejectTitle={this.props.strings.Actions.RemoveSuggestionsToMyProfil} />}

              {this.state.profil.softwares &&
                <ProfilSection
                  items={this.state.profil.softwares}
                  dataOperationQueryType={DataOperationQueryType.software}
                  title={this.props.strings.profilLabel.ApplicationsHeader}
                  onSearch={this.onTaxonomySearch}
                  editMode={this.state.editMode}
                  noInformationFoundLabel={this.props.strings.profilLabel.NoInformationFoundLabel}
                  isLoading={false}
                  suggestionPrefixLabel={this.props.strings.DropdownValuePrefixCategoryLabel}
                  placeholder={this.props.strings.AddLabel}
                  onAddItem={this.onSoftwareAdded}
                  onRemoveItem={this.onSoftwareRemoved} />
              }
              {this.state.profil.languages &&
                <Languages
                  items={this.state.profil.languages}
                  dataOperationQueryType={DataOperationQueryType.language}
                  title={this.props.strings.profilLabel.LanguesBNCHeader}
                  onSearch={this.onTaxonomySearch}
                  editMode={false} // temporaire, language est juste en read
                  noInformationFoundLabel={this.props.strings.profilLabel.NoInformationFoundLabel}
                  isLoading={false}
                  suggestionPrefixLabel={this.props.strings.DropdownValuePrefixCategoryLabel}
                  placeholder={this.props.strings.AddLabel}
                />
              }
              {this.state.profil.certifications &&
                <ProfilSection
                  items={this.state.profil.certifications}
                  dataOperationQueryType={DataOperationQueryType.certification}
                  title={this.props.strings.profilLabel.CertificationsHeader}
                  onSearch={this.onTaxonomySearch}
                  editMode={false}
                  noInformationFoundLabel={this.props.strings.profilLabel.NoInformationFoundLabel}
                  isLoading={false}
                  suggestionPrefixLabel={this.props.strings.DropdownValuePrefixCategoryLabel}
                  placeholder={this.props.strings.AddLabel} />
              }
            </Stack>
            {this.getMapComponent()}
          </Stack>}
      </>);
    } catch (error) {
      if (alert) {
        return (<>{ alert}</>);
      }
      else {
        return (<div>{ error}</div>);
       }
    }
  }

  private getAlert = (): JSX.Element => {
    if (this.state.error) {
      return <BncAlert
        text={this.getErrorMessage(this.state.error)}
        inTeams={this.props.inTeams}
        onClick={() => {
          this.setState({ error: undefined });
        }} />;
    }
  }

  /**
   * Return error message based on a key. If the key doesn't exist return the key.
   *
   * @private
   * @memberof ProfilContainer
   */
  private getErrorMessage = (key: string): string => {
    const message = this.props.strings.errors[key];

    // enregistrement des informations dans la telemetrie
    this.telemetryService.takeSnapshot(TelemetryEventName.profilSocialException,
      {
        code: key,
        message: message
      });

    return (message) ? message : key;
  }

  private onCancelClick = (): void => {
    this.setState({ editMode: false, error: undefined });
    this.loadFullCurrentUserProfil();
  };

  private onEditClick = (): void => {
    this.setState({ editMode: true, error: undefined });
  };

  private onCompetencyAdded = (item: ITag) => {

    let profil: IProfilData = this.state.profil;
    const itemToAdd: IProfilDataItem = {
      key: item.key,
      name: item.name,
      status: ManageCompetencyStatus.add
    };
    profil.validatedCompetencies.push(itemToAdd);
    this.competenciesUpdated.push(itemToAdd);
    this.setState({ profil: profil });
  }

  private onCompetencyRemoved = (item: ITag) => {

    let profil: IProfilData = this.state.profil;
    const itemToRemove: IProfilDataItem = {
      key: item.key,
      name: item.name,
      status: ManageCompetencyStatus.delete
    };
    _.remove(profil.validatedCompetencies, (val) => {
      return val.name.toLocaleLowerCase() == item.name.toLocaleLowerCase();
    });

    this.competenciesUpdated.push(itemToRemove);
    this.setState({ profil: profil });
  }

  private onSoftwareAdded = (item: ITag) => {

    let profil: IProfilData = this.state.profil;
    const itemToAdd: IProfilDataItem = {
      key: item.key,
      name: item.name,
      status: ManageCompetencyStatus.add
    };
    profil.softwares.push(itemToAdd);
    this.softwaresUpdated.push(itemToAdd);
    this.setState({ profil: profil });
  }

  private onSoftwareRemoved = (item: ITag) => {

    let profil: IProfilData = this.state.profil;
    const itemToRemove: IProfilDataItem = {
      key: item.key,
      name: item.name,
      status: ManageCompetencyStatus.delete
    };
    _.remove(profil.softwares, (val) => {
      return val.name.toLocaleLowerCase() == item.name.toLocaleLowerCase();
    });

    this.softwaresUpdated.push(itemToRemove);
    this.setState({ profil: profil });
  }

  private loadProfilConfiguration = (): void => {
    try {
      this.tenantPropertiesManagerService.getProperty<IProfilConfiguration>(ServiceConstants.PROPERTIES.BNC_PROFIL).then((configuration: IProfilConfiguration) => {
        if (!configuration) {
          Logger.write("Impossible de trouver la configuration du profil dans les stores. SVP vérifier les tenant properties.", LogLevel.Error);
          this.setState({
            error: this.props.strings.errors.LoadProfilConfigurationException
          });
        }
        this.profilConfiguration = configuration;
      });
    } catch (error) {
      Logger.write("Une exception s'est produite lors de la récupération de la configuration du profil dans les stores. SVP vérifier les tenant properties.", LogLevel.Error);
      this.setState({
        error: this.props.strings.errors.LoadProfilConfigurationException
      });

    }
  }

  /**
   * Return the current user profil asynchronously.
   *
   * @private
   * @memberof ProfilContainer
   */
  private loadFullCurrentUserProfil = async (fromSave: boolean = false): Promise<void> => {

    try {
      if (!this.props.isMockData) {
        const profilData = await this.profilSocialService.getUserInformation(this.props.userPrincipalName);
        let tmp: IProfilData = profilData;
        if (this.state.profil) {
          tmp.validatedCompetencies = this.state.profil.validatedCompetencies;
          tmp.suggestedCompetencies = this.state.profil.suggestedCompetencies;
        }

        this.setState({
          profil: tmp,
          isLoadingCompetency: true
        });

        const competencies = await this.profilSocialService.getData(this.props.userPrincipalName, DataOperationQueryType.competency, this.props.language);
        tmp = this.state.profil;
        tmp.validatedCompetencies = competencies.filter((value: IProfilDataItem) => { return value.fields['competencyStatus'] === CompetencyStatus.valid; });
        tmp.suggestedCompetencies = competencies.filter((value: IProfilDataItem) => { return value.fields['competencyStatus'] === CompetencyStatus.suggested; });

        const languagescompetencies = await this.profilSocialService.getData(this.props.userPrincipalName, DataOperationQueryType.language, this.props.language);
        tmp.languages = languagescompetencies;

        const tools = await this.profilSocialService.getData(this.props.userPrincipalName, DataOperationQueryType.software, this.props.language, DataSource.microService);
        tmp.softwares = tools;

        this.setState({
          profil: tmp,
          isLoadingCompetency: false
        });
      }
      else {
        const profilData: IProfilData = await this.profilSocialService.getUserInformation(this.props.userPrincipalName, DataSource.mock);
        this.setState({
          profil: profilData,
          isLoadingCompetency: true
        });
      }
    } catch (exception) {
      this.setState({
        error: exception
      });
    }
  }
  /**
   * Validate the difference between what we sent and what we got from Stardog. If it's different, raise an error.
   *
   * @private
   * @memberof ProfilContainer
   */
  private validateSave = async (profilBefore: IProfilData): Promise<void> => {

    if ((profilBefore.validatedCompetencies.length !== this.state.profil.validatedCompetencies.length)) {

      this.telemetryService.takeSnapshot(TelemetryEventName.profilSocialUpdateProfil,
        {
          message: "Error Update",
          dataToUpdate: profilBefore,
          dataAfterUpdate: this.state.profil
        });
      this.setState({
        error: this.props.strings.errors.SaveProfilException
      });
    } else {
      this.telemetryService.takeSnapshot(TelemetryEventName.profilSocialUpdateProfil,
        {
          message: "Update Success",
          dataToUpdate: profilBefore,
          dataAfterUpdate: this.state.profil
        });
    }

    // Reinitialisation des valeurs
    this.competenciesUpdated = [];
    this.softwaresUpdated = [];
  }

  /**
   * Perform Save operation. Take profil data saved in '...updated' variables.
   *
   * @private
   * @memberof ProfilContainer
   */
  private onSave = async (): Promise<void> => {

    try {

      let profilToSave: IProfilData = {
        validatedCompetencies: this.competenciesUpdated,
        softwares: this.softwaresUpdated
      };
      const profilBeforeSaving: IProfilData = this.state.profil;

      this.setState({ editMode: false, disabledEditButton: true, isLoadingCompetency: true });
      await this.profilSocialService.updateProfil(this.props.userPrincipalName, profilToSave);

      // Rechargement du profile
      await this.loadFullCurrentUserProfil(true);

      await this.validateSave(profilBeforeSaving);
      this.setState({ disabledEditButton: false });

    } catch (error) {
      Logger.write(`ProfilContainer::onSave Une erreur s'est produite dans l'enregistrement du profil : ${error}`, LogLevel.Error);
      this.setState({ error: this.props.strings.errors.SaveProfilException });
    }
  }

  /**
   * Reload section Validated and Suggested competencies after suggested task operation.
   *
   * @private
   * @memberof ProfilContainer
   */
  private onAfterSuggestedCompetencyUpdated = async (): Promise<void> => {

    try {

      // reload du profil si la mise à jour est ok
      const competencies = await this.profilSocialService.getData(this.props.userPrincipalName, DataOperationQueryType.competency, this.props.language);

      let tmp: IProfilData = this.state.profil;
      tmp.validatedCompetencies = competencies.filter((value: IProfilDataItem) => { return value.fields['competencyStatus'] === CompetencyStatus.valid; });
      tmp.suggestedCompetencies = competencies.filter((value: IProfilDataItem) => { return value.fields['competencyStatus'] === CompetencyStatus.suggested; });
      this.setState({ profil: tmp });

    } catch (error) {
      Logger.write(`Une erreur s'est produite lors de la mise è jour des suggestions de competences: ${error}`, LogLevel.Error);
      this.setState({ error: error });
    }
  }

  private onTaxonomySearch = async (filterText: string, dataOperationQueryType: DataOperationQueryType): Promise<ITag[]> => {

    let termsetId: string;
    let suggestionItems: ITag[] = [];

    switch (dataOperationQueryType) {
      case DataOperationQueryType.competency:
        termsetId = this.profilConfiguration.termsetCompetencies;
        break;
      case DataOperationQueryType.language:
        termsetId = this.profilConfiguration.termsetLanguages;
        break;
      case DataOperationQueryType.certification:
        termsetId = this.profilConfiguration.termsetCertifications;
        break;
      case DataOperationQueryType.software:
        termsetId = this.profilConfiguration.termsetSoftwares;
        break;
      default:
        termsetId = undefined;
        break;
    }

    if (!termsetId || termsetId === '') {
      Logger.write("Le termsetId est undefined ou vide. Aucune recherche de terme ne peut s'effectuer. SVP verifier les tenant properties.", LogLevel.Error);
      this.setState({
        error: this.props.strings.errors.TermSetException
      });
    } else {
      suggestionItems = await this.taxonomyService.searchTermsByName(filterText, this.props.language, termsetId);
    }

    return suggestionItems;
  }

  private getMapComponent = (): JSX.Element => {

    return (
      <Stack>
        <h3>{this.props.strings.profilLabel.LocalisationsHeader}</h3>
        <iframe
          frameBorder="0"
          id="gmap_canvas"
          src={this.state.profil.userLocationMapUrl}
          style={{
            width: '100%',
            height: window.innerHeight / 2
          }}
          scrolling="no" />
      </Stack>
    );
  }

}

export default WithAppContext(ProfilContainer);
