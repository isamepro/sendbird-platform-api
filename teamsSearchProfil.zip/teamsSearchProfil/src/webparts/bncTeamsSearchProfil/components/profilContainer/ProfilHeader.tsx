import * as React from "react";
import * as _ from "lodash";
import { PersonaSize, Persona, IPersonaSharedProps, Stack } from "@fluentui/react";
import { IPhone, IProfilData } from "bnc-library";
import { AppContext, IAppContextProps } from "../../../common/AppContext";
import {
  colorsSchemaForeground,
  colorsSchemaForeground1
} from "../../../common/theme";
import { WithAppContext } from "../../../common/WithAppContext";

export interface IProfilHeaderProps extends IAppContextProps {
  profil: IProfilData;
}

class ProfilHeader extends React.Component<IProfilHeaderProps, {} > {

  public render(): JSX.Element {

    const primaryFontColor = colorsSchemaForeground(this.props.siteVariables);
    const secondaryFontColor = colorsSchemaForeground1(this.props.siteVariables);

    return ( <Stack>
        <Persona
          imageUrl={this.props.profil.pictureUrl}
          size={PersonaSize.size100}
          presence={this.props.profil.personaPresence}
          hidePersonaDetails={false}
          imageAlt={`${this.props.profil.persona.displayName}, ${this.props.profil.persona.jobTitle}`}
          onRenderSecondaryText={ () => {
            return (
              this.props.inTeams
                ? (<span style={{ color: secondaryFontColor }}>{this.props.profil.persona.jobTitle}</span>)
                : <>{this.props.profil.persona.jobTitle}</>);
          }}
          onRenderTertiaryText={ () => {

            let cityStateCountryZipCode = `${this.getValue(this.props.profil.persona.city)}${this.getValue(this.props.profil.persona.state)}${this.getValue(this.props.profil.persona.usageLocation)}${this.getValue(this.props.profil.persona.postalCode)}`;

            const details: JSX.Element= <>
              <Stack>{this.props.profil.persona.officeLocation}</Stack>
              <Stack>{this.props.profil.persona.streetAddress}</Stack>
              <Stack>{cityStateCountryZipCode}</Stack>
              <Stack>{ this.getEmailAndPhoneFormated() }</Stack>
            </>;
            return (
              this.props.inTeams
                ? (<span style={{ color: secondaryFontColor }}>{details}</span>)
                : <>{details}</>);
          }}
          onRenderPrimaryText={ () => {
            return (
              this.props.inTeams
              ? (<Stack><h2 style={{ color: primaryFontColor, fontWeight: 600, margin: 0, marginTop: 40}}>{this.props.profil.persona.displayName}</h2></Stack>)
              : (<Stack><h2 style={{ margin: 0, marginTop: 40 }}>{this.props.profil.persona.displayName}</h2></Stack>));

          }}
        />
        </Stack>);
  }

  private getValue(field: any): any {
    if (!field) return '';

    return `${field} `;
  }

  /**
   * Return a string with phones and email on the same lines.
   *
   * @protected
   * @param {IPhone[]} phones
   * @param {string} email
   * @returns {string}
   * @memberof ProfilService
   */
  protected getEmailAndPhoneFormated(): string {
    const phones: IPhone[] = this.props.profil.phonesFormated;
    const email: string = (this.props.profil.persona.mail) ? this.props.profil.persona.mail: this.props.profil.persona.userPrincipalName;
    const extensionFieldName: string = 'ext';
    let phoneLine: string[];

    if (phones !== undefined && phones !== null) {
      phoneLine = phones.map((phone: IPhone) => {
        const extensionValue = !_.get(phone, extensionFieldName ) || _.get(phone, extensionFieldName) === ''
              ? ''
              : `${this.props.strings.profilLabel.Poste}: ${_.get(phone, extensionFieldName, '')}`;

        return ` ${phone.phone} ${extensionValue}`;
      });
    }

    return (!phones || phoneLine.toString().trim() === '')
      ? `${email}`
      : `${email} | ${phoneLine.toString()}`;
  }
}


export default WithAppContext(ProfilHeader);

