import * as React from "react";
import * as _ from "lodash";
import { Stack } from "@fluentui/react";
import { IPhone} from "bnc-library";
import { IAppContextProps } from "../../../common/AppContext";
import { ChatIcon, EmailIcon, CloseIcon, EditIcon, AcceptIcon, CallIcon } from '@fluentui/react-northstar';
import { WithAppContext } from "../../../common/WithAppContext";
import { Utils } from "../../../common/Utils";
import { BncButton } from "../../../controls/bncButton/BncButton";

export interface IProfilHeaderButtonsProps extends IAppContextProps {
  telephone: IPhone[];
  disabled: boolean;
  onCancelClick(): void;
  onEditClick(): void;
  onSaveClick(): void;
}

class ProfilHeaderButtons extends React.Component<IProfilHeaderButtonsProps, {} > {

  public render(): JSX.Element {
    return ( <Stack>{ this.getProfilActionButtons() }</Stack>);
  }

  private getProfilActionButtons = () : JSX.Element => {
    if (this.props.isMe){
      return <Stack horizontal gap={10}>
        { this.props.editMode &&
            <BncButton
              primary={false}
              text={ this.props.disabled ? this.props.strings.Saving : this.props.strings.Buttons.CancelButtonLabel }
              inTeams={ this.props.inTeams}
              onClick={ this.props.onCancelClick }
              iconSharePoint= { 'Cancel' }
              iconTeams= { <CloseIcon /> }
              disabled={this.props.disabled} />
        }
        { !this.props.editMode &&
            <BncButton
              primary={true}
              text={ this.props.disabled ? this.props.strings.Saving : this.props.strings.Buttons.EditButtonLabel }
              inTeams={ this.props.inTeams}
              onClick={ this.props.onEditClick }
              iconSharePoint= { 'Edit' }
              iconTeams= { <EditIcon /> }
              disabled={this.props.disabled} />
        }
        { this.props.editMode &&
            <BncButton
              primary={true}
              text={ this.props.strings.Buttons.SaveButtonLabel }
              inTeams={ this.props.inTeams}
              onClick={ this.props.onSaveClick }
              iconSharePoint= { 'CheckMark' }
              iconTeams= { <AcceptIcon /> }
              disabled={this.props.disabled} />
        }
      </Stack>;
    }

    return <Stack horizontal gap={10}>
            <BncButton inTeams={ this.props.inTeams} circular={true} iconSharePoint={ 'Chat' } iconTeams={<ChatIcon /> } primary={true} text={ this.props.strings.profilLabel.Message } onClick={ this.onChatClicked} />
            <BncButton inTeams={ this.props.inTeams} circular={true} iconSharePoint={ 'Mail' } iconTeams={<EmailIcon />} primary={true} text={ this.props.strings.profilLabel.Email }  onClick={ this.onMailClicked} />
            <BncButton inTeams={ this.props.inTeams} circular={true} iconSharePoint={ 'Phone' } iconTeams={<CallIcon />} primary={true} text={ this.props.strings.profilLabel.Phone } onClick={ this.onPhoneClicked} />
          </Stack>;
  }

  private onChatClicked = (): void => {
    window.open(`https://teams.microsoft.com/l/chat/0/0?users=${this.props.userPrincipalName}`, "_blank");
  };

  private onMailClicked = (): void => {
    window.open(`mailto:${this.props.userPrincipalName}`, "_blank");
  };

  private onPhoneClicked = (): void => {

    let link: string = Utils.getPhoneUri(this.props.telephone);
    window.open(link, "_blank");
  };
}

export default WithAppContext(ProfilHeaderButtons);
