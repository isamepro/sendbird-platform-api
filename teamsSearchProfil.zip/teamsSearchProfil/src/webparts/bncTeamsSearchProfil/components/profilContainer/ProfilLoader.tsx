import * as React from "react";
import * as _ from "lodash";
import { Shimmer, mergeStyles, Fabric } from "@fluentui/react";

export interface IProfilLoaderProps {
}

export class ProfilLoader extends React.Component<IProfilLoaderProps, {} > {

  public render(): JSX.Element {

    const wrapperClass = mergeStyles({
      padding: 2,
      selectors: {
        '& > .ms-Shimmer-container': {
          margin: '10px 0',
        },
      },
    });

    return (
      <Fabric className={wrapperClass}>
        <Shimmer width="20%" />
        <Shimmer width="30%" />
        <Shimmer width="39%" />
        </Fabric>
      );
  }
}
