import * as React from "react";
import * as _ from "lodash";
import {
  IProfilDataItem
} from "bnc-library";
import { Logger, ConsoleListener } from "@pnp/logging";
import { getTheme, mergeStyleSets, FontWeights, ITag, IBasePicker, Stack, Shimmer, ShimmerElementType, ShimmerElementsGroup, Fabric, mergeStyles, ITheme, createTheme, IShimmerStyles, IShimmerStyleProps } from "@fluentui/react";
import { BncTagPicker } from "../../../controls/bncTagPicker/BncTagPicker";
import { IProfilProps } from "./IProfilProps";
import {
  colorSchemaBackgroundPressed,
  colorsSchemaBackgoundColor,
  colorsSchemaForeground
} from "../../../common/theme";
import { WithAppContext } from "../../../common/WithAppContext";
import { BncTagItem } from "../../../controls/bncTagItem/BncTagItem";

export interface IProfilSectionProps extends IProfilProps {}

const theme = getTheme();
const { palette, effects, fonts, semanticColors } = theme;
const styles = mergeStyleSets({
  text:{
    fontWeight: FontWeights.semibold,
    overflow: 'hidden',
    textOverflow: 'ellipsis',
    whiteSpace: 'nowrap',
    minWidth: 30,
    maxWidth: 'inherit',
    display: 'inline-block'
  }
});

/**
 * The Component shows tag items in read mode or TagPicker in edit mode.
 *
 * @export
 * @class BncProfilSection
 * @extends {React.Component<IProfilSectionProps, {}>}
 */
 class ProfilSection extends React.Component<IProfilSectionProps, {} > {

  constructor(props: IProfilSectionProps) {
    super(props);

    Logger.subscribe(new ConsoleListener());
  }

  public render(): JSX.Element {

    const noInformationFoundLabel = (!this.props.editMode &&
                                (!this.props.items || (this.props.items && this.props.items.length === 0)) &&
                                !this.props.isLoading &&
                                <>
                                  { this.props.noInformationFoundLabel}
                                </>);


        return (
          <Stack>
            <h3>{ this.props.title }</h3>
            { <Stack horizontal={!this.isLoading()} wrap styles={{ inner: { flexBasis: '100%' } }} >
              { this.props.editMode &&
                <BncTagPicker
                  onSearch={this.onSearch}
                  onChange={this.onChange}
                  items={this.props.items}
                  onAddItem={ this.props.onAddItem}
                  onRemoveItem={ this.props.onRemoveItem}
                  inTeams={ this.props.inTeams}
                  placeholder= {this.props.placeholder}
                  suggestionPrefixLabel= {this.props.suggestionPrefixLabel} />
              }
              { !this.props.editMode &&
                this.props.items &&
                this.props.items.map((tag: IProfilDataItem) => {
                  return (
                    <BncTagItem
                      rootStyles={
                        this.props.inTeams
                          ? {
                            backgroundColor: colorSchemaBackgroundPressed(this.props.siteVariables)
                          }
                          : {}
                      }
                    >
                      <span
                        className={styles.text}
                        style={this.props.inTeams
                            ? {
                              color: colorsSchemaForeground(this.props.siteVariables)
                            }
                            : {}
                        }
                        title={tag.name}
                      >
                        {tag.name}
                      </span>
                    </BncTagItem>
                  );
                })
              }
              { this.showShimmer() }
              { noInformationFoundLabel }
            </Stack> }
          </Stack>);
  }

  private isLoading = (): boolean => {
    return !this.props.editMode
           && (!this.props.items || (this.props.items && this.props.items.length === 0))
           && this.props.isLoading;
  }

  private showShimmer = (): JSX.Element => {

    const backgroundColor = colorsSchemaBackgoundColor(this.props.siteVariables);
    const shimmerElements = [
      { type: ShimmerElementType.line, height: 26, width: '20%' },
      { type: ShimmerElementType.gap, width: '2%' },
      { type: ShimmerElementType.line, height: 26, width: '20%' },
      { type: ShimmerElementType.gap, width: '2%' },
      { type: ShimmerElementType.line, height: 26, width: '15%' },
      { type: ShimmerElementType.gap, width: '2%' },
      { type: ShimmerElementType.line, height: 26 },
    ];

    const classNames = mergeStyleSets({
      wrapper: {
        selectors: {
          '& > .ms-Shimmer-container': {
            margin: '10px 0',
          },
        },
      },
      themedBackgroundWrapper: {
        padding: 0,
        margin: '10px 0',
        height: 20,
        boxSizing: 'border-box',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'stretch',
        background: `${backgroundColor}`,
        selectors: {
          '& > .ms-Shimmer-container': {
            flexGrow: 1,
          },
        },
      },
      indent: {
        paddingLeft: 18,
      },
    });

    return (
      this.isLoading() &&
      <div className={classNames.themedBackgroundWrapper}>
        <Shimmer shimmerColors={{ shimmer: '#bbbbbb', background: `${backgroundColor}`, }}
          shimmerElements={shimmerElements}
        />
      </div>
    );
  }

  private onSearch = async (filterText: string): Promise<ITag[]> => {
    return await this.props.onSearch(filterText, this.props.dataOperationQueryType);
  }

  private onChange = (items: ITag[]): void => {
    this.props.onChange(items);
  }

}

export default WithAppContext(ProfilSection);
