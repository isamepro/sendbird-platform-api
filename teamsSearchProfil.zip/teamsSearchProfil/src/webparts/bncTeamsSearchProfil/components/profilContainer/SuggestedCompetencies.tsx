import * as React from "react";
import { SplitButton, AcceptIcon, CloseIcon } from '@fluentui/react-northstar';
import {
  IProfilDataItem, IProfilSocialService, ProfilSocialService, ManageCompetencyStatus, TelemetryService, ITelemetryService, TelemetryEventName
} from "bnc-library";
import { Stack, DefaultButton, IContextualMenuItem, IIconProps } from "@fluentui/react";
import { IProfilProps } from "./IProfilProps";
import { Spacing10StackTokens } from "./ProfilContainer.styles";
import { WithAppContext } from "../../../common/WithAppContext";
import { ConsoleListener, Logger, LogLevel } from "@pnp/logging";

export interface ISuggestedCompetenciesProps extends IProfilProps {
  onAfterSuggestedCompetencyUpdated?: () => Promise<void>;
  buttonApproveTitle: string;
  buttonRejectTitle: string;
}

export interface ISuggestedCompetenciesState {
  processingTags: string[];
}

class SuggestedCompetencies extends React.Component<ISuggestedCompetenciesProps, ISuggestedCompetenciesState> {

  private profilSocialService: IProfilSocialService;
  private telemetryService: ITelemetryService;

  constructor(props: ISuggestedCompetenciesProps) {
    super(props);

    this.props.serviceScope.whenFinished(() => {
      this.profilSocialService = this.props.serviceScope.consume(ProfilSocialService.serviceKey);
      this.telemetryService = this.props.serviceScope.consume(TelemetryService.serviceKey);
    });
    this.state = {
      processingTags: []
    };

    Logger.activeLogLevel = LogLevel.Info;
    Logger.subscribe(new ConsoleListener());
    Logger.subscribe(new TelemetryService(this.props.serviceScope));
  }

  public render(): JSX.Element {
    // if items is undefined or items equal 0 or in edit mode, do not show the component.
    if ( !this.props.items
     || (this.props.items && this.props.items.length === 0)
     || this.props.editMode) {
     return <></>;
   }

    // Do not show the component if it's not my account
    if (!this.props.isMe) { return <></>; }

    return (
      <Stack>
        <h3>{ this.props.title }</h3>
        <Stack
          horizontal
          wrap
          tokens={Spacing10StackTokens}
          styles={{
            inner: {
              flexBasis: '100%'
            }
          }}
        >
          {
            this.getSuggestedCompetencies(this.props.inTeams)
          }
        </Stack>
      </Stack>
    );
  }

  private getSuggestedCompetencies = (inTeams: boolean) => {
    const toolIcon: IIconProps = { iconName: 'DeveloperTools' };
    const compIcon: IIconProps = { iconName: 'UserGauge' };
    let actionTags = this.props.items
      .map(item => {
        const processingStatus = this.state.processingTags.indexOf(item.key.toString()) >= 0;
        return (
          <>
            {inTeams && <SplitButton
              menu={[
                {
                  key: 'approve',
                  content: this.props.buttonApproveTitle,
                  icon: <AcceptIcon />
                },
                {
                  key: 'reject',
                  content: this.props.buttonRejectTitle,
                  icon: <CloseIcon />
                },
              ]}
              button={{
                content: item.name,
                loading: processingStatus,
              }}
              primary
              disabled={ processingStatus }
              toggleButton={{
                'aria-label': 'Options',
              }}
              onMenuItemClick={(e, { index }) => this.onTeamsSuggestedCompetencyActionClick(item, index)}
              
            />
            }
            {!inTeams &&
              <DefaultButton text={item.name} primary split
                disabled={ processingStatus }
                //  iconProps={item.fields['competenceType'] == 'TechnologySkill'? toolIcon:compIcon}
                menuProps={{
                  items: [
                    {
                      key: 'approve',
                      data: item,
                      text: this.props.buttonApproveTitle,
                      iconProps: { iconName: 'CheckMark' },
                      onClick: this.onSharePointMenuSuggestedClick
                    },
                    {
                      key: 'reject',
                      data: item,
                      text: this.props.buttonRejectTitle,
                      iconProps: { iconName: 'Cancel' },
                      onClick: this.onSharePointMenuRejectedClick
                    },
                  ],
                }}
              />
            }
          </>
      );
    });
    return actionTags;
  };

  private onSharePointMenuSuggestedClick = (ev?: any, menuItem?: IContextualMenuItem): void => {
    let item = menuItem.data as IProfilDataItem;
    item.status = ManageCompetencyStatus.sugested;
    this.onUpdateSuggestedCompetencies(item).then(() => {
      this.props.onAfterSuggestedCompetencyUpdated();
    });

  }
  private onSharePointMenuRejectedClick = (ev?: any, menuItem?: IContextualMenuItem): void => {
    let item = menuItem.data as IProfilDataItem;
    item.status = ManageCompetencyStatus.delete;
    this.onUpdateSuggestedCompetencies(item).then(() => {
      this.props.onAfterSuggestedCompetencyUpdated();
    });

  }

  private onTeamsSuggestedCompetencyActionClick = async (item: IProfilDataItem, index: number): Promise<void> => {

    item.status = (index === 0) ? ManageCompetencyStatus.sugested : ManageCompetencyStatus.delete;
    await this.onUpdateSuggestedCompetencies(item);
    this.props.onAfterSuggestedCompetencyUpdated();
  }

  private onUpdateSuggestedCompetencies = async (item: IProfilDataItem): Promise<void> => {
    let processingTags = this.state.processingTags.slice(0);

    if (processingTags.indexOf(item.key.toString()) >= 0) {
      // tag is already being processed, it's being either added or removing
      return;
    }

    processingTags.push(item.key.toString());
    this.setState({
      processingTags
    });

    await this.profilSocialService.updateSuggestedCompetency(this.props.userPrincipalName, item).then(() => {
      this.telemetryService.takeSnapshot(TelemetryEventName.profilSocialSuggestedCompetencyUpdate, item);
       processingTags = this.state.processingTags.slice(0);
       this.setState({
         processingTags: processingTags.filter(t => t !== item.key.toString())
       });

      Promise.resolve();
   });
  }
}
export default WithAppContext(SuggestedCompetencies);

