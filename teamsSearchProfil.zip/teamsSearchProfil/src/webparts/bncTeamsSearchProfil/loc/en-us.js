define([], function() {
  return {
    properties: {
      MockDataLabel: "Using of Mock data",
      DebugModeLabel: "Activate Debug Mode",
      showColleagueSectionLabel: "Show colleagues section",
      LabelYes: "Yes",
      LabelOff: "No"
    },
    Competencies: {
      CompetenciesPanelTitle: "Select a competency",
      CompetenciesLabel: "Competencies",
      EditMyCompetencies: "Edit my competencies",
      SaveMyCompetencies: "Save my competencies",
      CancelMyCompetencies: "Cancel my competencies"
    },
    Saving:"Saving ...",
    AddLabel:"Add",
    DropdownValuePrefixCategoryLabel:"in",
    PlaceHolderErrorTitle:"An error occur",
    PlaceHolderErrorDetailText:"This app has an error. Please contact your administrator.",
    HeaderDescription: "You need to configure this properties.",
    BasicGroupName: "Configration Teams tab",
    DescriptionFieldLabel: "Description Field",
    errors: {
      ProfilNotFound: "Profil not found.",
      ProfilsNotFound: "No profil found.",
      EmailNotFound: "Email not found.",
      PhoneNotFound: "Phone not found.",
      ExtNotFound: "Extension not found.",
      KeywordNotFound: "getProfils need keyword.",
      LoadProfilConfigurationException: "The profil configuration data ca not be found. Please refresh the page again.",
      SaveProfilException: "The profil updating failed. Please try again.",
      TermSetException:"An error occurs during term sets fetching.",
      ResourceNotFound:"The user requested is unknown. Please try again later."
    },
    profilLabel: {
      CompetenciesSeactionHeader: "My strengths",
      ActivitesHeader: "Activities related to my role",
      CompetencesHeader: "My skills",
      SuggestionsHeader: "Suggestions",
      ExpertisesHeader: "My Expertise",
      OutilsHeader: "My tools",
      ExperiencesHeader: "Professional experience",
      EducationsFormationsHeader: "Education and training",
      BadgesHeader: "Badges",
      LocalisationsHeader: "Location",
      ApplicationsHeader: "Applications",
      CertificationsHeader: "Certifications",
      LanguesBNCHeader: "Fluent languages",
      Poste: "ext",
      Loading: "Loading...",
      Search: "Search",
      Message: "Chat",
      Email: "Send email",
      Phone: "Call",
      Shared: "Shared",
      NoInformationFoundLabel: "No information found.",
      ColleguesFound: "{0} collegues in",
      Date: {
        Aujourdhui: "today",
        To: "to"
      }
    },
    LanguesBNC: {
      PanelTitle: "Select a fluent language",
      Label: "Fluent language",
      EditMy: "Edit my fluent languages",
      SaveMy: "Save my fluent languages",
      CancelMy: "Cancel",
      Level: "Niveau",
    },
    Certifications: {
      PanelTitle: "Select a certification",
      Label: "Certifications",
      EditMy: "Edit my certifications",
      SaveMy: "Save my certifications",
      CancelMy: "Cancel"
    }
    ,
    Applications : {
      PanelTitle: "Select a application",
      Label: "Applications",
      EditMy: "Edit my applications",
      SaveMy: "Save my applications",
      CancelMy: "Cancel"
    },
    Actions: {
      AddToMyProfil: 'Add to my public profile',
      RemoveSuggestionsToMyProfil: 'Do not offer me anymore'
    },
    Network: {
      Colleagues: 'Colleagues',
      SimilarProfiles: 'Similar profiles',
      NoColleaguesMessage: 'No colleagues have been found'
    },
    Buttons: {
      SaveButtonLabel: 'Save',
      CancelButtonLabel: 'Cancel',
      EditButtonLabel: 'Edit'
    },
    Languages: {
      French: "French",
      English: "English",
    },
    LanguagesAbility:{
      oral_expression:"Speak",
      written_expression:"Write",
      oral_comprehension: "Oral comprehension",
      written_comprehension: "Read",
      other:"Other"
    },
    PropertyPaneResultLangue: "Language",
  };
});
