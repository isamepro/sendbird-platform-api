define([], function () {
  return {
    properties: {
      MockDataLabel: "Utilisation de données fictives",
      DebugModeLabel: "Activer le mode Debug",
      showColleagueSectionLabel: "Afficher la section des collègues",
      LabelYes: "Oui",
      LabelOff: "Non"
    },
    Competencies: {
      CompetenciesPanelTitle: "Selection de compétence",
      CompetenciesLabel: "Compétences",
      EditMyCompetencies: "Éditer mes compétences",
      SaveMyCompetencies: "Sauvegarder mes compétences",
      CancelMyCompetencies: "Annuler mes compétences"
    },
    Saving: "Enregistrement ...",
    AddLabel: "Ajouter",
    DropdownValuePrefixCategoryLabel: "dans",
    PlaceHolderErrorTitle: "Une erreur s'est produite",
    PlaceHolderErrorDetailText: "Cette application est en erreur. SVP contacter votre administrateur.",
    HeaderDescription: "Vous devez définir ces propriétés.",
    BasicGroupName: "Configration du tab Teams.",
    DescriptionFieldLabel: "Description Field",
    errors: {
      ProfilNotFound: "Le profil n'a pas été trouver.",
      ProfilsNotFound: "Aucun profil.",
      EmailNotFound: "Le courriel n'est pas défini.",
      PhoneNotFound: "Le téléphone n'est pas défini.",
      ExtNotFound: "Le poste n'est pas défini.",
      KeywordNotFound: "getProfils need keyword.",
      LoadProfilConfigurationException: "Impossible de trouver la configuration du profil. SVP rafraichir la page.",
      SaveProfilException: "La mise à jour du profil n'a pu etre effectuée correctement. SVP réessayer une nouvelle fois.",
      TermSetException: "Une erreur s'est produite dans la recherche des termes.",
      ResourceNotFound: "l'utilisateur demandé est inconnu. SVP, réessayer plus tard."
    },
    profilLabel: {
      CompetenciesSeactionHeader: "Mes atouts",
      ActivitesHeader: "Activités liées à mon rôle",
      CompetencesHeader: "Mes compétences",
      SuggestionsHeader: "Suggestions",
      ExpertisesHeader: "Mon Expertise",
      OutilsHeader: "Mes outils",
      ExperiencesHeader: "Expérience professionnelle",
      EducationsFormationsHeader: "Éducation et formation",
      BadgesHeader: "Badges",
      LocalisationsHeader: "Localisation",
      ApplicationsHeader: "Applications",
      CertificationsHeader: "Certifications",
      LanguesBNCHeader: "Langues maitrisées",
      Poste: "poste",
      Loading: "Chargement en cours...",
      NoInformationFoundLabel: "Aucune information trouvée.",
      Search: "Rechercher",
      Message: "Envoyer un message",
      Email: "Envoyer un courriel",
      Phone: "Téléphoner",
      Shared: "Partager",
      ColleguesFound: "{0} collègues dans",
      Date: {
        Aujourdhui: "Aujourd'hui",
        To: "à"
      }
    },
    LanguesBNC: {
      PanelTitle: "Selection une langue",
      Label: "Langues",
      EditMy: "Éditer mes langues",
      SaveMy: "Sauvegarder mes langues",
      CancelMy: "Annuler mes langues",
      Level: "Niveau"
    },
    Certifications: {
      PanelTitle: "Selection une certification",
      Label: "Certifications",
      EditMy: "Éditer mes certifications",
      SaveMy: "Sauvegarder mes certifications",
      CancelMy: "Annuler mes certifications"
    },
    Applications: {
      PanelTitle: "Selection une application",
      Label: "Applications",
      EditMy: "Éditer mes applications",
      SaveMy: "Sauvegarder mes applications",
      CancelMy: "Annuler mes applications"
    },
    Actions: {
      AddToMyProfil: "Ajouter à mon profil public",
      RemoveSuggestionsToMyProfil: "Ne plus me proposer"
    },
    Network: {
      Colleagues: 'Collègues',
      SimilarProfiles: 'Profils similaires',
      NoColleaguesMessage: 'Nous n\'avons trouvé aucun collègue'
    },
    Buttons: {
      SaveButtonLabel: 'Enregistrer',
      CancelButtonLabel: 'Annuler',
      EditButtonLabel: 'Modifier'
    },
    Languages: {
      French: "Français",
      English: "Anglais",
    },
    LanguagesAbility: {
      oral_expression: "Parlé",
      written_expression: "Écrit",
      oral_comprehension: "Compréhension oral",
      written_comprehension: "Lu",
      other: "Autre"
    },
    PropertyPaneResultLanguage: "Langue",
  };
});
