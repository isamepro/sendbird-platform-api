declare interface IBncTeamsProfilWebPartStrings {
  properties: {
    MockDataLabel: string;
    showColleagueSectionLabel: string;
    DebugModeLabel: string;
    DebugModeLabel: string;
    LabelYes: string;
    LabelOff: string;
  };
  Competencies: {
    CompetenciesPanelTitle: string;
    CompetenciesLabel: string;
    EditMyCompetencies: string;
    SaveMyCompetencies: string;
    CancelMyCompetencies: string;
  };
  Saving: string;
  AddLabel: string;
  DropdownValuePrefixCategoryLabel: string;
  PlaceHolderErrorTitle: string;
  PlaceHolderErrorDetailText: string;
  HeaderDescription: string;
  ConfigurationJsonLabel: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
  errors: {
    ProfilNotFound: string;
    ProfilsNotFound: string;
    EmailNotFound: string;
    PhoneNotFound: string;
    ExtNotFound: string;
    KeywordNotFound: string;
    LoadProfilConfigurationException: string;
    SaveProfilException: string;
    TermSetException: string;
    ResourceNotFound: string;
  };
  profilLabel: {
    CompetenciesSeactionHeader: string;
    ActivitesHeader: string;
    CompetencesHeader: string;
    SuggestionsHeader: string;
    ExpertisesHeader: string;
    OutilsHeader: string;
    ExperiencesHeader: string;
    EducationsFormationsHeader: string;
    BadgesHeader: string;
    LocalisationsHeader: string;
    ApplicationsHeader: string;
    CertificationsHeader: string;
    LanguesBNCHeader: string;
    Poste: string;
    Loading: string;
    Search: string;
    Message: string;
    Email: string;
    Phone: string;
    Shared: string;
    ColleguesFound: string;
    NoInformationFoundLabel: string;
    Date: {
      Aujourdhui: string;
      To: string;
    };
  };
  LanguesBNC: {
    PanelTitle: string;
    Label: string;
    EditMy: string;
    SaveMy: string;
    CancelMy: string;
    Level: string;
  };
  Certifications: {
    PanelTitle: string;
    Label: string;
    EditMy: string;
    SaveMy: string;
    CancelMy: string;
  };
  Applications: {
    PanelTitle: string;
    Label: string;
    EditMy: string;
    SaveMy: string;
    CancelMy: string;
  };
  Actions:{
    AddToMyProfil: string ;//'Ajouter a mon profil public'
    RemoveSuggestionsToMyProfil: string ;//'Ne plus me proposer'
  };
  Network: {
    Colleagues: string;
    SimilarProfiles: string;
    NoColleaguesMessage: string;
  };
  Buttons: {
    SaveButtonLabel: string;
    CancelButtonLabel: string;
    EditButtonLabel: string;
  };
  Languages: {
    French: string,
    English: string,
  };
  LanguagesAbility: {
    oral_expression:string,
    written_expression:string,
    oral_comprehension:string,
    written_comprehension:string,
    other:string
  }
  PropertyPaneResultLanguage: string;
}

declare module "BncTeamsProfilWebPartStrings" {
  const strings: IBncTeamsProfilWebPartStrings;
  export = strings;
}
