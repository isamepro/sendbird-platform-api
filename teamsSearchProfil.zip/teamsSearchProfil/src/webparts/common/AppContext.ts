import * as React from "react";
import { SiteVariablesPrepared }  from '@fluentui/react-northstar';
import { WebPartContext } from "@microsoft/sp-webpart-base";
import { IProfilConfiguration } from '../models/IProfilConfiguration';
import { ServiceScope } from "@microsoft/sp-core-library";

export interface IAppContextProps {
  editMode?: boolean;
  strings?: IBncTeamsProfilWebPartStrings;
  siteVariables?: SiteVariablesPrepared;
  isMe?: boolean;
  inTeams: boolean;
  email: string;
  userPrincipalName: string;
  serviceScope: ServiceScope;
  language: string;
}

export const AppContext = React.createContext<IAppContextProps>(undefined);
