import { IPhone } from "bnc-library";
import * as _ from "lodash";

export class Utils {

  public static getPhoneUri = (phones: IPhone[]): string => {

    // get phone object
    let phonesObject: IPhone = phones[0];
    //get first phone by default
    let phone: string = _.get(phonesObject, 'phone', "").replace(".", "-");
    //get extension add p
    const ext = _.get(phonesObject, 'ext');
    const extension: string = (ext) ? `p${ext}` : "";
    return `tel:${phone}${extension}`;
  }

  /**
   * Change string guid in format '/Guid(xxxxxxxx-xxxx-xxxx)/' to proper Guid string.
   *
   * @static
   * @memberof Utils
   */
  public static transformStringToGuid = (value: string): string => {
     return value.replace(/Guid|[()]|\//gi, (x) => {
       return '';
     });
  }
}
