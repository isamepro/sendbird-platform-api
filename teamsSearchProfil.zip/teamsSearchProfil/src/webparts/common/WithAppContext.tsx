import * as React from 'react';
import { useContext } from 'react';
import { AppContext } from './AppContext';

//Infuse all components wrapped with this Higher Order Component with the serviceScope
export const WithAppContext = (Component: any) => {
  return (props: any) => {
    const appContext = useContext(AppContext);

    return <Component
              editMode={appContext.editMode}
              siteVariables={appContext.siteVariables}
              strings={appContext.strings}
              isMe={appContext.isMe}
              inTeams={appContext.inTeams}
              email={appContext.email}
              userPrincipalName={appContext.userPrincipalName}
              serviceScope={appContext.serviceScope}
              language={appContext.language}
              {...props} />;
  };
};
