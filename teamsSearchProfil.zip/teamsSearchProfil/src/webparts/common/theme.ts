import { SiteVariablesPrepared }  from '@fluentui/react-northstar';

import {
  ColorSchemeMapping,
  ColorScheme,
  TeamsColorNames
}  from '@fluentui/react-northstar';

export const colorsSchema = ( variables: SiteVariablesPrepared ): ColorSchemeMapping<ColorScheme, TeamsColorNames> => {
  return variables.colorScheme;
};

export const colorsSchemaBrandBackgoundColor = ( variables: SiteVariablesPrepared ): string => {
  if (!variables) return '';
  return colorsSchema( variables ).brand.background;
};
export const colorsSchemaBrandBorderColor = (
  variables: SiteVariablesPrepared
): string => {
  if (!variables) return '';
  return colorsSchema( variables ).brand.borderFocusWithin;
};

export const colorsSchemaBorderFocusWithinColor = (
  variables: SiteVariablesPrepared
): string => {
  if (!variables) return '';
  return colorsSchema( variables ).default.borderFocusWithin;
};


export const colorsSchemaBrandForegroundColor4 = (
  variables: SiteVariablesPrepared
): string => {
  if (!variables) return '';
  return colorsSchema( variables ).brand.foreground4;
};
export const colorsSchemaBrandForegroundColor = (
  variables: SiteVariablesPrepared
): string => {
  if (!variables) return '';
  return colorsSchema( variables ).brand.foreground;
};
export const colorsSchemaBrandBackgoundFocus = (
  variables: SiteVariablesPrepared
): string => {
  if (!variables) return '';
  return colorsSchema( variables ).brand.backgroundFocus;
};
export const colorsSchemaBrandBackgoundHover = (
  variables: SiteVariablesPrepared
): string => {
  if (!variables) return '';
  return colorsSchema( variables ).brand.backgroundHover;
};

export const colorsSchemaBackgoundColor = (
  variables: SiteVariablesPrepared
): string => {
  if (!variables) return '';
  return colorsSchema( variables ).default.background2;
};

export const colorsSchemaBackgoundColorLight = (
  variables: SiteVariablesPrepared
): string => {
  if (!variables) return '';
  return colorsSchema( variables ).default.background;
};

export const colorsSchemaForeground = (
  variables: SiteVariablesPrepared
): string => {
  if (!variables) return '';
  return colorsSchema( variables ).default.foreground;
};
export const colorsSchemaForeground1 = (
  variables: SiteVariablesPrepared
): string => {
  if (!variables) return '';
  return colorsSchema( variables ).default.foreground1;
};
export const colorsSchemaForeground2 = (
  variables: SiteVariablesPrepared
): string => {
  if (!variables) return '';
  return colorsSchema( variables ).default.foreground2;
};
export const colorsSchemaBorder = (
  variables: SiteVariablesPrepared
): string => {
  if (!variables) return '';
  return colorsSchema( variables ).default.border;
};

export const colorSchemaBorderHover = (
  variables: SiteVariablesPrepared
): string => {
  if (!variables) return '';
  return colorsSchema( variables ).default.borderHover;
};

export const colorSchemaBackgroundHover = (
  variables: SiteVariablesPrepared
): string => {
  if (!variables) return '';
  return colorsSchema( variables ).default.backgroundHover;
};

export const colorSchemaBackgroundPressed = (
  variables: SiteVariablesPrepared
): string => {
  if (!variables) return '';
  return colorsSchema( variables ).default.backgroundPressed;
};

export const colorsSchemaForegroundHover = (
  variables: SiteVariablesPrepared
): string => {
  if (!variables) return '';
  return colorsSchema( variables ).default.foregroundHover;
};

export const colorSchemaBorderActive = (
  variables: SiteVariablesPrepared
): string => {
  if (!variables) return '';
  return colorsSchema( variables ).default.border3;
};

export const colorSchemaBorderFocus = (
  variables: SiteVariablesPrepared
): string => {
  if (!variables) return '';
  return colorsSchema( variables ).default.borderFocus;
};

export const colorSchemaBrandBorderFocus = (
  variables: SiteVariablesPrepared
): string => {
  if (!variables) return '';
  return colorsSchema( variables ).brand.borderFocus1;
};
