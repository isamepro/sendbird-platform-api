import * as React from "react";
import { Button, Alert } from '@fluentui/react-northstar';
import { getTheme, mergeStyleSets, Stack, DefaultButton, IconButton, MessageBarType, MessageBar } from "@fluentui/react";

export interface IBncAlertProps {
  inTeams: boolean;
  text: string;
  onClick:() => void;
}

/**
 * BncAlert encapsulates Alert from northstar and MessageBar from fluent ui.
 *
 * @export
 * @class BncButton
 * @extends {React.Component<IBncAlertProps, {}>}
 */
export class BncAlert extends React.Component<IBncAlertProps, {}> {


  public render() {
    return (<Stack>
      { this.props.inTeams &&
        <Alert content={this.props.text} dismissible variables={{ urgent: true }} onVisibleChange={this.props.onClick} />
      }
      { !this.props.inTeams &&
        <MessageBar messageBarType={MessageBarType.error} isMultiline={false} dismissButtonAriaLabel="Close" onDismiss={this.props.onClick} >
          { this.props.text }
        </MessageBar>
      }
    </Stack>
    );
  }
}
