import * as React from "react";
import { Button, ShorthandValue, BoxProps } from '@fluentui/react-northstar';
import { getTheme, mergeStyleSets, Stack, DefaultButton, IconButton } from "@fluentui/react";

export interface IBncButtonProps {
  inTeams: boolean;
  text: string;
  onClick:() => void;
  disabled?: boolean;
  primary: boolean;
  circular?: boolean;
  iconTeams?: ShorthandValue<BoxProps>;
  iconSharePoint?: string;
}

/**
 * BncButton encapsulates Button from northstar and DefautButton from fluent ui.
 *
 * @export
 * @class BncButton
 * @extends {React.Component<IBncButtonProps, {}>}
 */
export class BncButton extends React.Component<IBncButtonProps, {}> {


  public render() {
    return (<Stack>
      { this.props.inTeams &&
        <Button
          circular={ this.props.circular }
          secondary={!this.props.primary}
          primary={this.props.primary}
          iconPosition="before"
          disabled={this.props.disabled}
          content={!this.props.circular ? this.props.text : undefined }
          title={this.props.circular ? this.props.text : undefined }
          icon={ this.props.iconTeams }
          onClick={this.props.onClick} />
      }
      { !this.props.inTeams && !this.props.circular &&
        <DefaultButton
          iconProps={{ iconName: this.props.iconSharePoint }}
          primary={this.props.primary}
          text={ this.props.text }
          onClick={this.props.onClick}
          allowDisabledFocus
          disabled={this.props.disabled}
        />
      }
      { !this.props.inTeams && this.props.circular &&
        <IconButton
          iconProps={{ iconName: this.props.iconSharePoint }}
          title={ this.props.text }
          ariaLabel={ this.props.text }
          onClick={this.props.onClick}
          disabled={this.props.disabled} />
      }
    </Stack>
    );
  }
}
