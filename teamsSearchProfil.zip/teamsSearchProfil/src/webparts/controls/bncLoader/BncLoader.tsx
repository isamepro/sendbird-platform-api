import * as React from "react";
import { Loader } from '@fluentui/react-northstar';
import { getTheme, mergeStyleSets, Stack, Shimmer } from "@fluentui/react";

export interface IBncLoader {
  inTeams: boolean;

}

/**
 * BncLoader encapsulates Loader fron northstar and shimmer from fluent ui.
 *
 * @export
 * @class BncLoader
 * @extends {React.Component<IBncLoader, {}>}
 */
export class BncLoader extends React.Component<IBncLoader, {}> {

  public render() {
    return (<Stack>
      { this.props.inTeams &&
        <Loader />
      }
      { !this.props.inTeams &&
        <Shimmer />}
    </Stack>
    );
  }
}
