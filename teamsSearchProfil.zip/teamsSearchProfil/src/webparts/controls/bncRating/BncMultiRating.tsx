import * as React from 'react';
import { IconButton, Callout, mergeStyleSets, getTheme, FontWeights, ITagItemProps } from '@fluentui/react';
import { initializeIcons } from '@uifabric/icons';
import { BncRatingStar } from './bncRatingStar';

interface IValues {
  [key: string]: string | Date | undefined | number | boolean | null;
}
export interface IBncMultiRatingProps {
  title?: string;
  values?: IValues;
  onDelete: () => void;
  isPickerDisabled?: boolean;
  tagItemProps?: ITagItemProps;
  readonly?: boolean;
  tooltip?: string;
  inTeams?: boolean;
  backgroundColor?: string;
  secondaryBackgroundColor?: string;
  fontColor?: string;
  secondaryFontColor?: string;
  labelForOther: string;
  labels: { [key: string]: string };
  numberOfStars: number;
  ratingSymbol: string;
  emptyRatingSymbol: string;
  height:string;
}

const theme = getTheme();
const { palette, effects, semanticColors } = theme;
const getStyles = (props: IBncMultiRatingProps) => (
  mergeStyleSets({
    root: {
      boxSizing: 'content-box',
      flexShrink: '1',
      maxWidth: 150,
      minWidth: 0, // needed to prevent long tags from overflowing container
      borderRadius: effects.roundedCorner2,
      color: semanticColors.inputText,
      margin: 2,
      cursor: 'default',
      userSelect: 'none',
      padding: '10px',
      display: 'inline-table',
      background: props.inTeams && props.backgroundColor ? props.backgroundColor : palette.neutralLight
    },
    buttonArea: {
      verticalAlign: 'top',
      display: 'inline-block',
      textAlign: 'center',
      minWidth: 55,
      height: 26,
    },
    text: {
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap',
      minWidth: 30,
      margin: '0 5px',
      color: props.inTeams && props.fontColor ? props.fontColor : undefined,
      'font-weight': '600'
    },
    subText: {
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap',
      minWidth: 30,
      margin: '0 5px',
      color: props.inTeams && props.secondaryFontColor ? props.secondaryFontColor : undefined,
      'font-weight': '600'
    },
    callout: {
      minWidth: 200,
      maxWidth: 300
    },
    header: {
      padding: '15px 14px 8px',
    },
    title: [
      theme.fonts.xLarge,
      {
        margin: 0,
        fontWeight: FontWeights.semilight,
      },
    ],
    inner: {
      height: '100%',
      padding: '0 2px 2px',
      fontWeight: FontWeights.semilight,
    },
    ratingCard: {
      display: 'table-cell',
      background: props.inTeams && props.secondaryBackgroundColor ? props.secondaryBackgroundColor : palette.neutralLighter,
      'border-left-width': '5px',
      'border-right-width': '5px',
      'border-style': 'solid',
      'border-color': props.inTeams && props.backgroundColor ? props.backgroundColor : palette.neutralLight,
      'padding-top': '5px',
      'padding-bottom': '5px',
      'padding-left': '5px',
      'padding-right': '5px',
      color: props.inTeams && props.secondaryFontColor ? props.secondaryFontColor : palette.neutralSecondaryAlt,
      'text-align': 'center'
    },
    star: {
      'white-space': 'nowrap'
    },
    languageCompetencies: {
      'padding-top': '10px',
    },

  })
);

export const BncMultiRating: React.FunctionComponent<IBncMultiRatingProps> = props => {
  initializeIcons();
  const { title, values } = props;

  const styles = getStyles(props);

  return (
    <div
      className={styles.root}
      role={'listitem'}>
      <span className={styles.text} aria-label={title} title={title}>
        {title.charAt(0).toUpperCase() + title.slice(1)}
      </span>
      
      <div className={styles.languageCompetencies}>
        {Object.keys(values).map((key: string) => {
          const label = (Object.keys(props.labels).indexOf(key) >= 0) ? props.labels[key] : props.labelForOther;
          return (
            <div
              className={styles.ratingCard}>
              <span className={styles.subText} aria-label={label} title={label}>
                {label}
              </span>
              <BncRatingStar
                currentRating={+values[key]}
                numberOfStars={props.numberOfStars}
                ratingSymbol={props.ratingSymbol}
                emptyRatingSymbol={props.emptyRatingSymbol}
                ratingSymbolColor={props.inTeams && props.secondaryFontColor ? props.secondaryFontColor : palette.neutralSecondaryAlt}
                height={props.height}
                readOnly={props.readonly}
              />
            </div>
          );
        })}
      </div>
    </div>
  );
};
