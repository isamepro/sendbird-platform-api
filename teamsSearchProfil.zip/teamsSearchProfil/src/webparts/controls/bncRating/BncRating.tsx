import * as React from 'react';
import { IconButton, Rating, Callout, mergeStyleSets, getTheme, FontWeights, ActionButton, IIconProps, ITagItemProps, RatingSize, Icon, ITooltipHostStyles, TooltipHost  } from '@fluentui/react';
import { initializeIcons } from '@uifabric/icons';
import { useBoolean, useId } from '@uifabric/react-hooks';

export interface IBncRatingProps  {
  title?: string;
  value?: number;
  onDelete: () => void;
  isPickerDisabled?: boolean;
  tagItemProps?: ITagItemProps;
  readonly?: boolean;
  tooltip?: string;
  inTeams?: boolean;
  backgroundColor?:string;
  fontColor?:string;
}

const theme = getTheme();
const { palette, effects, fonts, semanticColors } = theme;
const getStyles = (props: IBncRatingProps) => (
  mergeStyleSets({
    root:{
      boxSizing: 'content-box',
      flexShrink: '1',
      maxWidth: 150,
      minWidth: 0, // needed to prevent long tags from overflowing container
      borderRadius: effects.roundedCorner2,
      color: semanticColors.inputText,
      margin: 2,
      cursor: 'default',
      userSelect: 'none',
      padding: '10px',
      background: props.inTeams && props.backgroundColor ? props.backgroundColor : palette.neutralLight
    },
    buttonArea: {
      verticalAlign: 'top',
      display: 'inline-block',
      textAlign: 'center',
      minWidth: 55,
      height: 26,
    },
    text: {
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap',
      minWidth: 30,
      margin: '0 5px',
      color: props.inTeams && props.fontColor ? props.fontColor : undefined
    },
    hr:{
      color: theme.palette.neutralTertiary,
      height: '100%',
    },
    callout: {
      minWidth:200,
      maxWidth: 300
    },
    header: {
      padding: '15px 14px 8px',
    },
    rating: {
      padding: '0 8px 0px'
    },
    ratingStar: {
      color: props.inTeams && props.fontColor ? props.fontColor : undefined
    },
    ratingStarBack: {
      color: props.inTeams && props.fontColor ? props.fontColor : undefined
    },
    title: [
      theme.fonts.xLarge,
      {
        margin: 0,
        fontWeight: FontWeights.semilight,
      },
    ],
    inner: {
      height: '100%',
      padding: '0 2px 2px',
      fontWeight: FontWeights.semilight,
    }
  })
);

export const BncRating: React.FunctionComponent<IBncRatingProps> = props => {
  const [isCalloutVisible, { toggle: toggleIsCalloutVisible }] = useBoolean(false);
  initializeIcons();
  const labelId: string = useId('callout-label');
  const descriptionId: string = useId('callout-description');
  const deleteIcon: IIconProps = { iconName: 'Trash' };
  const { title } = props;
  const calloutProps = { gapSpace: 0 };
  const hostStyles: Partial<ITooltipHostStyles> = { root: { display: 'inline-block' } };
  const tooltipId = useId('tooltip');
  const onDeleteClicked = (): void => {
    toggleIsCalloutVisible();
    props.tagItemProps.onRemoveItem();
    props.onDelete();
  };
  const styles = getStyles(props);
    return (
      <div
        className={styles.root}
        role={'listitem'}>
          <span className={styles.text} aria-label={title} title={title}>
                {title}
          </span>
          { !props.readonly && (
            <div className={styles.buttonArea} id={title}>
              <IconButton
                onClick={toggleIsCalloutVisible}
                iconProps={{ iconName: 'ChevronDown', styles: { root: { fontSize: '12px' } } }} />
            </div>
          )}
        {isCalloutVisible && (
          <Callout
            className={styles.callout}
            ariaLabelledBy={labelId}
            ariaDescribedBy={descriptionId}
            role="alertdialog"
            gapSpace={0}
            target={`#${title}`}
            onDismiss={toggleIsCalloutVisible}
            setInitialFocus >
            <div className={styles.header}>
              Niveau de maitrise :
          </div>
          <div className={styles.inner}>
            <Rating
              className={styles.rating}
              id="small"
              min={1}
              max={3}
              size={RatingSize.Small}
              rating={props.value} />
              <hr className={styles.hr} />
              <ActionButton iconProps={deleteIcon} allowDisabledFocus onClick={onDeleteClicked} >
                Supprimer
              </ActionButton>
          </div>

          </Callout>)
          }

        <div>
          <TooltipHost
            content={props.tooltip}
            id={tooltipId}
            calloutProps={calloutProps}
            styles={hostStyles}>
            <Rating
              id="small"
              size={RatingSize.Small}
              readOnly={props.readonly}
              min={1}
              max={3}
              rating={ props.value } />
          </TooltipHost>
        </div>
      </div>
    );
};
