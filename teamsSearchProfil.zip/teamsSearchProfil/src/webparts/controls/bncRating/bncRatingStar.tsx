import * as _ from 'lodash';
import * as React from 'react';
import { createRef } from 'react';

export interface IBncStarRatingProps {
    currentRating: number;
    numberOfStars: number;
    onClick?: (rating) => void;
    ratingSymbol: string;
    emptyRatingSymbol: string;
    ratingSymbolColor: string;
    readOnly: boolean;
    height:string;
}
export interface IBncStarRatingState {
    currentRating: number;
}

export class BncRatingStar extends React.Component<IBncStarRatingProps, IBncStarRatingState> {
    public constructor(props) {
        super(props);
        this.state = {
            currentRating: this.props.currentRating
        };
    }

    private ratingRef = createRef<HTMLDivElement>();

    public componentDidMount() {
        this.setRating();
    }

    public hoverHandler = ev => {
        const stars: HTMLCollectionOf<HTMLElement> = ev.target.parentElement.getElementsByClassName('star');
        const hoverValue = ev.target.dataset.value;
        [].slice.call(stars).forEach((star: HTMLElement) => {
            star.style.color = this.props.ratingSymbolColor;
            star.style.fontSize=this.props.height;
            this.state.currentRating >= +star.dataset.value ? star.innerText = this.props.ratingSymbol : star.innerText = this.props.emptyRatingSymbol;

        });
    };

    private setRating() {
        const stars: HTMLCollectionOf<HTMLElement> = this.ratingRef.current.getElementsByClassName('star') as HTMLCollectionOf<HTMLElement>;
        [].slice.call(stars).forEach((star: HTMLElement) => {
            star.style.color = this.props.ratingSymbolColor;
            star.style.fontSize=this.props.height;
            this.state.currentRating >= +star.dataset.value ? star.innerText = this.props.ratingSymbol : star.innerText = this.props.emptyRatingSymbol;
        });
    }

    private starClickHandler = ev => {
        let rating = ev.target.dataset.value;
        this.setState({ currentRating: rating }); // set state so the rating stays highlighted
        if (this.props.onClick) {
            this.props.onClick(rating); // emit the event up to the parent
        }
    };

    public render() {
        var numberOfStar: number[] = Array.apply(null, { length: this.props.numberOfStars }).map(Number.call, Number);

        return (
            <div
                className="rating"
                ref={this.ratingRef}
                data-rating={this.state.currentRating}
                onMouseOut={this.setRating}
            >
                {numberOfStar.map((n, i) => {
                    return (
                        <span
                            className="star"
                            key={i + 1}
                            data-value={i + 1}
                            onMouseOver={!this.props.readOnly && this.hoverHandler}
                            onClick={this.starClickHandler}
                        >
                            {_.unescape(this.props.ratingSymbol)}
                        </span>
                    );
                })}
            </div>
        );
    }
}