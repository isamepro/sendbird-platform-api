import * as React from "react";
import { getTheme, mergeStyleSets } from "@fluentui/react";

export interface IBncTagItem {
  rootStyles?: {
    backgroundColor?: string;
  };
}


const theme = getTheme();
const { palette, effects, fonts, semanticColors } = theme;
const getStyles = (rootStyles) => (
  mergeStyleSets({
    root:{
      boxSizing: 'content-box',
      flexShrink: '1',
      maxWidth: 250,
      minWidth: 0, // needed to prevent long tags from overflowing container
      borderRadius: effects.roundedCorner2,
      color: semanticColors.inputText,
      background: (rootStyles && rootStyles.backgroundColor ? rootStyles.backgroundColor : null) || palette.neutralLight,
      margin: '2px 10px 6px 2px',
      cursor: 'default',
      padding: '10px 10px',
      userSelect: 'none',
      fontSize: 14
    }
  })
);
export class BncTagItem extends React.Component<IBncTagItem, {}> {

  public render() {
    const { rootStyles } = this.props;
    let styles = getStyles(rootStyles);
    return (
      <div className={styles.root}>
          {this.props.children}
      </div>
    );
  }
}
