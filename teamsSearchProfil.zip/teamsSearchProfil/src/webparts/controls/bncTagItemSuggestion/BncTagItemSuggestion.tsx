import * as React from "react";
import { TagItemSuggestion } from "@fluentui/react";

export interface IBncTagItemSuggestion{
  title: string;
  category?: string;
}
export class BncTagItemSuggestion extends React.Component<IBncTagItemSuggestion, {}> {

  public render() {
    return (

      <TagItemSuggestion>
        <span style={{display: 'flex'}}>{this.props.title}</span>
        <span style={{display: 'flex'}}><small>{this.props.category}</small></span>
      </TagItemSuggestion>
    );
  }
}
