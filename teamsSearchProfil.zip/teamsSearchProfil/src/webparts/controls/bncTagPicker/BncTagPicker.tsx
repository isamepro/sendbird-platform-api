import * as React from "react";
import * as _ from "lodash";
import {
  ITagBNC,
  IProfilDataItem
} from "bnc-library";
import { Logger, ConsoleListener } from "@pnp/logging";
import { getTheme, mergeStyleSets, FontWeights,
        TagPicker, IBasePicker, ITag,
        ITagItemProps, TagItem, IRefObject } from "@fluentui/react";
import stylesModule from './BncTagPicker.module.scss';
import { AppContext } from "../../common/AppContext";
import {
  colorsSchemaBackgoundColor,
  colorsSchemaForeground,
  colorsSchemaBackgoundColorLight,
  colorsSchemaBorder,
  colorSchemaBorderHover,
  colorSchemaBackgroundHover,
  colorsSchemaForegroundHover,
  colorSchemaBorderActive,
  colorSchemaBrandBorderFocus,
  colorsSchemaBrandBorderColor,
  colorsSchemaBrandForegroundColor,
  colorsSchemaBorderFocusWithinColor,
  colorSchemaBackgroundPressed
} from "../../common/theme";
import { SiteVariablesPrepared } from "@fluentui/react-northstar";
import { Utils } from "../../common/Utils";
import { BncTagItemSuggestion } from '../bncTagItemSuggestion/BncTagItemSuggestion';


export interface IBncTagPickerProps {
  onChange?: (items: ITag[]) => void;
  onAddItem?: (item: ITag) => void;
  onRemoveItem?: (item: ITag) => void;
  onSearch: (text: string) => Promise<ITag[]>;
  inTeams: boolean;
  items?: IProfilDataItem[];
  suggestionsHeaderText?: string;
  noResultsFoundText?: string;
  siteVariables?: SiteVariablesPrepared;
  placeholder?: string;
  suggestionPrefixLabel?: string;

  backgoundColor?: string;
  foregroundColor?: string;
  backgoundColorLight?: string;
  borderColor?: string;
  borderHoverColor?: string;
  backgroundHoverColor?: string;
  foregroundHoverColor?: string;
  borderActiveColor?: string;
  borderFocusColor?: string;
}

const theme = getTheme();
const { palette, effects, fonts, semanticColors } = theme;
const getStyles = (siteVariables) => {
  return mergeStyleSets({
      tagPickerTheme: {
        backgroundColor: `${colorsSchemaBorderFocusWithinColor(siteVariables)}`,
        width: '100%'
      },
      tagPickerThemeFocus: {
        borderBottom: `solid 1px ${colorsSchemaBrandForegroundColor(siteVariables)}`
      },
      itemTagWrapTheme: {
        background: `${colorSchemaBackgroundPressed(siteVariables)}`,
        border: 0,
        marginTop: '2px',
        marginRight: '10px',
        marginBottom: '8px',
        marginLeft: '2px'
      },
      itemTagDiv: {
        padding: '10px'
      },
      itemTeamsTagDiv: {
        backgroundColor: `${colorSchemaBackgroundPressed(siteVariables)}`,
        color: colorsSchemaForeground(siteVariables),
        fontWeight: FontWeights.semibold,
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        whiteSpace: 'nowrap',
        minWidth: 30,
        selectors: {
          'button.ms-TagItem-close': {
            color: colorsSchemaForeground(siteVariables),
            selectors: {
              ':hover': {
                borderColor: `${colorSchemaBorderHover(siteVariables)}`,
                backgroundColor: `${colorSchemaBackgroundHover(siteVariables)}`,
                color: colorsSchemaForegroundHover(siteVariables)
              }
            }
          },
          ':hover': {
            backgroundColor: `${colorSchemaBackgroundPressed(siteVariables)}`,
            color: colorsSchemaForeground(siteVariables),
            selectors: {
              'button.ms-TagItem-close': {
                color: colorsSchemaForeground(siteVariables),
                selectors: {
                  ':hover': {
                    color: colorsSchemaForegroundHover(siteVariables)
                  }
                }
              }
            }
          }
        }
      },
      pickerInput: {
        backgroundColor: `${colorsSchemaBorderFocusWithinColor(siteVariables)}`,
        color: colorsSchemaForeground(siteVariables),
        borderWidth: 0,
        height: '100%',
        padding: '10px',
        marginBottom: '8px'
      }
    });
};
interface IBncTagPickerState {
  focused: boolean;
}
export class BncTagPicker extends React.Component<IBncTagPickerProps, IBncTagPickerState> {

  private separator = '#|#';
  public picker = React.createRef<IBasePicker<ITag>>();
  private tagPickerInitialValues: ITag[] = [];

  constructor(props: IBncTagPickerProps) {
    super(props);
    Logger.subscribe(new ConsoleListener());
    this.state = {
      focused: false
    };
  }

  private changePickerFocus = (focused: boolean) => {
    this.setState({
      focused: focused
    });
  }

  public render(): JSX.Element {
    this.tagPickerInitialValues = [];

    if (this.props.items){
      this.props.items.map((item: IProfilDataItem) => {
        this.tagPickerInitialValues.push({
          key: item.key,
          name: item.name});
      });
    }
    // TODO:
    // - Dans TagPicker l'input est affiché à côté du dernière tag seulement dans Teams parce qu'on utilise
    //   une propriété CSS dans la class «itemsWrapper» qui n'existe pas sur Internet Explorer (display: 'contents').
    //   Sur Sharepoint, la boîte de texte est affichée à côté dans la première ligne
    //   et elle reste en bas à partir de la deuxième ligne.
    // - La clé Backspace n'enlève pas des tags quand la boîte de texte est vide.
    return (
      <AppContext.Consumer>
        {({ siteVariables }) => {
          const styles = getStyles(siteVariables);
          const focusStyle: string = this.state.focused ? styles.tagPickerThemeFocus : '';
          return (
            <TagPicker
              className={ this.props.inTeams
                ? `${styles.tagPickerTheme} ${ focusStyle }`
                : ''
              }
              removeButtonAriaLabel="Supprimer"
              componentRef={this.picker}
              selectedItems={this.tagPickerInitialValues}
              onResolveSuggestions={this.onResolveSuggestions}
              onItemSelected={this.onItemSelected}
              getTextFromItem={this.getTextFromItem}
              onRenderItem= {this.onRenderItem(styles)}
              onRenderSuggestionsItem={this.onRenderSuggestionsItem}
              pickerSuggestionsProps={{
                suggestionsHeaderText: this.props.suggestionsHeaderText,
                noResultsFoundText: this.props.noResultsFoundText,
              }}
              inputProps={{
                onBlur: (ev: React.FocusEvent<HTMLInputElement>) => { this.changePickerFocus(false); },
                onFocus: (ev: React.FocusEvent<HTMLInputElement>) => { this.changePickerFocus(true); },
                'aria-label': 'Tag Picker',
                className: styles.pickerInput,
                placeholder: this.props.placeholder
              }}
              styles={{
                itemsWrapper: {
                  display: this.props.inTeams ? 'contents' : 'flex'
                }
              }}
            >
            </TagPicker>
          );
        }}
        </AppContext.Consumer>
    );
  }

  private onRenderSuggestionsItem = (props: ITag): JSX.Element => {
    let prefix: string = '';
    // On ajoute le prefix s'il a été spécifié
    if (this.props.suggestionPrefixLabel){
      prefix = `${this.props.suggestionPrefixLabel} `;
    }

    const category = `${prefix}${this.getCategoryFromStringFormatted(props.name)}`;
    const name = this.getNameFromStringFormatted(props.name);
    return <BncTagItemSuggestion title={name} category={category} />;
  }

  /**
   * We pass an ITag object formatted with name property : name#|#category from taxonomy service.
   * Use this function to retrieve the name part of the string.
   * If no separator has been found return the string passed.
   *
   * @private
   * @memberof BncTagPicker
   */
  private getNameFromStringFormatted = (value: string): string => {
    let nameSplitted = value.split(this.separator);
    let returnValue: string = value;
    if (nameSplitted.length == 2){
      returnValue = nameSplitted[0];
    }

    return returnValue;
  }

  /**
   * We pass an ITag object formatted with name property : name#|#category from taxonomy service.
   * Use this function to retrieve the category part of the string.
   * If no separator has been found return the string passed.
   *
   * @private
   * @memberof BncTagPicker
   */
  private getCategoryFromStringFormatted = (value: string): string => {
    let nameSplitted = value.split(this.separator);
    let returnValue: string = value;
    if (nameSplitted.length == 2){
      returnValue = nameSplitted[1];
    }

    return returnValue;
  }

  private onRenderItem = (styles) => (props: ITagItemProps): JSX.Element => {

    return (
      <div className={`${stylesModule.tagItem} ${ this.props.inTeams ? styles.itemTagWrapTheme : ''}`}>
        <TagItem {...props} className={`${this.props.inTeams ? styles.itemTeamsTagDiv : styles.itemTagDiv}`}
          onRemoveItem={ () =>{
            this.props.onRemoveItem(props.item);
            props.onRemoveItem();
          }}>
          {props.item.name.toString()}
        </TagItem>
      </div>);
  }

  private getTextFromItem = (item: ITag): string =>{
    return this.getNameFromStringFormatted(item.name);
  }

  private onResolveSuggestions = async (filterText: string, tagList: ITag[]): Promise<ITag[]> => {
    return await this.props.onSearch(filterText);
  }

  private onItemSelected = (item: ITag): ITag | null => {
    if (this.picker.current && this.listContainsDocument(item, this.picker.current.items)) {
      return null;
    }

    item.name = this.getNameFromStringFormatted(item.name);
    item.key = Utils.transformStringToGuid(item.key.toString());
    this.props.onAddItem(item);
    return item;
  }

  private listContainsDocument = (tag: ITag, tagList?: ITag[]) => {
    if (!tagList || !tagList.length || tagList.length === 0) {
      return false;
    }
    return tagList.filter(compareTag => compareTag.key === Utils.transformStringToGuid(tag.key.toString())).length > 0;
  }

}
