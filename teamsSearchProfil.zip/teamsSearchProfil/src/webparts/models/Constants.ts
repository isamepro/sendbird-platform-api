export class ServiceConstants {
  public static readonly NAMESPACE: string = "BNC.Profil";

  public static readonly PROPERTIES = {
    BNC_COMMON: "BNC.Common",
    BNC_PROFIL: "BNC.Profil"
  };

}
