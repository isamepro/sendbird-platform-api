import { IBncConfiguration } from "bnc-library";

export interface IProfilConfiguration extends IBncConfiguration {
  '@odata.null'?: boolean;
  azureApiUrl?: string;
  termsetCompetencies?: string;
  termsetLanguages?: string;
  termsetSoftwares?: string;
  termsetCertifications?: string;
}
